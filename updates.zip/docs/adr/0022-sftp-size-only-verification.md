# ADR-0022: SFTP delivery size-only verification

## Status

Superseded — SFTP is no longer a supported destination type. This ADR is void.

## Context

After uploading to an SFTP server, the ideal verification is to read back the file and compare its SHA-256 hash. However, many SFTP servers have permission models that prevent re-reading a just-written file, and the round-trip cost on large files is significant.

## Options

1. **Size-only verification** — stat the remote file; compare byte count. Fast but cannot detect silent corruption.
2. **SHA-256 re-read** — download and hash. Reliable but expensive and may not be permitted.
3. **No verification** — rely on SSH transport integrity (HMAC). Simplest; weakest.

## Decision

Pending. Size-only verification is the current default. The weakness is documented here. Decision will be revisited for the first SFTP routing configuration.

# ADR-0015: Business notifications via ACS Email; ops alerts via action group

## Status

Superseded — replaced by Office 365 Outlook managed connector (see decision below).

## Context

Two notification channels: team notifications (delivery outcome) and ops alerts (DLQ depth, failed runs, etc.).

## Decision (original)

Team notifications use Azure Communication Services Email (MI-authenticated). Ops alerts use the existing shared action group wired to Azure Monitor alerts defined in Bicep.

## Superseding decision

Team notifications now use the **Office 365 Outlook managed connector** directly in `wf-shared-notifications-service`. ACS Email is removed. The Office 365 connector is provisioned as a managed API connection (MSI auth, `Mail.Send` application permission) and wired via `connections.json` and app settings `office365_connection_id` / `office365_connection_runtime_url`.

## Consequences (retained)

- Notification failures are non-blocking (`NOTIFICATION_FAILED` logged, never propagated).
- Recipient is always a shared mailbox or DL, never an individual's address.
- No insured names or attachment filenames in notification content.

# Apollo DTS — Operational Runbook

**Service:** Apollo Document Transfer Service (DTS)
**Milestone:** 12
**Last updated:** See git blame

This runbook is intended for on-call engineers who did not build the system. It covers daily checks, alert responses, manual operations, and configuration procedures. Read the architecture doc (`docs/architecture.md`) before your first on-call shift.

---

## On-Call Contacts

| Role | Contact | Notes |
|------|---------|-------|
| Primary on-call engineer | TBD — populate from PagerDuty rotation | |
| Secondary / escalation | TBD | |
| Platform / infra team | TBD | VNet, Key Vault, Azure subscription issues |
| Whitespace partner support | TBD | Partner API outages, credential resets |
| SharePoint admin | TBD | Required for Sites.Selected grant changes |
| CISO / security escalation | TBD | Credential compromise, data exposure incidents |
| Business owner | TBD | Go/no-go decisions on extended outages |

---

## Dashboards and Monitoring

| Resource | Location |
|----------|----------|
| Application Insights | Azure Portal → `ai-apollo-dts-{env}` |
| Live Metrics | Application Insights → Live Metrics blade |
| DTS Operations Workbook | Application Insights → Workbooks → `Apollo DTS Operations` |
| Durable Functions monitor | Azure Portal → Function App → Durable Task Hub |
| Service Bus metrics | Azure Portal → `sb-apollo-dts-{env}` → Metrics |
| Alert rules | Azure Portal → Monitor → Alerts → filter by resource group `rg-apollo-dts-{env}` |
| SQL audit / ledger | Azure Portal → `sql-apollo-dts-{env}` → Ledger → `dbo.DeliveryAuditLedger` |

Key metrics to watch at a glance:

- `requests/failed` — failed HTTP trigger invocations
- `customMetrics/DeliveryFailureRate` — permanent delivery failures per hour
- Service Bus Dead Letter queue depth on `dts-risk-delivery/$DeadLetterQueue`
- Durable orchestration pending count in the task hub

---

## Daily Checks

Perform the following each morning before 09:00 UK time on business days.

### 1. DLQ depth

```kusto
// Application Insights — check for DLQ growth overnight
customMetrics
| where timestamp > ago(12h)
| where name == "ServiceBus.DeadLetterDepth"
| summarize max(value) by bin(timestamp, 1h)
| order by timestamp desc
```

Also check directly in the portal: Service Bus → `dts-risk-delivery` → Dead-Letter sub-queue → Message count. If depth is above zero, investigate using the DLQ replay procedure in this runbook.

### 2. Running orchestrations count

```kusto
customEvents
| where timestamp > ago(1h)
| where name == "OrchestrationStarted" or name == "OrchestrationCompleted"
| summarize started = countif(name == "OrchestrationStarted"),
            completed = countif(name == "OrchestrationCompleted")
```

Alternatively, call the ops endpoint:

```
GET https://func-apollo-dts-{env}.azurewebsites.net/orchestration/status?runtimeStatus=Running
Authorization: Bearer {Entra ID token with Dts.Reader role}
```

A non-zero count of long-running instances (over 2 hours) warrants investigation — check for the `alert-delivery-stale` alert below.

### 3. Delivery stale count

Check the `alert-delivery-stale` alert status in Azure Monitor. If the alert fired overnight, run:

```kusto
customEvents
| where timestamp > ago(24h)
| where name == "DeliveryStale"
| extend workloadId = tostring(customDimensions.WorkloadId)
| extend destination = tostring(customDimensions.DestinationType)
| summarize count() by workloadId, destination, bin(timestamp, 30m)
| order by timestamp desc
```

### 4. Dead mans switch alert status

The `alert-dead-mans-switch` fires if no documents have been processed within the configured window on a business day. Confirm the alert is in a resolved state each morning. If it fired, follow the per-alert response below before the business day starts.

---

## Per-Alert Response

### alert-document-rejected

**Cause:** The number of documents rejected in the last hour has exceeded the configured threshold. Rejection reasons include `FILE_TYPE_NOT_ALLOWED`, `MAGIC_NUMBER_MISMATCH`, `CLASSIFICATION_CEILING_EXCEEDED`, or `SP_FILE_TOO_LARGE`.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(2h)
| where name == "DocumentRejected"
| extend reasonCode = tostring(customDimensions.ReasonCode)
| extend workloadId = tostring(customDimensions.WorkloadId)
| extend fileName = tostring(customDimensions.FileName)
| summarize count() by reasonCode, workloadId, bin(timestamp, 5m)
| order by timestamp desc
```

**Remediation:**

- `FILE_TYPE_NOT_ALLOWED`: The partner sent a file type not in the allowed-list for this workload. Check SQL `WorkloadDocumentRoutings.AllowedFileTypes`. If the type is genuinely expected, update the routing config via DACPAC and redeploy. If it is unexpected, notify the partner.
- `CLASSIFICATION_CEILING_EXCEEDED`: The document's classification label exceeds the ceiling configured on the routing. Review with the business owner whether the ceiling should be raised. Do not raise it without approval.
- `SP_FILE_TOO_LARGE`: SharePoint has a per-file upload limit. If the document is legitimately large, consider an alternative destination type for this workload.
- `MAGIC_NUMBER_MISMATCH`: File header does not match the declared extension. This may indicate a partner-side packaging issue. Notify the partner and retain the staging blob for investigation.

---

### alert-delivery-stale

**Cause:** One or more delivery orchestrations have been in a running state for over 2 hours without completing. This usually indicates a destination is unreachable, credentials have expired, or a Durable activity is stuck in retry loops.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(3h)
| where name == "ActivityRetry" or name == "ActivityFailed"
| extend activityName = tostring(customDimensions.ActivityName)
| extend reasonCode = tostring(customDimensions.ReasonCode)
| extend instanceId = tostring(customDimensions.InstanceId)
| summarize retries = count() by activityName, reasonCode, instanceId
| order by retries desc
```

Check the Durable task hub for the specific instance and its current activity:

```
GET /orchestration/status?runtimeStatus=Running
```

**Remediation:**

1. Identify the destination type from the stale instance's custom dimensions.
2. If `DELIVERY_ACCESS_DENIED`: credentials may have expired. Check Key Vault for the relevant secret's expiry. Rotate if needed (see Key Vault Rotation section).
4. If the activity is stuck with no retries remaining (permanent failure), the message will be dead-lettered. Confirm via DLQ depth check, then replay after fixing root cause.
5. If an instance must be forcibly terminated: `POST /runtime/webhooks/durabletask/instances/{instanceId}/terminate?reason=manual-runbook-stale`. The next scheduled trigger will pick up new documents.

---

### alert-classification-skip

**Cause:** Deliveries are being skipped because the document's classification label exceeds the routing's ceiling. This alert fires when the skip rate crosses the threshold, indicating a systematic mismatch between partner output and routing config.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(2h)
| where name == "DeliverySkipped"
| where tostring(customDimensions.ReasonCode) == "CLASSIFICATION_CEILING_EXCEEDED"
| extend workloadId = tostring(customDimensions.WorkloadId)
| extend classificationLabel = tostring(customDimensions.ClassificationLabel)
| extend ceilingLabel = tostring(customDimensions.CeilingLabel)
| summarize count() by workloadId, classificationLabel, ceilingLabel
```

**Remediation:**

1. Confirm with the business owner that the classification change on the partner side is intentional.
2. If the routing ceiling needs raising: update `WorkloadDocumentRoutings.ClassificationCeiling` via DACPAC change, raise a change record, and get security approval before deploying.
3. If the partner is sending incorrect classification labels in error: notify the partner. The skipped deliveries remain in the audit ledger. Once the issue is resolved, a backfill reprocess (see Backfill section) can replay the affected period.

---

### alert-orchestration-failure-rate

**Cause:** The rate of orchestration failures (terminal state, not retrying) has exceeded the configured threshold. This is distinct from activity-level retries — these are orchestrations that have reached a failed terminal state.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(1h)
| where name == "OrchestrationFailed"
| extend workloadId = tostring(customDimensions.WorkloadId)
| extend failureType = tostring(customDimensions.FailureType)
| extend instanceId = tostring(customDimensions.InstanceId)
| summarize count() by workloadId, failureType, bin(timestamp, 5m)
| order by timestamp desc
```

Check for exception details:

```kusto
exceptions
| where timestamp > ago(1h)
| where operation_Name contains "Orchestrat"
| project timestamp, type, outerMessage, customDimensions
| order by timestamp desc
```

**Remediation:**

1. Determine whether the failure is infrastructure (SQL unreachable, Service Bus throttled) or logic (bug, bad config).
2. Infrastructure failures: check Azure health status for the relevant service. If transient, orchestrations will be retried by Durable on the next timer fire. If the SQL or Service Bus is persistently unavailable, escalate to the platform team.
3. Logic failures: check the exception type. A `ConfigurationException` or `OptionsValidationException` means a required setting is missing or malformed — check Function App Configuration. A `DeliveryException` with an unexpected reason code may indicate a newly introduced bug — check the recent deployment history.

---

### alert-config-invalid

**Cause:** The Function App failed to validate one or more `IOptions<T>` on startup. The host will fail to start, meaning no functions are running.

**Immediate triage:**

```kusto
exceptions
| where timestamp > ago(30m)
| where type contains "OptionsValidation" or type contains "Configuration"
| project timestamp, type, outerMessage, innermostMessage
| order by timestamp desc
```

Also check Function App → Overview → Status. If the app shows as stopped or in restart loop, the host is failing to initialise.

**Remediation:**

1. Identify the failing options class from the exception message.
2. Navigate to Function App → Configuration → Application Settings.
3. Add or correct the required setting. Common causes: a new feature flag added in a deployment that was not added to the environment's app settings, or a Key Vault reference that has become invalid.
4. Save the configuration and wait for the app to restart.
5. Confirm the host starts successfully by checking Live Metrics for incoming heartbeat events.

---

### alert-partner-unauthorised

**Cause:** The Function App is receiving HTTP 401 or 403 responses from the Whitespace API via APIM. This means the Managed Identity token used to authenticate to APIM, or the downstream partner credential held in APIM, has expired or been revoked.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(1h)
| where name == "PartnerRequestFailed"
| where tostring(customDimensions.ReasonCode) == "PARTNER_UNAUTHORISED"
| extend statusCode = tostring(customDimensions.HttpStatusCode)
| extend partnerId = tostring(customDimensions.PartnerId)
| summarize count() by partnerId, statusCode, bin(timestamp, 5m)
```

**Remediation:**

1. Confirm the DTS Managed Identity has the correct APIM Subscriber role. Navigate to APIM → `apim-apollo-{env}` → Products → DTS → Subscriptions and verify the DTS identity is active.
2. If APIM itself is returning the 401, the downstream Whitespace credential in APIM may have expired. Contact the Whitespace partner to confirm and request a credential refresh. The APIM team updates the Named Value / backend credential — this does not require a DTS deployment.
3. If the issue is the DTS → APIM MI auth, verify the Function App's system-assigned identity and its APIM role assignment in IAM (per ADR-0013).

---

### alert-dead-mans-switch

**Cause:** No documents have been successfully processed within the configured window on a business day. This alert exists to catch silent failures — scenarios where the system is running but not actually doing work.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(8h)
| where name == "DocumentProcessed"
| summarize lastProcessed = max(timestamp)
```

If `lastProcessed` is hours ago or null, processing has stalled.

```kusto
// Check if discovery is running at all
customEvents
| where timestamp > ago(4h)
| where name == "DiscoveryStarted" or name == "DiscoveryCompleted"
| summarize count() by name, bin(timestamp, 30m)
| order by timestamp desc
```

**Remediation:**

1. If discovery is not starting: check the timer trigger is not disabled. Navigate to Function App → Functions → `DiscoveryTimerTrigger` → Enable.
2. If discovery is running but returning zero results: check whether the partner API is returning empty responses. This may be a legitimate quiet period or a partner API issue. Check `PARTNER_THROTTLED` or `PARTNER_UNAVAILABLE` events.
3. If discovery returns documents but none are processed: look for rejections (`DocumentRejected` events) or stale orchestrations (see `alert-delivery-stale`).
4. If processing appears stuck and no alerts explain it: consider restarting the Function App as a last resort (this will drain in-flight Durable work items gracefully).

---

### alert-zero-documents-business-day

**Cause:** End of a business day and the document count for that day is zero. Distinct from the dead mans switch in that it fires at end-of-day, not during the day.

**Immediate triage:**

```kusto
customEvents
| where timestamp > startofday(now()) and timestamp < now()
| where name == "DocumentProcessed"
| summarize count()
```

**Remediation:**

This alert may be legitimate (e.g., a bank holiday not configured in the schedule, or a day with genuinely no partner activity). Confirm with the business owner. If it is unexpected:

1. Follow the same triage as `alert-dead-mans-switch` above.
2. Check the Whitespace portal directly (out-of-band manual check) to confirm whether documents were available from the partner.
3. If documents were available but not downloaded, work through the discovery triage steps.

---

### alert-run-timeout

**Cause:** A discovery or delivery run has exceeded the configured maximum duration. The orchestration has been forcibly terminated by the timeout mechanism.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(2h)
| where name == "RunTimeout"
| extend instanceId = tostring(customDimensions.InstanceId)
| extend workloadId = tostring(customDimensions.WorkloadId)
| extend durationSeconds = todouble(customDimensions.DurationSeconds)
| project timestamp, workloadId, instanceId, durationSeconds
| order by timestamp desc
```

**Remediation:**

1. If only one workload is timing out, it may have an unusually large document set this run. Check the document count for that workload's most recent run. If this is a one-off, no action required — the next run will pick up where it left off (watermark-based).
2. If multiple workloads are timing out consistently, the timeout threshold may be too low for the current throughput. Review the `Orchestration:MaxRunDurationSeconds` app setting against observed P95 run durations in Application Insights.
3. If the timeout appears to be caused by a slow destination (NetworkShare), investigate the destination's connectivity and performance.

---

### dts-dlq-depth (M8 alert)

**Cause:** The dead letter queue depth on `dts-risk-delivery/$DeadLetterQueue` has been growing, indicating persistent delivery failures.

**Immediate triage:**

```kusto
customEvents
| where timestamp > ago(2h)
| where name == "DeliveryPermanentFailure"
| extend reasonCode = tostring(customDimensions.ReasonCode)
| extend workloadId = tostring(customDimensions.WorkloadId)
| summarize count() by reasonCode, workloadId
| order by count_ desc
```

**Remediation:** See the DLQ Replay section for step-by-step replay instructions. Identify and fix the root cause before replaying — replaying without fixing the cause will re-dead-letter the messages.

---

### dts-dv-failed (M8 alert)

**Cause:** The delivery volume failure metric has exceeded threshold. This is a volume-level signal — a significant fraction of attempted deliveries are failing.

**Immediate triage:**

```kusto
customMetrics
| where timestamp > ago(1h)
| where name == "DeliveryFailureRate"
| summarize avg(value) by bin(timestamp, 5m)
| order by timestamp desc
```

Cross-reference with `alert-orchestration-failure-rate` triage steps. If the failure rate is correlated with a single destination type, investigate that destination's health.

**Remediation:** Follow destination-specific remediation for the identified reason codes. If it is a broad infrastructure issue (SQL, Service Bus), escalate to the platform team.

---

## DLQ Replay

Dead-lettered messages in `dts-risk-delivery/$DeadLetterQueue` need to be replayed after the root cause is fixed.

### Via Azure Portal

1. Navigate to Service Bus → `sb-apollo-dts-{env}` → Topics → `dts-risk-delivery` → Subscriptions → `dts-delivery-sub` → Dead-letter.
2. Select the messages you want to replay (you can filter by EnqueuedTime or custom properties).
3. For each message: click "Resend" (this re-enqueues the message to the active queue under a new MessageId to avoid duplicate detection interference — confirm with the team whether the topic has duplicate detection enabled; if so, the resend interval must exceed the duplicate detection window configured in `ADR-0009`).

### Via Azure CLI

```bash
# List DLQ messages (peek, not destructive)
az servicebus topic subscription message peek \
  --resource-group rg-apollo-dts-{env} \
  --namespace-name sb-apollo-dts-{env} \
  --topic-name dts-risk-delivery \
  --subscription-name dts-delivery-sub \
  --sub-queue dead-letter \
  --count 100

# Receive and re-send a specific message (requires Service Bus Data Owner on the namespace)
# Use the Service Bus Explorer tool or the portal for individual message replay.
# For bulk replay, use the following pattern with the sb-explorer CLI or a short script:

# Step 1: receive messages from DLQ into a local file
az servicebus topic subscription message receive \
  --resource-group rg-apollo-dts-{env} \
  --namespace-name sb-apollo-dts-{env} \
  --topic-name dts-risk-delivery \
  --subscription-name dts-delivery-sub \
  --sub-queue dead-letter \
  --count 10

# Step 2: send each message body back to the topic
az servicebus topic message send \
  --resource-group rg-apollo-dts-{env} \
  --namespace-name sb-apollo-dts-{env} \
  --topic-name dts-risk-delivery \
  --body "{message body from step 1}"
```

Note: `az servicebus topic message send` sends a single message. For bulk replay of many DLQ messages, use Azure Service Bus Explorer (GUI or CLI tool) which supports batch DLQ requeue natively.

### Verifying replay success

After replay, monitor Application Insights for `DocumentProcessed` or `DeliveryPermanentFailure` events with correlation IDs matching the replayed messages. Confirm the DLQ depth returns to zero within the expected processing window.

---

## Backfill and Reprocess

Use this procedure when a set of deliveries failed (e.g., due to a destination being misconfigured) and need to be reprocessed after the fix is in place.

### 1. Identify the affected deliveries

```sql
-- Run against apollo-dts-{env} SQL database
SELECT
    dr.DeliveryRecordId,
    dr.WorkloadId,
    dr.DocumentVersionId,
    dr.DestinationType,
    dr.Status,
    dr.ReasonCode,
    dr.CreatedUtc,
    dr.CompletedUtc
FROM dbo.DeliveryRecord dr
WHERE dr.Status = 'PermanentFailure'
  AND dr.ReasonCode = 'DELIVERY_ACCESS_DENIED'   -- replace with target reason code
  AND dr.CreatedUtc BETWEEN '2026-09-01' AND '2026-09-28'
ORDER BY dr.CreatedUtc DESC;
```

### 2. Reset the delivery status

Only reset after the underlying issue is confirmed fixed.

```sql
-- Reset specific delivery records to allow reprocessing
-- This must be run by a DBA or via a pipeline with appropriate permissions
-- Record the affected IDs before updating

UPDATE dbo.DeliveryRecord
SET Status = 'PendingRetry',
    ReasonCode = NULL,
    CompletedUtc = NULL,
    ModifiedUtc = GETUTCDATE()
WHERE DeliveryRecordId IN (
    -- paste the list of IDs from step 1
    1001, 1002, 1003
)
AND Status = 'PermanentFailure';
```

### 3. Replay the Service Bus message

For each affected `DocumentVersionId`, re-publish the `RiskDocumentsReadyForDelivery` message to the Service Bus topic. The message body should match the schema in `docs/schemas/routings.schema.json`. If the original message is no longer available (already cleared from DLQ), construct the message from the SQL `DocumentVersion` record.

```bash
# Example: send a reprocess message via CLI
az servicebus topic message send \
  --resource-group rg-apollo-dts-{env} \
  --namespace-name sb-apollo-dts-{env} \
  --topic-name dts-risk-delivery \
  --body '{"documentVersionId": "...", "workloadId": "...", "riskId": "..."}'
```

### 4. Monitor reprocessing

Watch Application Insights for `DeliveryCompleted` events with the affected `DocumentVersionId` values. Confirm the `DeliveryAuditLedger` entries show `Success` status.

---

## Manual Fallback (Function App Unavailable)

If the Function App is completely unavailable and documents must be delivered manually:

### Step 1: Access the staging blob container

Staging blobs are written to the `staging` container in `st-apollo-dts-{env}`. Access requires the `Storage Blob Data Reader` role on that storage account.

```bash
# List blobs in the staging container
az storage blob list \
  --account-name stapolodts{env} \
  --container-name staging \
  --auth-mode login \
  --output table

# Download a specific blob
az storage blob download \
  --account-name stapolodts{env} \
  --container-name staging \
  --name "{blobPath}" \
  --file "{localOutputPath}" \
  --auth-mode login
```

### Step 2: Verify the document

The SHA-256 hash of the downloaded file should be verified against the `DocumentVersion.ContentHash` value in SQL before delivery.

```sql
SELECT dv.ContentHash, dv.FileName, dv.FileSizeBytes
FROM dbo.DocumentVersion dv
WHERE dv.DocumentVersionId = '{id}';
```

```bash
# Compute SHA-256 of the downloaded file and compare
sha256sum "{localOutputPath}"
```

### Step 3: Deliver manually

Route the verified document to its intended destination as defined in `WorkloadDocumentRoutings`. Contact the business owner or destination administrator to confirm the exact delivery path.

### Step 4: Record the manual delivery

After manual delivery, update the SQL `DeliveryRecord` to reflect the outcome so the audit ledger remains accurate:

```sql
UPDATE dbo.DeliveryRecord
SET Status = 'ManualFallback',
    CompletedUtc = GETUTCDATE(),
    Notes = 'Manual delivery performed during Function App outage — runbook fallback procedure'
WHERE DeliveryRecordId = {id};
```

---

## SharePoint Sites.Selected Grant

The DTS Managed Identity requires `Sites.Selected` write access to each SharePoint site it delivers to. `Sites.Selected` is scoped to specific sites (not tenant-wide), which requires a SharePoint admin to grant. This cannot be done via the Azure Portal.

**Prerequisites:**

- PnP.PowerShell module installed: `Install-Module PnP.PowerShell`
- SharePoint admin credentials
- The DTS Managed Identity's application (Enterprise Application) Object ID from Entra ID

### Steps

```powershell
# 1. Connect to the SharePoint admin centre
Connect-PnPOnline -Url "https://{tenant}-admin.sharepoint.com" -Interactive

# 2. Retrieve the Entra Enterprise Application for the DTS Managed Identity
#    (this is the client ID of the system-assigned identity, found in Entra ID → Enterprise Applications)
$dtsAppId = "{DTS-Managed-Identity-Client-ID}"
$dtsDisplayName = "Apollo DTS ({env})"

# 3. Grant Sites.Selected write permission on the target site
Grant-PnPAzureADAppSitePermission `
    -AppId $dtsAppId `
    -DisplayName $dtsDisplayName `
    -Site "https://{tenant}.sharepoint.com/sites/{site-name}" `
    -Permissions Write

# 4. Verify the grant
Get-PnPAzureADAppSitePermission `
    -Site "https://{tenant}.sharepoint.com/sites/{site-name}"
```

The grant takes effect immediately. No DTS restart is required.

**Removing access** (e.g., offboarding a workload):

```powershell
# List permissions to find the permission ID
$perms = Get-PnPAzureADAppSitePermission `
    -Site "https://{tenant}.sharepoint.com/sites/{site-name}"
$perms | Where-Object { $_.Application.DisplayName -eq $dtsDisplayName }

# Remove the permission
Revoke-PnPAzureADAppSitePermission `
    -Site "https://{tenant}.sharepoint.com/sites/{site-name}" `
    -PermissionId "{permissionId from above}"
```

---

## Azure Files Mount and Migration

### Mount the Azure Files share for manual access

```bash
# Linux / WSL
sudo mkdir /mnt/dts-files
sudo mount -t cifs //{storageAccount}.file.core.windows.net/{shareName} /mnt/dts-files \
  -o vers=3.0,username={storageAccount},password={storageKey},dir_mode=0777,file_mode=0777,serverino

# Windows (net use)
net use Z: \\{storageAccount}.file.core.windows.net\{shareName} {storageKey} /user:AZURE\{storageAccount}
```

Storage account key is in Key Vault at secret `kv-apollo-dts-{env}` → `StorageAccountKey`.

### Offline migration of files between shares

Use `azcopy` for share-to-share migration. Both shares must be accessible from the machine running the copy.

```bash
# Generate SAS tokens for source and destination shares
az storage share generate-sas \
  --account-name {sourceAccount} \
  --name {sourceShare} \
  --permissions rl \
  --expiry 2026-10-01T00:00:00Z \
  --output tsv

az storage share generate-sas \
  --account-name {destAccount} \
  --name {destShare} \
  --permissions rwl \
  --expiry 2026-10-01T00:00:00Z \
  --output tsv

# Copy all files preserving directory structure
azcopy copy \
  "https://{sourceAccount}.file.core.windows.net/{sourceShare}?{sourceSAS}" \
  "https://{destAccount}.file.core.windows.net/{destShare}?{destSAS}" \
  --recursive \
  --preserve-smb-info \
  --preserve-smb-permissions
```

Verify the copy with `azcopy list` and cross-check file counts before decommissioning the source share.

---

## AFS Operations Note

Azure File Share (AFS) via the `AzureFileShare` destination type is still supported in the codebase. However, on-premises network share delivery now uses the `NetworkShareDrive` destination type, which connects directly via SMB2/3 using SMBLibrary (see ADR-0026) and does not use an AFS mount. If you encounter references to AFS-based network share operations in older runbooks or documentation, they apply only to the `AzureFileShare` destination — not to `NetworkShareDrive`. The `NetworkShareDrive` destination requires no Azure Files mount; it connects directly to the on-premises UNC path.

---

## Adding a New Workload

Per ADR-0011 (configuration-as-code), all workload and routing configuration lives in SQL and is deployed via DACPAC MERGE scripts. No application code changes are needed to add a new workload.

### Step 1: Add the partner (if new)

```sql
-- In the DACPAC pre-deployment or post-deployment script:
MERGE dbo.Partner AS target
USING (VALUES
    ('{partnerId}', 'Whitespace', 'https://apim-apollo-{env}.azure-api.net/whitespace', 1)
) AS source (PartnerId, PartnerName, ApiBaseUrl, IsActive)
ON target.PartnerId = source.PartnerId
WHEN NOT MATCHED THEN
    INSERT (PartnerId, PartnerName, ApiBaseUrl, IsActive)
    VALUES (source.PartnerId, source.PartnerName, source.ApiBaseUrl, source.IsActive);
```

### Step 2: Add the workload

```sql
MERGE dbo.Workload AS target
USING (VALUES
    ('{workloadId}', '{partnerId}', '{workloadName}', '{scheduleExpression}', 1)
) AS source (WorkloadId, PartnerId, WorkloadName, CronSchedule, IsActive)
ON target.WorkloadId = source.WorkloadId
WHEN NOT MATCHED THEN
    INSERT (WorkloadId, PartnerId, WorkloadName, CronSchedule, IsActive)
    VALUES (source.WorkloadId, source.PartnerId, source.WorkloadName, source.CronSchedule, source.IsActive);
```

### Step 3: Add the routing

See the "Adding a New Routing" section below.

### Step 4: Deploy

Commit the DACPAC script changes, raise a PR, get code review, and run the CD pipeline to the target environment. The DACPAC deploy is idempotent — running it again is safe.

---

## Adding a New Routing

```sql
-- Insert or update a routing in WorkloadDocumentRoutings
MERGE dbo.WorkloadDocumentRouting AS target
USING (VALUES
    (
        '{routingId}',
        '{workloadId}',
        '{destinationType}',       -- BlobStorage | AzureFileShare | SharePointSite | SftpSite | NetworkShareDrive
        '{destinationPath}',       -- UNC path, blob container path, SharePoint folder URL, etc.
        '{allowedFileTypes}',      -- comma-separated: .pdf,.docx
        '{classificationCeiling}', -- e.g. OFFICIAL, SECRET
        1                          -- IsActive
    )
) AS source (RoutingId, WorkloadId, DestinationType, DestinationPath, AllowedFileTypes, ClassificationCeiling, IsActive)
ON target.RoutingId = source.RoutingId
WHEN MATCHED THEN
    UPDATE SET
        DestinationType = source.DestinationType,
        DestinationPath = source.DestinationPath,
        AllowedFileTypes = source.AllowedFileTypes,
        ClassificationCeiling = source.ClassificationCeiling,
        IsActive = source.IsActive
WHEN NOT MATCHED THEN
    INSERT (RoutingId, WorkloadId, DestinationType, DestinationPath, AllowedFileTypes, ClassificationCeiling, IsActive)
    VALUES (source.RoutingId, source.WorkloadId, source.DestinationType, source.DestinationPath, source.AllowedFileTypes, source.ClassificationCeiling, source.IsActive);
```

After adding a routing for `SftpSite` or `NetworkShareDrive`, ensure the corresponding feature flag is enabled in the target environment's app settings (`FeatureFlags:EnableSftpDelivery` or `FeatureFlags:EnableNetworkShareDelivery`).

---

## Key Vault Rotation

The Function App accesses all third-party secrets via Key Vault references in app settings (ADR-0028). The vault URI is set in `KeyVault__Uri`.

### Rotation procedure

1. In Key Vault, create a new secret version with the updated value. Keep the old version active during the transition.
2. If the app setting uses a versioned KV reference (`@Microsoft.KeyVault(SecretUri=https://.../{version})`), update the reference to point to the new version. If using `latest` references (recommended), no app setting change is required.
3. Restart the Function App to force re-fetch of the secret value. App settings with KV references are resolved at startup.
4. Confirm the new secret is in use by triggering a test delivery (or checking Application Insights for successful authentication events).
5. Once confirmed, disable the old secret version in Key Vault. Do not delete it immediately — retain for 30 days for rollback.

### NetworkShareDrive credential rotation

The NetworkShareDrive credentials (`{"domain":"CORP","username":"svc_dts","password":"..."}`) are stored as a JSON object in Key Vault. The secret name is configured in the routing's `CredentialSecretName` field. Follow the same steps above, but also coordinate with the domain admin to ensure the new password is set in Active Directory before rotating the KV secret.

---

## Useful Kusto Queries

```kusto
// 1. Recent permanent failures by reason code (last 4 hours)
customEvents
| where timestamp > ago(4h)
| where name == "DeliveryPermanentFailure"
| extend reasonCode = tostring(customDimensions.ReasonCode)
| extend workloadId = tostring(customDimensions.WorkloadId)
| extend destinationType = tostring(customDimensions.DestinationType)
| summarize count() by reasonCode, workloadId, destinationType
| order by count_ desc

// 2. Orchestration duration P95 by name (last 24 hours)
requests
| where timestamp > ago(24h)
| where name startswith "Orchestrat"
| summarize p95_ms = percentile(duration, 95),
            p50_ms = percentile(duration, 50),
            runs = count() by name
| order by p95_ms desc

// 3. Delivery count by destination type (last 24 hours)
customEvents
| where timestamp > ago(24h)
| where name == "DeliveryCompleted"
| extend destinationType = tostring(customDimensions.DestinationType)
| summarize count() by destinationType, bin(timestamp, 1h)
| order by timestamp desc

// 4. Stale orchestration instances (running > 2 hours)
customEvents
| where timestamp > ago(24h)
| where name == "OrchestrationStarted"
| extend instanceId = tostring(customDimensions.InstanceId)
| join kind=leftanti (
    customEvents
    | where timestamp > ago(24h)
    | where name == "OrchestrationCompleted" or name == "OrchestrationFailed"
    | extend instanceId = tostring(customDimensions.InstanceId)
) on instanceId
| where timestamp < ago(2h)
| project timestamp, instanceId, workloadId = tostring(customDimensions.WorkloadId)
| order by timestamp asc

// 5. DLQ correlation — match DLQ events to their original delivery attempts
customEvents
| where timestamp > ago(24h)
| where name == "MessageDeadLettered"
| extend correlationId = tostring(customDimensions.CorrelationId)
| extend reasonCode = tostring(customDimensions.ReasonCode)
| join kind=leftouter (
    customEvents
    | where timestamp > ago(24h)
    | where name == "DeliveryAttempted"
    | extend correlationId = tostring(customDimensions.CorrelationId)
    | extend attemptCount = toint(customDimensions.AttemptNumber)
) on correlationId
| project timestamp, correlationId, reasonCode, attemptCount, workloadId = tostring(customDimensions.WorkloadId)
| order by timestamp desc

// 6. Zero-document check — confirm processing occurred today
customEvents
| where timestamp > startofday(now()) and timestamp < now()
| where name == "DocumentProcessed"
| summarize totalProcessed = count(),
            firstProcessed = min(timestamp),
            lastProcessed = max(timestamp)
```

# Apollo DTS — Environment Inputs

App settings are set as Logic App Standard application settings. Secrets are Key Vault references (`@Microsoft.KeyVault(SecretUri=...)`); all other values are plain strings. The Bicep deployment wires these automatically from the shared KV and computed values.

For local development, copy `workflows/local.settings.json` and fill in the values with dev credentials (Azurite for storage, real SB namespace for triggers).

---

## Runtime Infrastructure

| Setting | Type | Description |
|---------|------|-------------|
| `AzureWebJobsStorage` | Connection string | Config storage account (`stauksdtsconfig{env}`) connection string. Logic App state, artifact cache. |
| `WEBSITE_CONTENTAZUREFILECONNECTIONSTRING` | Connection string | Same config storage account — workflow file share. |
| `FUNCTIONS_EXTENSION_VERSION` | String | `~4` |
| `FUNCTIONS_WORKER_RUNTIME` | String | `node` |
| `APP_KIND` | String | `workflowapp` |
| `WEBSITE_RUN_FROM_PACKAGE` | String | `1` |

---

## Observability (KV-backed)

| Setting | Type | KV secret name |
|---------|------|----------------|
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | KV reference | `appinsights-connection-string` |
| `appinsights_instrumentation_key` | KV reference | `appinsights-instrumentation-key` |

> `APPLICATIONINSIGHTS_CONNECTION_STRING` is used by the Logic App runtime SDK. `appinsights_instrumentation_key` is used by workflow actions that POST custom telemetry events directly to the App Insights ingestion endpoint (`https://dc.services.visualstudio.com/v2/track`).

---

## External Services (KV-backed)

| Setting | Type | KV secret name | Description |
|---------|------|----------------|-------------|
| `whitespace_api_apim_subscription_key` | KV reference | `whitespace-api-apim-subscription-key` | APIM subscription key for the Whitespace API product |

---

## Service Bus

| Setting | Value (computed by Bicep) | Description |
|---------|--------------------------|-------------|
| `servicebus_fully_qualified_namespace` | `sbns-uks-integrationplatform-{env}.servicebus.windows.net` | Used by the built-in serviceBus service provider (MI auth) |
| `sbus_topic_dlv_requests` | `sbt-dts-riskdocs-delivery` | Topic the delivery trigger listens on |
| `sbus_sub_dlv_requests` | `sbts-dts-riskdocs-delivery` | Subscription on the delivery topic |
| `sbus_topic_notifications` | `sbt-dts-riskdocs-notifications` | Topic the delivery orch publishes notification requests to |

---

## Blob Storage

By default all containers are on the same data storage account (`stauksdtsdata{env}`). Each container has its own account-name setting so any container can be independently pointed at a separate storage account — the Logic App MI requires `Storage Blob Data Contributor` on each target account.

| Setting | Default value | Description |
|---------|---------------|-------------|
| `blob_staging_account_name` | `stauksdtsdata{env}` | Account for the staging container (azureBlobStaging connection) |
| `blob_records_account_name` | `stauksdtsdata{env}` | Account for the immutable records container (azureBlobRecords connection) |
| `blob_quarantine_account_name` | `stauksdtsdata{env}` | Account for the quarantine container (azureBlobQuarantine connection) |
| `blob_staging_container` | `dts-staging` | Ephemeral staging area for downloaded files |
| `blob_records_container` | `dts-records` | Immutable records container (WORM, unlocked — see ADR-0018) |
| `blob_quarantine_container` | `dts-quarantine` | Files that failed hash verification |

---

## Table Storage

| Setting | Value | Description |
|---------|-------|-------------|
| `datastore_table_storage_account_name` | `stauksdtsdata{env}` | Data storage account name (used by azureTables connection config) |

---

## Business Configuration

| Setting | Type | Description |
|---------|------|-------------|
| `apim_base_url` | String | APIM base URL e.g. `https://apim-uks-integrationplatform-{env}.azure-api.net` |
| `environment_name` | String | `dev` / `uat` / `prod` — surfaced in telemetry events |
| `correlation_id_header` | String | Header name for correlation IDs passed through HTTP calls (default: `X-Correlation-ID`) |
| `whitespace_api_audience_id` | KV reference | `whitespace-api-audience-id` | Whitespace API app registration client ID; used as the MSI audience when calling the Whitespace API via APIM. Overridden per-workload via `{sourceConfigCode}::whitespace_api_audience_id`. |
| `whitespace_api_base_uri` | String | Base URI path for the Whitespace API product in APIM (e.g. `whitespace/v1.0`). Combined with `apim_base_url` at runtime: `{apim_base_url}/{whitespace_api_base_uri}/api/summary`. Overridden per-workload via `{sourceConfigCode}::whitespace_api_base_uri`. |
| `sharepoint_api_id` | String | Computed by Bicep: `/subscriptions/{subscriptionId}/providers/Microsoft.Web/locations/{location}/managedApis/sharepointonline` |
| `sharepoint_connection_id` | String | Resource ID of the SharePoint managed API connection. Empty on first deploy; populate after creating the connection in the portal. |
| `sharepoint_connection_runtime_url` | String | SharePoint managed API connection runtime URL. Empty on first deploy; populate after creating the connection in the portal. |
| `office365_api_id` | String | Computed by Bicep: `/subscriptions/{subscriptionId}/providers/Microsoft.Web/locations/{location}/managedApis/office365` |
| `office365_connection_id` | String | Resource ID of the Office 365 Outlook managed API connection. Empty on first deploy; populate after creating the connection in the portal. |
| `office365_connection_runtime_url` | String | Office 365 Outlook managed API connection runtime URL. Empty on first deploy; populate after creating the connection in the portal. |
| `key_vault_name` | String | Shared KV name e.g. `kv-uks-integration-{env}` — used by SMB activity workflow to fetch routing credentials via REST |

---

## Per-Workload App Settings

Certain settings vary per workload and are accessed dynamically at runtime using the pattern `@appsetting(concat(sourceConfigCode, '::{key}'))`. These are not declared in Bicep; they must be added manually or via script after deployment.

| Key suffix | Description |
|------------|-------------|
| `{configCode}::whitespace_api_apim_subscription_key` | APIM subscription key scoped to this workload's Whitespace API product |
| `{configCode}::whitespace_api_audience_id` | Whitespace API audience ID for OAuth validation at APIM (overrides global) |
| `{configCode}::sharepoint_site_drive_id` | SharePoint drive ID for the target document library |

---

## Destination Credentials (Key Vault secret names in `DtsWorkloadDocRouting`)

SMB routings store a `CredentialKeyVaultRef` (secret name only) in the routing table. At delivery time the activity workflow calls the Key Vault REST API using the Logic App MI.

| Destination type | Credential location |
|-----------------|---------------------|
| SharePoint Online | `Sites.Selected` permission grant via Entra; no secret required at delivery time |
| Azure Files | MI role-based (`Storage File Data Privileged Contributor`); no secret required |
| Azure Blob Storage | MI role-based (`Storage Blob Data Contributor`); no secret required |
| Network Share (SMB) | Service account password in shared KV; secret name in `DtsWorkloadDocRouting.CredentialKeyVaultRef` |

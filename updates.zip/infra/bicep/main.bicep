targetScope = 'resourceGroup'

// ── Parameters ─────────────────────────────────────────────────────────────

@description('Target environment: dev, uat, or prod')
@allowed(['dev', 'uat', 'prod'])
param environment string

@description('Azure region for all DTS resources. Determines locationCode used in resource names.')
@allowed(['uksouth', 'ukwest'])
param location string = 'uksouth'

@description('Tags applied to all resources')
param tags object = {
  product: 'dts'
  environment: environment
  managedBy: 'bicep'
}

// ── Shared integration platform ───────────────────────────────────────────────
// These resources already exist in the shared integration platform resource group.
// They are referenced (not created) by this deployment.

@description('Resource group containing the shared integration platform (KV, SB, APIM, AppInsights)')
param sharedInfraResourceGroupName string

@description('Shared Service Bus namespace name. Standard or Premium tier required for topics.')
param serviceBusNamespaceName string

@description('Shared Key Vault name. Holds APIM subscription key, AppInsights secrets, ACS endpoint.')
param sharedKeyVaultName string

@description('Shared Application Insights component name. Used to derive the Log Analytics workspace ID for diagnostic settings.')
param appInsightsName string

@description('APIM base URL for all outbound HTTP actions from workflow activities.')
param apimBaseUrl string

// ── Whitespace (Partner API) ───────────────────────────────────────────────────
// whitespace_api_apim_subscription_key is @secure() — supply via CD pipeline variable group,
// not in a parameter file. whitespaceApiBaseUri and whitespaceApiAudienceId are non-secret.
param whitespaceApiBaseUri string = ''
param whitespaceApiAudienceId string = ''
@secure()
param whitespaceApiApimSubscriptionKey string = ''

// ── KV secret names (in the shared Key Vault) ─────────────────────────────────

param correlationIdHeader string = 'X-Correlation-ID'

// ── Managed API connection URLs ────────────────────────────────────────────────

@description('SharePoint Online managed connection runtime URL. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param sharePointConnectionRuntimeUrl string = ''

@description('SharePoint Online managed API connection resource ID. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param sharePointConnectionResourceId string = ''

@description('Office 365 Outlook managed connection runtime URL. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param office365ConnectionRuntimeUrl string = ''

@description('Office 365 Outlook managed API connection resource ID. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param office365ConnectionResourceId string = ''

// [VNet] Uncomment (and remove defaults) when VNet integration is managed by Bicep.
// @description('Subnet resource ID for Logic App VNet integration. Must be delegated to Microsoft.Web/serverFarms.')
#disable-next-line no-unused-params
param logicAppSubnetId string = ''

// @description('Subnet resource ID where private endpoints are placed for both storage accounts.')
#disable-next-line no-unused-params
param storageSubnetId string = ''

// ── Alerts ─────────────────────────────────────────────────────────────────────

@description('Email address for the DTS ops alert action group. Leave empty to deploy alert rules without email notification.')
param alertEmailAddress string = ''

// ── Config storage role assignment names ──────────────────────────────────────
// Set to existing GUIDs when manual role assignments are already present on the
// config storage account, to avoid RoleAssignmentExists on re-deploy.
// Leave empty on first deploy to new environments (Bicep derives GUIDs via guid()).
param configStorageBlobRoleAssignmentName string = ''
param configStorageQueueRoleAssignmentName string = ''
param configStorageTableRoleAssignmentName string = ''

// ── Data storage role assignment names ────────────────────────────────────────
// Set to existing GUIDs when manual role assignments are already present on the
// data storage account, to avoid RoleAssignmentExists on re-deploy.
// Leave empty on first deploy to new environments (Bicep derives GUIDs via guid()).
param dataStorageBlobRoleAssignmentName string = ''
param dataStorageTableRoleAssignmentName string = ''

// ── Derived values ─────────────────────────────────────────────────────────────

var locationCodeMap = {
  uksouth: 'uks'
  ukwest:  'ukw'
}
var locationCode = locationCodeMap[location]

var logicAppName   = 'logic-${locationCode}-dts-${environment}'
var servicePlanName = 'asp-${locationCode}-dts-${environment}'

// ── Service Bus topic/sub names (must match serviceBusResources.bicep) ─────────
var sbusTopicDlvRequests   = 'sbt-dts-riskdocs-delivery'
var sbusSubDlvRequests     = 'sbts-dts-riskdocs-delivery'
var sbusTopicNotifications = 'sbt-dts-riskdocs-notifications'

// ── Existing shared resources ──────────────────────────────────────────────────

resource sharedKeyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: sharedKeyVaultName
  scope: resourceGroup(sharedInfraResourceGroupName)
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' existing = {
  name: appInsightsName
  scope: resourceGroup(sharedInfraResourceGroupName)
}

// ── Storage accounts ───────────────────────────────────────────────────────────

module storageAccounts './modules/storageAccounts.bicep' = {
  name: 'storageAccounts'
  params: {
    environment:     environment
    locationCode:    locationCode
    location:        location
    tags:            tags
    // storageSubnetId: storageSubnetId  // [VNet]
  }
}

// ── Logic App Standard ─────────────────────────────────────────────────────────

module logicApp './modules/logicAppStandard.bicep' = {
  name: 'logicAppStandard'
  params: {
    logicAppName:     logicAppName
    servicePlanName:  servicePlanName
    environment:      environment
    locationCode:     locationCode
    location:         location
    tags:             tags
    serviceBusNamespaceName: serviceBusNamespaceName
    apimBaseUrl:             apimBaseUrl
    logAnalyticsWorkspaceId: appInsights.properties.WorkspaceResourceId
    sharedKeyVaultName:      sharedKeyVaultName
    blobStagingAccountName:   storageAccounts.outputs.dataAccountName
    blobRecordsAccountName:   storageAccounts.outputs.dataAccountName
    blobQuarantineAccountName: storageAccounts.outputs.dataAccountName
    tableStorageAccountName:  storageAccounts.outputs.dataAccountName
    blobStagingContainerName:   storageAccounts.outputs.stagingContainerName
    blobRecordsContainerName:   storageAccounts.outputs.recordsContainerName
    blobQuarantineContainerName: storageAccounts.outputs.quarantineContainerName
    sbusTopicDlvRequests:   sbusTopicDlvRequests
    sbusSubDlvRequests:     sbusSubDlvRequests
    sbusTopicNotifications: sbusTopicNotifications
    sharePointConnectionRuntimeUrl:  sharePointConnectionRuntimeUrl
    sharePointConnectionResourceId:  sharePointConnectionResourceId
    office365ConnectionRuntimeUrl:   office365ConnectionRuntimeUrl
    office365ConnectionResourceId:   office365ConnectionResourceId
    correlationIdHeader:             correlationIdHeader
    whitespaceApiBaseUri:             whitespaceApiBaseUri
    whitespaceApiAudienceId:          whitespaceApiAudienceId
    whitespaceApiApimSubscriptionKey: whitespaceApiApimSubscriptionKey
    // logicAppSubnetId: logicAppSubnetId  // [VNet]
    // storageSubnetId:  storageSubnetId   // [VNet]
    configStorageBlobRoleAssignmentName:  configStorageBlobRoleAssignmentName
    configStorageQueueRoleAssignmentName: configStorageQueueRoleAssignmentName
    configStorageTableRoleAssignmentName: configStorageTableRoleAssignmentName
  }
}

// ── Service Bus resources (scoped to shared integration platform RG) ───────────

module serviceBusResources './modules/serviceBusResources.bicep' = {
  name: 'serviceBusResources'
  scope: resourceGroup(sharedInfraResourceGroupName)
  params: {
    serviceBusNamespaceName: serviceBusNamespaceName
  }
}

// ── Alert rules (scoped to shared integration platform RG) ────────────────────

module alertRules './modules/alertRules.bicep' = {
  name: 'alertRules'
  scope: resourceGroup(sharedInfraResourceGroupName)
  params: {
    environment:           environment
    locationCode:          locationCode
    logicAppId:            logicApp.outputs.logicAppId
    serviceBusNamespaceName: serviceBusNamespaceName
    appInsightsId:         appInsights.id
    alertEmailAddress:     alertEmailAddress
  }
}

// ── Logic App MI → data storage role assignments ──────────────────────────────
// Blob: read/write staging, records, quarantine containers.
// Table: read/write all DTS table entities.

var storageBlobDataContributorRoleId  = 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
var storageTableDataContributorRoleId = '0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3'

resource dataStorageRef 'Microsoft.Storage/storageAccounts@2023-01-01' existing = {
  name: 'sta${locationCode}dtsdata${environment}'
}

resource dataStorageBlobRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: empty(dataStorageBlobRoleAssignmentName) ? guid(dataStorageRef.id, logicAppName, storageBlobDataContributorRoleId) : dataStorageBlobRoleAssignmentName
  scope: dataStorageRef
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageBlobDataContributorRoleId)
    principalId: logicApp.outputs.logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource dataStorageTableRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: empty(dataStorageTableRoleAssignmentName) ? guid(dataStorageRef.id, logicAppName, storageTableDataContributorRoleId) : dataStorageTableRoleAssignmentName
  scope: dataStorageRef
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageTableDataContributorRoleId)
    principalId: logicApp.outputs.logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output logicAppName string            = logicApp.outputs.logicAppName
output logicAppId string              = logicApp.outputs.logicAppId
output logicAppDefaultHostname string = logicApp.outputs.logicAppDefaultHostname
output logicAppPrincipalId string     = logicApp.outputs.logicAppPrincipalId
output dataStorageAccountName string  = storageAccounts.outputs.dataAccountName
output configStorageAccountName string = logicApp.outputs.configStorageAccountName
output sharedKeyVaultUri string       = sharedKeyVault.properties.vaultUri

using './main.bicep'

// ── Environment (UK West — DR replica of prod) ─────────────────────────────
// Deployed to rg-ukw-dts-prod in UK West. The Logic App and storage accounts
// (staukwdtsconfigprod, staukwdtsdataprod) are provisioned here independently.
// Shared integration platform resources (KV, SB, APIM, AppInsights) remain in
// UK South and are referenced cross-region — no separate DR instances.
param environment = 'prod'
param location    = 'ukwest'

// ── Shared integration platform (rg-uks-integrationplatform-prod — UK South) ─
// Shared infra is not replicated to UK West. The DR Logic App reads secrets
// from the UK South KV and publishes to the UK South Service Bus namespace.
// Pipeline overrides this via SHARED_RESOURCE_GROUP variable group variable.
// Value here is used for local az CLI runs only.
param sharedInfraResourceGroupName = 'rg-uks-integrationplatform-prod'  // overridden by SHARED_RESOURCE_GROUP
param serviceBusNamespaceName      = 'sbns-uks-integrationplatform-prod' // overridden by SERVICE_BUS_NAMESPACE
param sharedKeyVaultName           = 'kv-uks-integration-prod'         // overridden by KEY_VAULT_NAME
param appInsightsName              = 'appi-uks-integrationplatform-prod' // overridden by APP_INSIGHTS_NAME
param apimBaseUrl                  = 'https://apim-uks-integrationplatform-prod.azure-api.net' // overridden by APIM_BASE_URL

// ── Whitespace (Partner API) ───────────────────────────────────────────────
// whitespaceApiAudienceId and whitespaceApiApimSubscriptionKey are set via CD pipeline variable group:
//   WHITESPACE_API_AUDIENCE_ID, WHITESPACE_API_APIM_SUBSCRIPTION_KEY
param whitespaceApiBaseUri = ''  // TODO: APIM suffix/route for Whitespace API (e.g. 'whitespace/v1')

// ── Managed API connections ────────────────────────────────────────────────
// Populate after creating each connection in the Azure Portal (see setup-guide.md steps 5 and 5.1).
param sharePointConnectionRuntimeUrl = ''
param office365ConnectionRuntimeUrl  = ''

// ── Networking ─────────────────────────────────────────────────────────────────
// [VNet] Uncomment when DTS-owned VNet/subnets are ready and Bicep manages VNet integration.
// param logicAppSubnetId = '/subscriptions/21788d43-ca58-4712-93b1-c42e14ae6d6c/resourceGroups/rg-ukw-dts-prod/providers/Microsoft.Network/virtualNetworks/vnet-ukw-dts-prod/subnets/snet-ukw-dts-logicapp-prod'
// param storageSubnetId  = '/subscriptions/21788d43-ca58-4712-93b1-c42e14ae6d6c/resourceGroups/rg-ukw-dts-prod/providers/Microsoft.Network/virtualNetworks/vnet-ukw-dts-prod/subnets/snet-ukw-dts-storage-prod'

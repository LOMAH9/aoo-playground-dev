using './main.bicep'

// ── Environment ────────────────────────────────────────────────────────────
param environment = 'uat'
param location    = 'uksouth'

// ── Shared integration platform (rg-uks-integrationplatform-uat) ──────────
// Pipeline overrides this via SHARED_RESOURCE_GROUP variable group variable.
// Value here is used for local az CLI runs only.
param sharedInfraResourceGroupName = 'rg-uks-integrationplatform-uat'  // overridden by SHARED_RESOURCE_GROUP
param serviceBusNamespaceName      = 'sbns-uks-integrationplatform-uat' // overridden by SERVICE_BUS_NAMESPACE
param sharedKeyVaultName           = 'kv-uks-integration-uat'          // overridden by KEY_VAULT_NAME
param appInsightsName              = 'appi-uks-integrationplatform-uat' // overridden by APP_INSIGHTS_NAME
param apimBaseUrl                  = 'https://apim-uks-integrationplatform-uat.azure-api.net' // overridden by APIM_BASE_URL

// ── Whitespace (Partner API) ───────────────────────────────────────────────
// whitespaceApiAudienceId and whitespaceApiApimSubscriptionKey are set via CD pipeline variable group:
//   WHITESPACE_API_AUDIENCE_ID, WHITESPACE_API_APIM_SUBSCRIPTION_KEY
param whitespaceApiBaseUri = ''  // TODO: APIM suffix/route for Whitespace API (e.g. 'whitespace/v1')

// ── Managed API connections ────────────────────────────────────────────────
// Populate after creating each connection in the Azure Portal (see setup-guide.md steps 5 and 5.1).
param sharePointConnectionRuntimeUrl = ''
param office365ConnectionRuntimeUrl  = ''

// ── Networking ─────────────────────────────────────────────────────────────────
// [VNet] Uncomment when DTS-owned VNet/subnets are ready and Bicep manages VNet integration.
// param logicAppSubnetId = '/subscriptions/21788d43-ca58-4712-93b1-c42e14ae6d6c/resourceGroups/rg-uks-dts-uat/providers/Microsoft.Network/virtualNetworks/vnet-uks-dts-uat/subnets/snet-uks-dts-logicapp-uat'
// param storageSubnetId  = '/subscriptions/21788d43-ca58-4712-93b1-c42e14ae6d6c/resourceGroups/rg-uks-dts-uat/providers/Microsoft.Network/virtualNetworks/vnet-uks-dts-uat/subnets/snet-uks-dts-storage-uat'

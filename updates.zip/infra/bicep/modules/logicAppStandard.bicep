param logicAppName string
param servicePlanName string
param environment string
param locationCode string
param location string
param tags object
param serviceBusNamespaceName string
param apimBaseUrl string
param whitespaceApiBaseUri string = ''
param whitespaceApiAudienceId string = ''
@secure()
param whitespaceApiApimSubscriptionKey string = ''
param logAnalyticsWorkspaceId string
param sharedKeyVaultName string

// ── Blob storage account names (per container type) ───────────────────────────
// All default to the same data account. Set independently to split containers
// across separate storage accounts — the Logic App MI requires the appropriate
// Storage Blob Data Contributor role on each target account.

param blobStagingAccountName string
param blobRecordsAccountName string
param blobQuarantineAccountName string
param tableStorageAccountName string

param blobStagingContainerName string
param blobRecordsContainerName string
param blobQuarantineContainerName string
param sbusTopicDlvRequests string
param sbusSubDlvRequests string
param sbusTopicNotifications string
param sharePointConnectionRuntimeUrl string
param sharePointConnectionResourceId string = ''
param office365ConnectionRuntimeUrl string = ''
param office365ConnectionResourceId string = ''
param correlationIdHeader string = 'X-Correlation-ID'
// param logicAppSubnetId string  // [VNet] re-enable when VNet integration is managed by Bicep
// param storageSubnetId string   // [VNet] re-enable when private endpoints are managed by Bicep
#disable-next-line no-unused-params
param logicAppSubnetId string = ''
#disable-next-line no-unused-params
param storageSubnetId string = ''

// ── Config storage role assignment names ──────────────────────────────────────
// Leave empty on first deploy to new environments (Bicep derives GUIDs via guid()).
// Set to the existing assignment GUIDs when pre-existing manual assignments are
// present, to prevent RoleAssignmentExists errors on re-deploy.
param configStorageBlobRoleAssignmentName string = ''
param configStorageQueueRoleAssignmentName string = ''
param configStorageTableRoleAssignmentName string = ''

// ── Logic App backing (config) storage ────────────────────────────────────────
// Hosts Logic App state, artifact cache, and workflow definitions at runtime.
// Naming: sta + locationCode + dts + config + env
// Network access restrictions are applied manually by the infrastructure team.

var configStorageName = 'sta${locationCode}dtsconfig${environment}'

resource configStorage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: configStorageName
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    supportsHttpsTrafficOnly: true
    networkAcls: {
      defaultAction: 'Deny'
      bypass: 'AzureServices'
      virtualNetworkRules: []
      ipRules: []
    }
  }
}

/* [VNet] Uncomment when VNet integration and private endpoints are managed by Bicep.

// ── Private DNS zones (existing, in same resource group) ──────────────────────

resource dnsZoneBlob 'Microsoft.Network/privateDnsZones@2020-06-01' existing = {
  name: 'privatelink.blob.${az.environment().suffixes.storage}'
}

resource dnsZoneFile 'Microsoft.Network/privateDnsZones@2020-06-01' existing = {
  name: 'privatelink.file.${az.environment().suffixes.storage}'
}

resource dnsZoneQueue 'Microsoft.Network/privateDnsZones@2020-06-01' existing = {
  name: 'privatelink.queue.${az.environment().suffixes.storage}'
}

resource dnsZoneTable 'Microsoft.Network/privateDnsZones@2020-06-01' existing = {
  name: 'privatelink.table.${az.environment().suffixes.storage}'
}

// ── Config storage private endpoints ─────────────────────────────────────────

resource peConfigBlob 'Microsoft.Network/privateEndpoints@2023-04-01' = {
  name: 'pe-${configStorage.name}-blob'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorage.name}-blob'
        properties: {
          privateLinkServiceId: configStorage.id
          groupIds: ['blob']
        }
      }
    ]
  }
}

resource peConfigBlobDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-04-01' = {
  name: 'default'
  parent: peConfigBlob
  properties: {
    privateDnsZoneConfigs: [
      { name: 'blob', properties: { privateDnsZoneId: dnsZoneBlob.id } }
    ]
  }
}

resource peConfigFile 'Microsoft.Network/privateEndpoints@2023-04-01' = {
  name: 'pe-${configStorage.name}-file'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorage.name}-file'
        properties: {
          privateLinkServiceId: configStorage.id
          groupIds: ['file']
        }
      }
    ]
  }
}

resource peConfigFileDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-04-01' = {
  name: 'default'
  parent: peConfigFile
  properties: {
    privateDnsZoneConfigs: [
      { name: 'file', properties: { privateDnsZoneId: dnsZoneFile.id } }
    ]
  }
}

resource peConfigQueue 'Microsoft.Network/privateEndpoints@2023-04-01' = {
  name: 'pe-${configStorage.name}-queue'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorage.name}-queue'
        properties: {
          privateLinkServiceId: configStorage.id
          groupIds: ['queue']
        }
      }
    ]
  }
}

resource peConfigQueueDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-04-01' = {
  name: 'default'
  parent: peConfigQueue
  properties: {
    privateDnsZoneConfigs: [
      { name: 'queue', properties: { privateDnsZoneId: dnsZoneQueue.id } }
    ]
  }
}

resource peConfigTable 'Microsoft.Network/privateEndpoints@2023-04-01' = {
  name: 'pe-${configStorage.name}-table'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorage.name}-table'
        properties: {
          privateLinkServiceId: configStorage.id
          groupIds: ['table']
        }
      }
    ]
  }
}

resource peConfigTableDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-04-01' = {
  name: 'default'
  parent: peConfigTable
  properties: {
    privateDnsZoneConfigs: [
      { name: 'table', properties: { privateDnsZoneId: dnsZoneTable.id } }
    ]
  }
}

*/ // end [VNet]

// ── App Service Plan ───────────────────────────────────────────────────────────

resource servicePlan 'Microsoft.Web/serverfarms@2022-09-01' = {
  name: servicePlanName
  location: location
  tags: tags
  sku: {
    name: 'WS1'
    tier: 'WorkflowStandard'
  }
  kind: 'windows'
  properties: {
    targetWorkerCount: 1
    targetWorkerSizeId: 0
    maximumElasticWorkerCount: 20
  }
}

// ── Logic App Standard ─────────────────────────────────────────────────────────
// AzureWebJobsStorage uses a connection string (same account as WEBSITE_CONTENTAZUREFILECONNECTIONSTRING).
// Using the __accountName / __credential MI auth variants causes
// IDistributedCacheProvider to register twice in the DI container (a known
// extension-bundle bug in versions ≥1.49), leaving services.Count=2 / instances.Count=0
// at startup. A single connection string registers exactly one provider.
// WEBSITE_CONTENTAZUREFILECONNECTIONSTRING must remain a full connection string —
// the App Service ARM provider enforces the exact setting name and rejects the
// __accountName variant.

var configStorageConnectionString = 'DefaultEndpointsProtocol=https;AccountName=${configStorage.name};AccountKey=${configStorage.listKeys().keys[0].value};EndpointSuffix=${az.environment().suffixes.storage}'

resource logicApp 'Microsoft.Web/sites@2022-09-01' = {
  name: logicAppName
  location: location
  tags: tags
  kind: 'workflowapp,functionapp'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: servicePlan.id
    httpsOnly: true
    // virtualNetworkSubnetId: logicAppSubnetId  // [VNet]
    siteConfig: {
      use32BitWorkerProcess: false
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      http20Enabled: false
      vnetPrivatePortsCount: 2
      // vnetRouteAllEnabled: true  // [VNet]
      appSettings: [
        // ── Runtime infrastructure ────────────────────────────────────────────
        { name: 'FUNCTIONS_EXTENSION_VERSION',       value: '~4' }
        { name: 'FUNCTIONS_WORKER_RUNTIME',          value: 'node' }
        { name: 'WEBSITE_NODE_DEFAULT_VERSION',      value: '~22' }
        { name: 'APP_KIND',                          value: 'workflowApp' }
        { name: 'WEBSITE_RUN_FROM_PACKAGE',          value: '1' }
        { name: 'AzureWebJobsStorage',               value: configStorageConnectionString }
        { name: 'WEBSITE_CONTENTAZUREFILECONNECTIONSTRING', value: configStorageConnectionString }
        { name: 'WEBSITE_CONTENTSHARE',    value: logicAppName }
        { name: 'WEBSITE_CONTENTOVERNET', value: '1' }
        { name: 'AzureFunctionsJobHost__extensionBundle__id',      value: 'Microsoft.Azure.Functions.ExtensionBundle.Workflows' }
        { name: 'AzureFunctionsJobHost__extensionBundle__version', value: '[1.*, 2.0.0)' }
        // ── Observability (set via CD pipeline from variable group) ──────────
        // APPLICATIONINSIGHTS_CONNECTION_STRING, appinsights_instrumentation_key
        // ── Runtime behaviour ──────────────────────────────────────────────────
        { name: 'correlation_id_header', value: correlationIdHeader }
        // ── Managed API connections (SharePoint Online) ────────────────────────
        { name: 'sharepoint_api_id',               value: '/subscriptions/${subscription().subscriptionId}/providers/Microsoft.Web/locations/${location}/managedApis/sharepointonline' }
        { name: 'sharepoint_connection_id',         value: sharePointConnectionResourceId }
        { name: 'sharepoint_connection_runtime_url', value: sharePointConnectionRuntimeUrl }
        // ── Managed API connections (Office 365 Outlook) ───────────────────────
        { name: 'office365_api_id',               value: '/subscriptions/${subscription().subscriptionId}/providers/Microsoft.Web/locations/${location}/managedApis/office365' }
        { name: 'office365_connection_id',         value: office365ConnectionResourceId }
        { name: 'office365_connection_runtime_url', value: office365ConnectionRuntimeUrl }
        // ── DTS infrastructure bindings ────────────────────────────────────────
        { name: 'servicebus_fully_qualified_namespace', value: '${serviceBusNamespaceName}.servicebus.windows.net' }
        { name: 'sbus_topic_dlv_requests',  value: sbusTopicDlvRequests }
        { name: 'sbus_sub_dlv_requests',    value: sbusSubDlvRequests }
        { name: 'sbus_topic_notifications', value: sbusTopicNotifications }
        // ── Blob storage (per-container account names + MI endpoints) ───────────
        { name: 'blob_staging_account_name',    value: blobStagingAccountName }
        { name: 'blob_records_account_name',    value: blobRecordsAccountName }
        { name: 'blob_quarantine_account_name', value: blobQuarantineAccountName }
        { name: 'blob_staging_endpoint',        value: 'https://${blobStagingAccountName}.blob.${az.environment().suffixes.storage}/' }
        { name: 'blob_records_endpoint',        value: 'https://${blobRecordsAccountName}.blob.${az.environment().suffixes.storage}/' }
        { name: 'blob_quarantine_endpoint',     value: 'https://${blobQuarantineAccountName}.blob.${az.environment().suffixes.storage}/' }
        { name: 'blob_staging_container',       value: blobStagingContainerName }
        { name: 'blob_records_container',       value: blobRecordsContainerName }
        { name: 'blob_quarantine_container',    value: blobQuarantineContainerName }
        // ── Table storage ──────────────────────────────────────────────────────
        { name: 'datastore_table_storage_account_name', value: tableStorageAccountName }
        { name: 'table_storage_endpoint',               value: 'https://${tableStorageAccountName}.table.${az.environment().suffixes.storage}/' }
        // ── Key Vault ──────────────────────────────────────────────────────────
        { name: 'key_vault_name', value: sharedKeyVaultName }
        // ── Business configuration ─────────────────────────────────────────────
        { name: 'environment_name', value: environment }
        { name: 'apim_base_url',    value: apimBaseUrl }
        // ── Whitespace (Partner API) ───────────────────────────────────────────
        { name: 'whitespace_api_base_uri',              value: whitespaceApiBaseUri }
        { name: 'whitespace_api_audience_id',           value: whitespaceApiAudienceId }
        { name: 'whitespace_api_apim_subscription_key', value: whitespaceApiApimSubscriptionKey }
      ]
    }
  }
}

// ── Config storage RBAC (Logic App MI) ────────────────────────────────────────
// Grants the Logic App MI read/write access to config storage for workflow
// management operations (e.g. reading workflow definitions, artifact cache).
// AzureWebJobsStorage itself uses a key connection string, so these are not
// required for host startup — but retained for runtime MI operations.

var storageBlobDataContributorId  = 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
var storageQueueDataContributorId = '974c5e8b-45b9-4653-ba55-5f855dd0fb88'
var storageTableDataContributorId = '0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3'

resource configStorageBlobRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: empty(configStorageBlobRoleAssignmentName) ? guid(configStorage.id, logicApp.id, storageBlobDataContributorId) : configStorageBlobRoleAssignmentName
  scope: configStorage
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageBlobDataContributorId)
    principalId: logicApp.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

resource configStorageQueueRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: empty(configStorageQueueRoleAssignmentName) ? guid(configStorage.id, logicApp.id, storageQueueDataContributorId) : configStorageQueueRoleAssignmentName
  scope: configStorage
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageQueueDataContributorId)
    principalId: logicApp.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

resource configStorageTableRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: empty(configStorageTableRoleAssignmentName) ? guid(configStorage.id, logicApp.id, storageTableDataContributorId) : configStorageTableRoleAssignmentName
  scope: configStorage
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageTableDataContributorId)
    principalId: logicApp.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

// ── Diagnostic settings ────────────────────────────────────────────────────────

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'default'
  scope: logicApp
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        category: 'WorkflowRuntime'
        enabled: true
        retentionPolicy: { enabled: false, days: 0 }
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
        retentionPolicy: { enabled: false, days: 0 }
      }
    ]
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output logicAppName string            = logicApp.name
output logicAppId string              = logicApp.id
output logicAppDefaultHostname string = logicApp.properties.defaultHostName
output logicAppPrincipalId string     = logicApp.identity.principalId
output servicePlanId string           = servicePlan.id
output configStorageAccountName string = configStorage.name

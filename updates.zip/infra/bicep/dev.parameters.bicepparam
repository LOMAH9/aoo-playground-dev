using './main.bicep'

// ── Environment ────────────────────────────────────────────────────────────
param environment = 'dev'
param location    = 'uksouth'

// ── Shared integration platform (rg-uks-integrationplatform-dev) ──────────
// All resources below already exist; they are referenced, not created here.
// Pipeline overrides this via SHARED_RESOURCE_GROUP variable group variable.
// Value here is used for local az CLI runs only.
param sharedInfraResourceGroupName = 'rg-uks-integrationplatform-dev'  // overridden by SHARED_RESOURCE_GROUP
param serviceBusNamespaceName      = 'sbns-uks-integrationplatform-dev' // overridden by SERVICE_BUS_NAMESPACE
param sharedKeyVaultName           = 'kv-uks-integration-dev'          // overridden by KEY_VAULT_NAME
param appInsightsName              = 'appi-uks-integrationplatform-dev' // overridden by APP_INSIGHTS_NAME
param apimBaseUrl                  = 'https://apim-uks-integrationplatform-dev.azure-api.net' // overridden by APIM_BASE_URL

// ── Whitespace (Partner API) ───────────────────────────────────────────────
// whitespaceApiAudienceId and whitespaceApiApimSubscriptionKey are set via CD pipeline variable group:
//   WHITESPACE_API_AUDIENCE_ID, WHITESPACE_API_APIM_SUBSCRIPTION_KEY
param whitespaceApiBaseUri = ''  // TODO: APIM suffix/route for Whitespace API (e.g. 'whitespace/v1')

// ── Managed API connections ────────────────────────────────────────────────
// Populate after creating each connection in the Azure Portal (see setup-guide.md steps 5 and 5.1).
param sharePointConnectionRuntimeUrl = ''
param office365ConnectionRuntimeUrl  = ''

// ── Networking ─────────────────────────────────────────────────────────────────
// [VNet] Dev uses shared vnet-uks-dev-001 / snet-subnet-001, configured manually.
// Uncomment and update subnet IDs when VNet integration is managed by Bicep.
// param logicAppSubnetId = '/subscriptions/21788d43-ca58-4712-93b1-c42e14ae6d6c/resourceGroups/rg-uks-dts-dev/providers/Microsoft.Network/virtualNetworks/vnet-uks-dts-dev/subnets/snet-uks-dts-logicapp-dev'
// param storageSubnetId  = '/subscriptions/21788d43-ca58-4712-93b1-c42e14ae6d6c/resourceGroups/rg-uks-dts-dev/providers/Microsoft.Network/virtualNetworks/vnet-uks-dts-dev/subnets/snet-uks-dts-storage-dev'

// ── Config storage role assignment names (existing manual assignments) ─────────
// These GUIDs match the role assignments already present on stauksdtsconfigdev.
// Prevents RoleAssignmentExists errors on re-deploy.
param configStorageBlobRoleAssignmentName  = '232bf333-54ee-466b-89e6-21fc59f5826a'
param configStorageQueueRoleAssignmentName = 'cb500e2d-f971-4802-8421-6cc0bec0a990'
param configStorageTableRoleAssignmentName = 'f97fbf87-0644-4dca-ba0c-78d6988070e1'
param dataStorageBlobRoleAssignmentName    = '0ff83447-1e3e-4875-9f9e-6ad3db144f75'
param dataStorageTableRoleAssignmentName   = '43751be6-9bcb-41fc-8cea-8e5907bb5f77'

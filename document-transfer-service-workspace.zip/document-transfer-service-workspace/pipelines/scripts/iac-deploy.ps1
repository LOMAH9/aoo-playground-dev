param(
    [Parameter(Mandatory)][string] $ResourceGroup,
    [Parameter(Mandatory)][string] $TemplateFile,
    [Parameter(Mandatory)][string] $ParamsFile,
    [Parameter(Mandatory)][string] $DeploymentNamePrefix,
    [Parameter(Mandatory)][string] $SharedResourceGroup,
    [Parameter(Mandatory)][string] $ServiceBusNamespace,
    [Parameter(Mandatory)][string] $ApimBaseUrl,
    [Parameter(Mandatory)][string] $AppInsightsName,
    [Parameter(Mandatory)][string] $KeyVaultName
)

$deploymentName = "$DeploymentNamePrefix-$(Get-Date -Format 'yyyyMMddHHmmss')"
Write-Host "##[section]Bicep deployment"
Write-Host "  Deployment name       : $deploymentName"
Write-Host "  Resource group        : $ResourceGroup"
Write-Host "  Shared resource group : $SharedResourceGroup"
Write-Host "  Service Bus namespace : $ServiceBusNamespace"
Write-Host "  APIM base URL         : $ApimBaseUrl"
Write-Host "  App Insights name     : $AppInsightsName"
Write-Host "  Key Vault name        : $KeyVaultName"
Write-Host "  Template              : $TemplateFile"
Write-Host "  Parameters            : $ParamsFile"

az deployment group create `
    --name $deploymentName `
    --resource-group $ResourceGroup `
    --template-file $TemplateFile `
    --parameters $ParamsFile `
    --parameters sharedInfraResourceGroupName=$SharedResourceGroup `
    --parameters serviceBusNamespaceName=$ServiceBusNamespace `
    --parameters apimBaseUrl=$ApimBaseUrl `
    --parameters appInsightsName=$AppInsightsName `
    --parameters sharedKeyVaultName=$KeyVaultName `
    --mode Incremental

if ($LASTEXITCODE -ne 0) {
    Write-Host "##[warning]Deployment failed - per-resource details:"
    az deployment operation group list `
        --name $deploymentName `
        --resource-group $ResourceGroup `
        --query "[?properties.provisioningState=='Failed'].{Resource:properties.targetResource.resourceName,Error:properties.statusMessage.error.message}" `
        --output table
    exit 1
}

Write-Host "##[section]Deployment succeeded: $deploymentName"
az deployment group show `
    --name $deploymentName `
    --resource-group $ResourceGroup `
    --query "properties.outputs" `
    --output json

param(
    [Parameter(Mandatory)] [string] $LogicAppName,
    [Parameter(Mandatory)] [string] $ResourceGroup,
    [Parameter(Mandatory)] [string] $SettingsFile
)

if (-not (Test-Path $SettingsFile)) {
    Write-Host "##[error]App settings file not found: $SettingsFile"
    exit 1
}

$config = Get-Content $SettingsFile -Raw | ConvertFrom-Json

$settingsList = @($config.Values.PSObject.Properties | ForEach-Object { "$($_.Name)=$($_.Value)" })

Write-Host "##[section]Deploying $($settingsList.Count) app settings to $LogicAppName"
$settingsList | ForEach-Object { Write-Host "  $_" }

az logicapp config appsettings set `
    --name $LogicAppName `
    --resource-group $ResourceGroup `
    --settings $settingsList

if ($LASTEXITCODE -ne 0) {
    Write-Host "##[error]App settings deployment failed (exit $LASTEXITCODE)"
    exit 1
}
Write-Host "##[section]App settings deployed successfully"

param(
    [Parameter(Mandatory)][string] $LogicAppName,
    [Parameter(Mandatory)][string] $ResourceGroup
)

Write-Host "##[section]Zip deploy"
Write-Host "  Logic App     : $LogicAppName"
Write-Host "  Resource group: $ResourceGroup"

az logicapp deployment source config-zip `
    --name $LogicAppName `
    --resource-group $ResourceGroup `
    --src logic-app-workflows.zip

if ($LASTEXITCODE -ne 0) {
    Write-Host "##[error]Zip deploy failed"
    exit 1
}
Write-Host "##[section]Zip deploy complete"

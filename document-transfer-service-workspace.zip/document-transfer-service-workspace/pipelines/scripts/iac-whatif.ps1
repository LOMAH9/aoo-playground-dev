param(
    [Parameter(Mandatory)][string] $ResourceGroup,
    [Parameter(Mandatory)][string] $TemplateFile,
    [Parameter(Mandatory)][string] $ParamsFile,
    [Parameter(Mandatory)][string] $SharedResourceGroup,
    [Parameter(Mandatory)][string] $ServiceBusNamespace,
    [Parameter(Mandatory)][string] $ApimBaseUrl,
    [Parameter(Mandatory)][string] $AppInsightsName,
    [Parameter(Mandatory)][string] $KeyVaultName
)

Write-Host "##[section]What-If Preview"
Write-Host "  Resource group        : $ResourceGroup"
Write-Host "  Shared resource group : $SharedResourceGroup"
Write-Host "  Service Bus namespace : $ServiceBusNamespace"
Write-Host "  APIM base URL         : $ApimBaseUrl"
Write-Host "  App Insights name     : $AppInsightsName"
Write-Host "  Key Vault name        : $KeyVaultName"
Write-Host "  Template              : $TemplateFile"
Write-Host "  Parameters            : $ParamsFile"

az deployment group what-if `
    --resource-group $ResourceGroup `
    --template-file $TemplateFile `
    --parameters $ParamsFile `
    --parameters sharedInfraResourceGroupName=$SharedResourceGroup `
    --parameters serviceBusNamespaceName=$ServiceBusNamespace `
    --parameters apimBaseUrl=$ApimBaseUrl `
    --parameters appInsightsName=$AppInsightsName `
    --parameters sharedKeyVaultName=$KeyVaultName `
    --no-pretty-print

if ($LASTEXITCODE -ne 0) {
    Write-Host "##[error]What-If failed"
    exit 1
}
Write-Host "##[section]What-If complete - review changes above before approving"

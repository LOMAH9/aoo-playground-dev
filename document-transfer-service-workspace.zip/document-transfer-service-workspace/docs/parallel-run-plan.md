# Apollo DTS — Parallel Run Plan

**Service:** Apollo Document Transfer Service (DTS)
**Milestone:** 12
**Last updated:** See git blame

---

## Goal

The parallel run validates that DTS automation produces identical results to the existing manual Whitespace-to-G-drive process before cutover. The manual process (a human downloading documents from the Whitespace portal and copying them to the G drive) remains the authoritative delivery during the run. DTS runs alongside it. A daily reconciliation confirms that the set of documents processed by DTS matches the set retrieved manually.

The run is divided into two weeks:

- **Week 1 — Shadow mode:** DTS runs fully but writes only to a shadow blob container. No writes to production destinations. Reconciliation confirms DTS would have delivered the correct documents.
- **Week 2 — Active mode:** DTS writes to all production destinations as well as the shadow container. The manual process continues in parallel. Reconciliation detects discrepancies between DTS-delivered and manually-delivered sets.

Cutover proceeds only after 5 consecutive business days with zero discrepancies in active mode.

---

## Week 1: Shadow Mode

### Configuration

Set the following app settings on the Function App before Week 1 begins:

| Setting | Value |
|---------|-------|
| `ParallelRun:Mode` | `Shadow` |
| `ParallelRun:ShadowContainerName` | `shadow-deliveries` |
| `FeatureFlags:EnableSftpDelivery` | `false` |
| `FeatureFlags:EnableNetworkShareDelivery` | `false` |

In shadow mode, the delivery orchestration writes every document to the `shadow-deliveries` blob container under the path `{env}/{workloadId}/{documentVersionId}/{fileName}`. No writes to SharePoint, SFTP, Azure Files, or NetworkShare destinations occur.

The DTS SQL `DeliveryRecord` table is written normally in shadow mode — every delivery attempt is recorded with `DestinationType = Shadow`.

### Daily reconciliation — Week 1

Each business day, by 17:00 UK time, the operator runs the reconciliation query below and compares the DTS shadow set against the manually downloaded set from the Whitespace portal log.

The manual process operator must log downloaded document reference IDs and filenames in the agreed daily log (shared spreadsheet or SharePoint list — TBD: confirm location with business owner).

If DTS missed documents that were manually downloaded, investigate discovery watermark accuracy and APIM connectivity. If DTS processed additional documents not in the manual log, investigate whether the manual log is complete.

---

## Week 2: Active Mode

### Configuration

Update the following app settings before Week 2:

| Setting | Value |
|---------|-------|
| `ParallelRun:Mode` | `Active` |
| `FeatureFlags:EnableSftpDelivery` | `true` (if applicable for any routing) |
| `FeatureFlags:EnableNetworkShareDelivery` | `true` |

In active mode, DTS writes to all production destinations as configured in `WorkloadDocumentRoutings`. The shadow container is still written to for reconciliation purposes.

### Daily reconciliation — Week 2

Run the same reconciliation query. In active mode, compare the DTS-delivered set against both the manual log and the actual destination contents. For NetworkShareDrive, list the files written to the G drive by DTS and compare against the manual uploads.

Any discrepancy (document in manual set but not in DTS, or document in DTS but not in manual set, or hash mismatch for the same document) must be investigated before the next business day. See Escalation below.

---

## Cutover Criteria

Cutover from parallel run to DTS-only is permitted when all of the following are true:

1. 5 consecutive business days in active mode with zero reconciliation discrepancies.
2. All Go/No-go checklist items (below) confirmed as green.
3. No open P1 or P2 incidents against DTS in the past 5 business days.
4. Business owner sign-off obtained in writing.

On cutover day, the manual process is suspended. The DTS timer trigger remains the sole delivery mechanism.

---

## Rollback Plan

Rollback can be executed at any point during the parallel run without data loss.

### Steps

1. Disable the DTS timer trigger: Azure Portal → Function App → Functions → `DiscoveryTimerTrigger` → Disable.
2. Allow any in-flight orchestrations to complete (poll `GET /orchestration/status?runtimeStatus=Running` until count is zero, or wait up to 30 minutes).
3. Clear the shadow container to avoid confusion: `az storage container delete --name shadow-deliveries --account-name stapolodts{env} --auth-mode login`. Recreate the container if needed for a future parallel run attempt.
4. Resume the manual Whitespace download process.
5. Set `ParallelRun:Mode` to `Disabled` in app settings to prevent accidental re-enabling.

No data loss occurs on rollback. The DTS SQL `DeliveryRecord` and `DeliveryAuditLedger` tables are immutable — all shadow and active deliveries remain recorded for audit. Production destinations that received writes during active mode are not rolled back (content already delivered is not removed).

If production destination writes need to be reviewed or reversed (e.g., documents were delivered incorrectly), this is an operational decision — contact the business owner and destination administrator.

---

## Daily Reconciliation Query

Run this query against the `apollo-dts-{env}` SQL database from SSMS or Azure Data Studio. Replace the date parameters before running.

```sql
-- ============================================================
-- Apollo DTS Parallel Run — Daily Reconciliation Query
-- Parameters:
--   @ReconciliationDate  : the business day to reconcile (UTC date, e.g. '2026-09-28')
--   @WorkloadId          : specific workload, or NULL for all workloads
-- ============================================================
DECLARE @ReconciliationDate DATE = '2026-09-28';  -- replace with target date
DECLARE @WorkloadId         NVARCHAR(100) = NULL;  -- set to specific WorkloadId or leave NULL for all

-- Step 1: Documents DTS processed on the given date
WITH DtsProcessed AS (
    SELECT
        dv.DocumentVersionId,
        dv.WorkloadId,
        dv.PartnerReferenceId,
        dv.FileName,
        dv.ContentHash,
        dv.FileSizeBytes,
        dv.IngestedUtc,
        dr.Status         AS DeliveryStatus,
        dr.DestinationType,
        dr.ReasonCode
    FROM dbo.DocumentVersion dv
    INNER JOIN dbo.DeliveryRecord dr
        ON dr.DocumentVersionId = dv.DocumentVersionId
    WHERE CAST(dv.IngestedUtc AS DATE) = @ReconciliationDate
      AND (@WorkloadId IS NULL OR dv.WorkloadId = @WorkloadId)
),
-- Step 2: Successful deliveries (Shadow or Active depending on run mode)
Delivered AS (
    SELECT
        DocumentVersionId,
        WorkloadId,
        PartnerReferenceId,
        FileName,
        ContentHash,
        FileSizeBytes,
        IngestedUtc,
        DeliveryStatus,
        DestinationType
    FROM DtsProcessed
    WHERE DeliveryStatus IN ('Success', 'Shadow')
),
-- Step 3: Failed or skipped deliveries
NotDelivered AS (
    SELECT
        DocumentVersionId,
        WorkloadId,
        PartnerReferenceId,
        FileName,
        ReasonCode
    FROM DtsProcessed
    WHERE DeliveryStatus NOT IN ('Success', 'Shadow')
)
-- Summary output
SELECT
    'DTS_DELIVERED'      AS RecordType,
    d.WorkloadId,
    d.PartnerReferenceId,
    d.FileName,
    d.ContentHash,
    d.FileSizeBytes,
    d.IngestedUtc,
    d.DestinationType,
    NULL                 AS ReasonCode
FROM Delivered d
UNION ALL
SELECT
    'DTS_NOT_DELIVERED'  AS RecordType,
    nd.WorkloadId,
    nd.PartnerReferenceId,
    nd.FileName,
    NULL                 AS ContentHash,
    NULL                 AS FileSizeBytes,
    NULL                 AS IngestedUtc,
    NULL                 AS DestinationType,
    nd.ReasonCode
FROM NotDelivered nd
ORDER BY RecordType, WorkloadId, PartnerReferenceId;

-- ============================================================
-- Reconciliation summary counts
-- ============================================================
SELECT
    CAST(dv.IngestedUtc AS DATE)    AS ReconciliationDate,
    dv.WorkloadId,
    COUNT(DISTINCT dv.DocumentVersionId)                              AS TotalDocumentsIngested,
    COUNT(DISTINCT CASE WHEN dr.Status IN ('Success', 'Shadow') THEN dv.DocumentVersionId END) AS TotalDelivered,
    COUNT(DISTINCT CASE WHEN dr.Status = 'PermanentFailure' THEN dv.DocumentVersionId END)     AS TotalPermanentFailures,
    COUNT(DISTINCT CASE WHEN dr.Status = 'PendingRetry' THEN dv.DocumentVersionId END)         AS TotalPendingRetry,
    COUNT(DISTINCT CASE WHEN dr.ReasonCode = 'CLASSIFICATION_CEILING_EXCEEDED' THEN dv.DocumentVersionId END) AS TotalSkippedClassification
FROM dbo.DocumentVersion dv
INNER JOIN dbo.DeliveryRecord dr ON dr.DocumentVersionId = dv.DocumentVersionId
WHERE CAST(dv.IngestedUtc AS DATE) = @ReconciliationDate
  AND (@WorkloadId IS NULL OR dv.WorkloadId = @WorkloadId)
GROUP BY CAST(dv.IngestedUtc AS DATE), dv.WorkloadId
ORDER BY dv.WorkloadId;
```

Compare the `TotalDelivered` count and the `PartnerReferenceId` set against the manual log for the same date. Any `PartnerReferenceId` present in the manual log but absent from `DTS_DELIVERED` is a discrepancy. Any `PartnerReferenceId` present in `DTS_NOT_DELIVERED` with an unexpected reason code is also a discrepancy.

---

## Escalation

If a reconciliation discrepancy is found:

1. The operator running reconciliation documents the discrepancy (WorkloadId, PartnerReferenceId, FileName, expected vs actual status) and shares it in the DTS ops channel immediately.
2. The on-call DTS engineer investigates root cause using Application Insights and the runbook's per-alert response procedures.
3. If the discrepancy cannot be explained and resolved within 4 business hours, escalate to the DTS tech lead (see On-Call Contacts in the runbook).
4. If data was delivered to a wrong destination or incorrectly omitted, notify the business owner. The business owner decides whether manual remediation is required.
5. A discrepancy resets the 5-consecutive-days cutover counter.

---

## Go/No-Go Checklist

All items must be confirmed as green by the tech lead and business owner before active mode begins (Week 2 start) and again before cutover.

| # | Item | Owner | Status |
|---|------|-------|--------|
| 1 | All M11 monitoring alerts deployed and confirmed firing in test (`alert-document-rejected`, `alert-delivery-stale`, etc.) | DTS Engineer | |
| 2 | DLQ depth at zero and no unexplained dead-lettered messages in the last 24 hours | DTS Engineer | |
| 3 | SharePoint `Sites.Selected` grant verified on all target sites (`Get-PnPAzureADAppSitePermission` returns DTS identity) | SharePoint Admin | |
| 4 | Drain-check endpoint responding: `GET /orchestration/status?runtimeStatus=Running` returns 200 within 5 seconds | DTS Engineer | |
| 5 | ADO pipeline approval gates configured for production: change-record artefact required, business-hours gate active (06:00–18:00 UK weekdays) | DevOps Lead | |
| 6 | DACPAC deployed to target environment with all routing and workload config for the parallel run workloads | DTS Engineer | |
| 7 | NetworkShareDrive Key Vault credential secret present and SMBLibrary connection test passed (test delivery to shadow path on G drive) | DTS Engineer / Domain Admin | |
| 8 | Feature flags set correctly for the run mode (`ParallelRun:Mode`, `FeatureFlags:EnableNetworkShareDelivery`) | DTS Engineer | |
| 9 | Self-hosted ADO agent (`dts-selfhosted` pool) healthy and connected to ADO | DevOps Lead | |
| 10 | Business owner briefed on parallel run schedule, reconciliation process, and escalation contacts | Business Owner | |

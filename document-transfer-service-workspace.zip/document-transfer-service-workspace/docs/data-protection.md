# Apollo DTS — Data Protection Impact Assessment Notes

> **Status:** Milestone 1 skeleton — for full DPIA, engage the DPO. This document records design-time data protection decisions and serves as input to the formal DPIA.

## Data Controller

The firm operating Apollo DTS is the data controller for all personal data processed through the service. Whitespace and other partner APIs are data processors supplying documents that may contain personal data.

## Categories of Personal Data Processed

| Category | Data Classification | Lawful Basis | Retention |
|----------|-------------------|--------------|-----------|
| Policy holder name, address, contact details | `ConfidentialPersonalData` (30) | Contract performance (Art 6(1)(b)) | Per SYSC 9 — 7 years |
| Risk survey data potentially containing personal information | `ConfidentialPersonalData` (30) | Legitimate interests (Art 6(1)(f)) | Per SYSC 9 — 7 years |
| Special category data (health, biometric) if present in risk documents | `ConfidentialSpecialCategory` (40) | Explicit consent or legal obligation (Art 9(2)) | Per SYSC 9 — 7 years |

## UK GDPR Principles (Art 5) — Implementation

| Principle | Implementation |
|-----------|--------------|
| **Lawfulness, fairness, transparency** | Processing is necessary for insurance contract performance and legal obligation |
| **Purpose limitation** | Documents used only for the stated delivery purpose; no secondary processing |
| **Data minimisation** | Only documents explicitly requested by configured delivery rules are processed |
| **Accuracy** | Documents are transmitted verbatim; no modification. SHA-256 integrity check confirms fidelity |
| **Storage limitation** | Staging blobs deleted after successful delivery (or after configurable retention window via `PurgeStagingDocuments`). Delivery records retained per SYSC 9 (7 years) |
| **Integrity and confidentiality** | TLS 1.2+ in transit; AES-256 at rest (Storage Service Encryption); Managed Identity; no credentials in code |
| **Accountability** | Full audit trail in SQL ledger table; DACPAC schema versioned in source control; SMCR accountability chain |

## Privacy by Design (Art 25)

- **Default confidentiality**: `DataClassification` is evaluated per routing rule; the classification ceiling (ADR-0012) ensures documents are never routed to a destination with insufficient controls.
- **Minimisation**: no document content is logged; only hashes, sizes, and metadata are written to Application Insights.
- **Stream-never-buffer**: documents pass through memory as streams; no content is materialised in function memory beyond the 16-byte magic-number header.
- **Staging blob TTL**: staging blobs are deleted post-delivery; not retained indefinitely.

## Security Measures (Art 32)

| Measure | Detail |
|---------|--------|
| Encryption in transit | TLS 1.2+ enforced; SFTP uses SSH-2 |
| Encryption at rest | Azure Storage SSE (AES-256); Azure SQL TDE |
| Access control | Managed Identity; RBAC on all Azure resources; no shared keys except where unavoidable (rotated via Key Vault) |
| Audit logging | Immutable SQL ledger table records every delivery outcome |
| Integrity | SHA-256 hash computed on every document; stored with delivery record |
| Vulnerability management | Dependabot / NuGet audit enabled in pipeline; `TreatWarningsAsErrors` surfaces obsolete API usage |
| Incident response | See `runbook.md`; SYSC 15A breach notification process applies |

## Right to Erasure (Art 17)

The `DeleteDocumentActivity` stub in Delivery module provides the technical capability to delete documents from all destinations. When implemented:
1. A deletion request is matched to a `DeliveryRecord` by policy reference / document hash.
2. `DeleteDocumentActivity` removes the blob from each recorded destination.
3. The deletion event is recorded in the audit ledger (the record of processing is retained; the personal data is not).

> **Note:** Erasure from partner source systems (Whitespace) is outside DTS scope — requires a separate process with the partner.

## International Transfers

- All Azure resources are provisioned in UK South / UK West — no international transfer by default.
- If a partner SFTP or SharePoint destination is outside the UK, a transfer mechanism (UK IDTA or equivalent) must be in place before enabling that destination.
- The `DataClassification` and destination configuration in SQL should record the transfer mechanism reference.

## Data Retention

| Data | Retention | Mechanism |
|------|-----------|-----------|
| Staging blobs (in-transit documents) | Until delivery confirmed + configurable grace period | `PurgeStagingDocuments` timer |
| Delivered documents at destination | Per destination owner's policy — not managed by DTS | Out of scope |
| SQL DeliveryRecord (metadata + hashes) | 7 years (SYSC 9) | SQL row-level TTL or archive job — TBD Milestone 3 |
| Application Insights telemetry | 90 days default; adjust via workspace retention setting | Azure Monitor |

## Outstanding Items for DPO Review

- [ ] Confirm lawful basis for processing special-category data in risk documents.
- [ ] Confirm Art 17 erasure procedure covers all destination types.
- [ ] Agree retention period for SQL delivery records with Records Management team.
- [ ] Review if Whitespace API constitutes an Art 28 data processing agreement requirement.
- [ ] Confirm no personal data flows into Application Insights custom dimensions (document metadata only).

<!-- TODO Milestone 2: Engage DPO for formal DPIA; update with processor agreements and transfer mechanism references -->

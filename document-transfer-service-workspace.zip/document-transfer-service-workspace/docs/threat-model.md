# Apollo DTS — Threat Model

**Service:** Apollo Document Transfer Service (DTS)
**Milestone:** 12
**Classification:** Internal
**Last updated:** See git blame

---

## Scope

This threat model covers all data flows in the Apollo DTS system:

1. Partner API polling and document discovery (Whitespace via APIM)
2. Document download and staging in Azure Blob Storage
3. Document validation (SHA-256 hash, file-type magic check, classification ceiling)
4. Service Bus message transit for delivery fan-out
5. Delivery to all five destination types: BlobStorage, AzureFileShare, SharePointSite, SftpSite, NetworkShareDrive
6. Ops endpoint access by internal operators

**Out of scope:** Partner-side (Whitespace) systems and their internal security, downstream destination security posture beyond the DTS delivery boundary, corporate network perimeter controls, endpoint security of operator workstations.

---

## Trust Boundaries

Five trust boundaries are defined:

| ID | Boundary | Direction |
|----|----------|-----------|
| TB-1 | Internet to DTS Function App | Inbound: Whitespace API responses arrive via APIM; APIM terminates external TLS |
| TB-2 | DTS Function App to Azure PaaS | Outbound from Functions: SQL, Storage, Service Bus, Key Vault — all via VNet private endpoints |
| TB-3 | DTS Function App to SharePoint Online / SFTP | Outbound internet egress via NAT gateway; no inbound |
| TB-4 | DTS Function App to on-premises network share | Outbound: SMB2/3 over port 445 via private peered VNet to corporate G drive |
| TB-5 | Ops team to DTS ops endpoints | Inbound: authenticated browser / API calls to `GET /orchestration/status` via Easy Auth |

```mermaid
graph TD
    subgraph Internet
        WS["Whitespace API"]
        SP["SharePoint Online"]
        SFTP["SFTP Site (partner)"]
        OpsUser["Ops Engineer"]
    end

    subgraph APIM["Azure APIM (TB-1 terminus)"]
        APIM_GW["APIM Gateway"]
    end

    subgraph VNet["VNet — Integration Subnet"]
        FuncApp["DTS Function App\n(Azure Functions Premium)"]
        AgentVM["Self-hosted ADO Agent VM"]
    end

    subgraph AzurePaaS["Azure PaaS — Private Endpoints (TB-2)"]
        SQL["Azure SQL\n(Ledger audit table)"]
        Blob["Azure Blob Storage\n(staging container)"]
        SB["Azure Service Bus\n(dts-risk-delivery topic)"]
        KV["Azure Key Vault"]
        AFS["Azure File Share"]
    end

    subgraph OnPrem["On-premises — Private Peered VNet (TB-4)"]
        SMB["G Drive\nNetworkShareDrive (SMB2/3 port 445)"]
    end

    WS -->|HTTPS| APIM_GW
    APIM_GW -->|MI-authenticated HTTPS, TB-1| FuncApp
    OpsUser -->|Easy Auth / Entra ID, TB-5| FuncApp

    FuncApp -->|Private endpoint, TB-2| SQL
    FuncApp -->|Private endpoint, TB-2| Blob
    FuncApp -->|Private endpoint, TB-2| SB
    FuncApp -->|Private endpoint, TB-2| KV
    FuncApp -->|Private endpoint, TB-2| AFS

    FuncApp -->|HTTPS + OAuth2, TB-3| SP
    FuncApp -->|SSH/SFTP, TB-3| SFTP

    FuncApp -->|SMB2/3 port 445, TB-4| SMB
```

---

## STRIDE Analysis

### S — Spoofing

| # | Threat | Trust Boundary | Mitigation | Control Reference |
|---|--------|---------------|------------|-------------------|
| S-1 | Attacker impersonates Whitespace API — sends crafted responses to influence document download | TB-1 | APIM holds partner OAuth2 credentials; DTS connects to APIM via Managed Identity (non-exportable token); API base URL is in immutable app config, not SQL rows | ADR-0013 |
| S-2 | Rogue service claims Managed Identity to access Azure PaaS resources | TB-2 | Managed Identity tokens are bound to the Function App's system-assigned identity; non-exportable; token audience is scoped per resource; RBAC enforced per service | Azure AD MI controls |
| S-3 | Spoofed Service Bus message injected into `dts-risk-delivery` topic | TB-2 | Service Bus namespace has public network access disabled; accessible only from VNet; Managed Identity auth used (no shared access signatures in production) | ADR-0008, VNet integration |
| S-4 | Operator spoofing — unauthenticated call to ops endpoint | TB-5 | Easy Auth enforces Entra ID authentication on all ops endpoints before request reaches function code; `Dts.Reader` app role required | ADR-0027 |
| S-5 | SFTP server impersonation (man-in-the-middle on SFTP connection) | TB-3 | Host key pinned in SQL `SftpDestinationConfig.HostKey`; mismatch results in permanent rejection with `SFTP_HOST_KEY_MISMATCH`; connection aborted | ADR-0022 |
| S-6 | SharePoint Graph API call intercepted — attacker pretends to be target site | TB-3 | TLS certificate validation enforced on all Graph calls; `Sites.Selected` permission scoped to specific site; raw HttpClient with no certificate bypass | ADR-0025 |

---

### T — Tampering

| # | Threat | Trust Boundary | Mitigation | Control Reference |
|---|--------|---------------|------------|-------------------|
| T-1 | Document modified in transit from APIM to DTS | TB-1 | TLS 1.2+ enforced on all APIM → Function connections; SHA-256 hash computed on download and stored in `DocumentVersion.ContentHash` | SHA-256 validation |
| T-2 | Document modified in staging blob between download and delivery | TB-2 | Storage account allows only DTS Managed Identity write access (RBAC `Storage Blob Data Contributor`); private endpoint; blob immutability policy configurable (ADR-0018) | ADR-0018 |
| T-3 | SQL workload or routing config tampered to redirect documents to an unauthorised destination | TB-2 | DACPAC config-as-code: all changes are code-reviewed via PR with 2-reviewer policy; no direct production SQL write access for humans; SMCR enforced; Azure SQL Ledger records all row changes with cryptographic proof | ADR-0011, ADR-0016 |
| T-4 | Service Bus message body tampered after publish | TB-2 | Message never traverses internet (private endpoint); `RiskDocumentsReadyForDelivery` schema validated on consume; malformed messages rejected before delivery begins | Schema validation |
| T-5 | NetworkShareDrive path manipulated to write outside authorised root | TB-4 | `ContainmentGuard.Check()` called in `PathBuilder.Build()` before every write; any constructed path that does not start with the configured root is rejected with `DELIVERY_PATH_ESCAPE` | §PathBuilder |
| T-6 | Attacker modifies Key Vault secret to substitute malicious credentials | TB-2 | Key Vault access policy allows only DTS Managed Identity read; Key Vault private endpoint; all secret changes are logged in Key Vault audit log with identity of modifier | ADR-0028 |

---

### R — Repudiation

| # | Threat | Trust Boundary | Mitigation | Control Reference |
|---|--------|---------------|------------|-------------------|
| R-1 | Partner denies that a document was provided or that a specific revision was current | TB-1 | `DocumentVersion` records partner-supplied revision ID, watermark, and ingestion timestamp; hash stored at download time; immutable SQL Ledger | ADR-0016 |
| R-2 | Operator denies having triggered a delivery or changed configuration | TB-5 | Easy Auth identity propagated to telemetry; ADO pipeline audit log records all deployments with approver identity; SQL Ledger records all config changes with transaction timestamp | ADR-0027, ADR-0016 |
| R-3 | DTS denies that delivery to a destination occurred | TB-2 / TB-3 / TB-4 | `DeliveryAuditLedger` records every delivery attempt with outcome, correlation ID, destination path, and timestamp; SQL Ledger provides cryptographic tamper-evidence | ADR-0016 |
| R-4 | Denial that a document was rejected | TB-2 | `DocumentRejected` events with reason codes written to Application Insights; `DeliveryRecord` with `PermanentFailure` status and `ReasonCode` persisted to SQL; DLQ retains the message for audit | Audit trail |

---

### I — Information Disclosure

| # | Threat | Trust Boundary | Mitigation | Control Reference |
|---|--------|---------------|------------|-------------------|
| I-1 | Document content (potentially sensitive insurance risk data) exposed via Application Insights telemetry | All | Only hashes, file sizes, extensions, and reason codes written to telemetry; document content never written to `ILogger`; `HashingReadStream` never buffers full content | Privacy design |
| I-2 | Personal data leaked through error messages returned from ops endpoint | TB-5 | Ops endpoint returns only orchestration status and counts; no document content, no PII, no SQL row contents in HTTP responses | ADR-0027 |
| I-3 | Third-party credentials (SFTP password, NetworkShare domain password) exposed in app settings or logs | TB-2 | All third-party secrets in Key Vault; app settings reference KV via `@Microsoft.KeyVault()` references; never written to logs; `ICredentialVault` pattern loads at delivery time only | ADR-0028 |
| I-4 | SharePoint OAuth token exposed in telemetry or logs | TB-3 | Token acquired in memory via `DefaultAzureCredential`; never logged; short-lived access token (1 hour); `Sites.Selected` scope limits exposure to named sites only | ADR-0025 |
| I-5 | SMBLibrary domain credentials for NetworkShareDrive exposed | TB-4 | Credentials stored as JSON in Key Vault; loaded at delivery time; not cached between deliveries; never written to telemetry; NTLMv2 authentication (credentials not sent in plaintext) | ADR-0026 |
| I-6 | Staging blob accessible to unauthorised services or operators | TB-2 | Staging storage account is dedicated to DTS; RBAC permits only DTS Managed Identity; private endpoint prevents internet access; operators require explicit `Storage Blob Data Reader` role assignment for break-glass access | RBAC controls |

---

### D — Denial of Service

| # | Threat | Trust Boundary | Mitigation | Control Reference |
|---|--------|---------------|------------|-------------------|
| D-1 | Partner API returns artificially large document set causing excessive scale-out | TB-1 | Durable fan-out bounded by `MaxConcurrentActivityFunctions`; Functions Premium plan with instance limits; discovery watermark prevents re-processing already-seen documents | ADR-0004, ADR-0019 |
| D-2 | Oversized document exhausts Function App memory mid-stream | TB-1 | `HashingReadStream.maxBytes` cap throws `FileTooLargeException` before full materialisation; blob is never fully buffered; stream is disposed on exception | SP_FILE_TOO_LARGE / maxBytes |
| D-3 | Service Bus message storm causes delivery backlog | TB-2 | `DELIVERY_THROTTLED` reason code with exponential back-off; Durable retry policy with max retry count; dead-lettering prevents infinite retry; `alert-delivery-stale` fires if queue backs up | DELIVERY_THROTTLED |
| D-4 | Staging storage exhausted by accumulated failed delivery blobs | TB-2 | `PurgeStagingDocuments` timer deletes blobs older than retention window; storage account quota alert; `alert-delivery-stale` fires before exhaustion | Storage cleanup |
| D-5 | SMB connection flood to on-premises network share exhausts connection pool | TB-4 | SMBLibrary connections are per-delivery, short-lived; `DELIVERY_THROTTLED` returned if share is unresponsive; circuit-breaker pattern in `NetworkShareDriveDestination` | ADR-0026 |
| D-6 | SharePoint Graph API rate limiting causes delivery failures | TB-3 | `PARTNER_THROTTLED` reason code with exponential back-off; Durable retries up to configured max; does not cascade to other destination types (fan-out isolation) | ADR-0025 |

---

### E — Elevation of Privilege

| # | Threat | Trust Boundary | Mitigation | Control Reference |
|---|--------|---------------|------------|-------------------|
| E-1 | Path traversal — attacker controls document name to escape destination root directory | TB-3 / TB-4 | `ContainmentGuard.Check()` in `PathBuilder.Build()` ensures all constructed paths start with the configured root; any path not within root is rejected with `DELIVERY_PATH_ESCAPE` before any I/O | §PathBuilder, DELIVERY_PATH_ESCAPE |
| E-2 | Archive bomb — ZIP with nested archives or very high entry count | TB-1 | `ExpandArchive` checks entry count and total expanded size before extraction; `HashingReadStream.maxBytes` cap enforced per entry | File expansion controls |
| E-3 | Macro-enabled Office document executes on open at destination | TB-3 / TB-4 | `FileTypeRules.Validate()` rejects `.xlsm`, `.docm`, `.pptm` with `FILE_TYPE_NOT_ALLOWED` | FILE_TYPE_NOT_ALLOWED |
| E-4 | Executable disguised as document — magic number mismatch | TB-1 | `FileSignature.Matches()` checks first 8 bytes against known magic patterns for each allowed extension; mismatch rejected as `MAGIC_NUMBER_MISMATCH` before staging | Magic number validation |
| E-5 | SQL injection via partner-supplied document metadata (filename, revision ID) | TB-2 | All SQL access via Dapper with parameterised queries only; raw SQL never constructed from partner-supplied values; ADR-0010 prohibits dynamic SQL | ADR-0010 |
| E-6 | Classification ceiling bypass — routing configured with overly permissive ceiling | TB-2 | Classification ceiling is a DACPAC-managed SQL field; changes require code review and SMCR approval; `alert-classification-skip` fires if ceiling is breached; §7.2 classification ceiling logic rejects delivery | ADR-0012, §7.2 classification ceiling |
| E-7 | SharePoint Sites.Selected over-grant — DTS gains access to all sites | TB-3 | `Sites.Selected` permission type explicitly limits access to only sites where `Grant-PnPAzureADAppSitePermission` has been run; not tenant-wide; Entra audit log records all grant changes | ADR-0025, Sites.Selected |

---

## Residual Risks

| ID | Risk | Likelihood | Impact | Residual Treatment |
|----|------|-----------|--------|-------------------|
| RR-1 | Whitespace OAuth token compromised (extracted from APIM config) | Low | High | Key Vault rotation on detection; APIM Named Value updated; short token TTL limits exposure window; APIM access log provides detection signal |
| RR-2 | New file type bypasses magic check via polyglot file (e.g., PDF+ZIP) | Low | Medium | Defence-in-depth: AV scanning at destination is outside DTS scope but is recommended for all delivery targets; classification ceiling provides secondary control |
| RR-3 | SFTP host key changed by partner without prior notice | Medium | Low | `SFTP_HOST_KEY_MISMATCH` causes permanent failure and DLQ alert; operator updates key via DACPAC; no data loss (document remains in staging) |
| RR-4 | SMBLibrary NTLMv2 credential capture via adversary-in-the-middle on peered VNet | Low | High | Mitigated by private peering (not internet-traversed); NTLMv2 challenge-response (no plaintext credential in wire traffic); domain account is a service account with minimal permissions |
| RR-5 | NetworkShareDrive delivers to a UNC path shared by multiple consumers — delivered file visible to unintended parties | Medium | Medium | Destination path scoped in SQL routing config; deployment of new routing requires PR review; destination folder permissions are the responsibility of the G drive admin (out of DTS scope) |
| RR-6 | Durable task hub storage account accessible to other services in the subscription | Low | Medium | Task hub storage account is dedicated to DTS; RBAC limits access; private endpoint; however, if the storage account key is compromised, task hub state could be tampered — mitigated by using MI auth for Durable (not storage key) |
| RR-7 | Application Insights workspace accessible by broad Azure AD group — telemetry visible to non-DTS engineers | Medium | Low | Telemetry contains no document content or PII; exposure limited to operational metadata (workload IDs, file sizes, reason codes); workspace RBAC should be reviewed at next access review cycle |
| RR-8 | Zero-day vulnerability in SMBLibrary library | Low | High | Dependency pinned to a specific version; Dependabot / NuGet audit alerts configured in CI; library is isolated to `NetworkShareDriveDestination` activity |

---

## Security Test Requirements

The following tests must pass before production go-live. All tests should be executed in the non-production environment with synthetic test data.

- [ ] **Path traversal fuzz test** — run `PathBuilder.Build()` with adversarial inputs: `../`, `..\\`, `%2F..%2F`, null bytes, UNC path segments. All cases must produce `DELIVERY_PATH_ESCAPE` rejection with no I/O performed.
- [ ] **Archive bomb test** — submit a ZIP with 10,000 entries totalling 5 GB expanded size. Verify rejection before expansion begins; confirm memory consumption does not exceed expected threshold.
- [ ] **Magic number polyglot test** — submit real polyglot files (PDF+ZIP, PNG+ZIP). Verify `MAGIC_NUMBER_MISMATCH` is raised for files where the declared extension does not match the magic bytes.
- [ ] **Macro-enabled Office rejection** — submit `.xlsm`, `.docm`, `.pptm` files. Verify `FILE_TYPE_NOT_ALLOWED` is raised.
- [ ] **PII telemetry audit** — run an end-to-end delivery with a synthetic document containing identifiable test PII. Review Application Insights workspace for any telemetry event containing PII in `customDimensions`. Zero findings required.
- [ ] **VNet network scan** — confirm Function App is unreachable from outside the VNet on all ports. Run an external port scan against the Function App's FQDN. Confirm zero open ports reachable from the internet.
- [ ] **Easy Auth bypass attempt** — make unauthenticated and incorrectly-scoped requests to `GET /orchestration/status`. Confirm 401 and 403 responses are returned without any application logic executing.
- [ ] **SQL injection test** — submit document metadata containing SQL injection payloads in filename, revision ID, and partner-supplied fields. Confirm all payloads are stored and retrieved as literal strings with no SQL execution side-effects.
- [ ] **SMBLibrary credential test** — verify Key Vault credential load fails safely (throws `CredentialVaultException`) if the secret is absent or malformed; confirm the exception message does not expose partial credential content in telemetry.
- [ ] **Classification ceiling enforcement test** — configure a routing with `ClassificationCeiling = OFFICIAL`; submit documents with `SECRET` and `TOP_SECRET` labels. Confirm `CLASSIFICATION_CEILING_EXCEEDED` is raised and no delivery to the destination occurs.
- [ ] **Sites.Selected scope test** — grant DTS MI access to Site A only; attempt delivery to Site B; confirm `DELIVERY_ACCESS_DENIED` (Graph 403) is returned and no content is written.
- [ ] **DLQ dead-letter test** — exhaust retry count on a deliberately failing delivery; confirm message reaches the DLQ and the `alert-dts-dlq-depth` alert fires within the configured evaluation window.

---

## Sign-Off

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Security Architect / CISO | TBD | TBD | |
| Lead Engineer | TBD | TBD | |
| Data Protection Officer | TBD | TBD | |

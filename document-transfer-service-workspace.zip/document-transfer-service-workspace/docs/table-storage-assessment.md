# Apollo DTS — Azure Table Storage vs Azure SQL: Assessment & Recommendations

**Author:** SpykherTech Engineering  
**Date:** September 2026  
**Status:** Decision Review

---

## Executive Summary

Replacing Azure SQL with Azure Table Storage would save ~£30–60/month at the cost of
rewriting every data-access subsystem, eliminating all temporal audit history, and
accepting eventual-consistency in a service where correctness guarantees are a
compliance requirement. **This pivot is not recommended.**

The recommended path to cost reduction is **Azure SQL Serverless (General Purpose,
auto-pause after 1 hr idle)**, which brings the baseline to £5–10/month with zero
code changes. Should that still be unacceptable, **Cosmos DB Serverless** is a viable
middle path that preserves enough query capability to keep the current design largely
intact. Full Table Storage is a last resort that would constitute a near-rewrite.

---

## Current SQL Usage by Table

### Group A — Trivial to migrate (lookup / append-only / no transactions)

| Table | Rows of concern | Notes |
|---|---|---|
| `dts.DataClassifications` | 4-row enum lookup | No FK pressure; partition by code, simple point reads |
| `dts.NonWorkingDays` | ~200–500 rows/year | Range queries by region + date; doable via partition scan |
| `dts.AuditEvents` | Append-only ledger | No FKs by design; already closest to NoSQL; good Table Storage fit |

### Group B — Moderate complexity (constraints replaceable in app code)

| Table | SQL features in use | Migration cost |
|---|---|---|
| `dts.Partners` | System-versioned temporal, FK from Workloads | Lose history; app must enforce uniqueness |
| `dts.Risks` | `rowversion` OCC, UMR unique constraint | Must replace rowversion with ETag/conditional update |
| `dts.WorkloadRuntimeState` | `rowversion` OCC, key-value watermark | Watermark atomicity depends on single-row conditional replace |
| `dts.WorkloadSchedules` | Temporal, DaysOfWeekMask range queries | Lose history; schedule queries become partition scans |
| `dts.WorkloadDocumentRoutings` | Temporal, multi-column unique constraints | Lose history; uniqueness moves to app layer |

### Group C — High complexity (SQL-only features with no Table Storage equivalent)

| Table | Blocking SQL features | Why it matters |
|---|---|---|
| `dts.Workloads` | System-versioned temporal (25+ columns), complex CHECK constraints | Temporal history is the compliance audit trail; losing it increases regulatory risk |
| `dts.OrchestrationRuns` | `UQ_OR_OneRunningPerWorkload` unique partial index, status state machine, multi-column uniqueness | Unique constraint prevents double-dispatch; impossible to enforce atomically in Table Storage |
| `dts.OrchestrationRunRisks` | TVP bulk insert via `usp_RegisterCandidates`, FK, status machine | TVPs have no equivalent; batch operations are limited to 100 same-partition entities |
| `dts.DocumentVersions` | 3 unique indexes (content hash, delivered filename, version sequence), 9-status state machine, SHA-256 deduplication, `rowversion` OCC | Content deduplication and version sequencing are core correctness guarantees; all become race conditions without transactions |
| `dts.DocumentDeliveries` | Stored procedures `usp_ClaimDelivery`, `usp_RecordDeliveryOutcome`, per-routing FK, `rowversion` | Claim-and-update is a two-step atomic operation; Table Storage offers no equivalent |

---

## SQL Features Lost in a Table Storage Pivot

| Feature | Current usage | Table Storage equivalent | Risk if lost |
|---|---|---|---|
| **System-versioned temporal tables** | Partners, Workloads, WorkloadSchedules, WorkloadDocumentRoutings — full change history for audit | None — requires manual soft-delete versioning in app code | Loss of compliant audit trail; Lloyd's / FCA readiness degraded |
| **Foreign key constraints** | Orphan prevention across 8 table relationships | None — must validate in app code on every write | Silent data corruption; orphaned DocumentVersions, DeliveryRecords |
| **Multi-column unique constraints** | Prevent duplicate runs, duplicate document versions, duplicate delivered filenames | None — Table Storage supports single-property uniqueness via RowKey only | Duplicate ingestion, conflicting deliveries, reprocessing storms |
| **Table-valued parameters (TVPs)** | `usp_RegisterCandidates` bulk-inserts document candidates atomically in one round-trip | None — would need N individual entity inserts (1 per document), 100-entity batch max, same partition only | N×round-trips, no atomic guarantee; partial success leaves DB in inconsistent state |
| **Stored procedures with transactions** | `usp_ClaimDelivery`, `usp_BeginRun`, `usp_CompleteRun`, `usp_MarkDownloaded`, `usp_MarkValidated`, `usp_MarkPublished` — each is atomic state-machine transition | None — state machine moves into app code; concurrent workers can observe split state | Duplicate delivery claims, split-brain run state, phantom watermarks |
| **`rowversion` optimistic concurrency** | `dts.Risks`, `dts.WorkloadRuntimeState`, `dts.DocumentVersions`, `dts.DocumentDeliveries` | ETags on Table Storage entities — viable replacement, but requires rewriting all Dapper calls to SDK calls | Without replacement: last-write-wins on concurrent updates |
| **ACID cross-row transactions** | Watermark commit atomically advances run state + write audit row | Table Storage: single-partition batch only (100 entities, same partition key) — no cross-partition transactions | Non-atomic watermark commits mean restarts could re-process or skip documents |
| **Window functions + JOINs** | `ScheduleImportRuns` uses MAX() over OrchestrationRuns with window to compute watermark | Not supported — client must load all candidate rows and aggregate in memory | Full partition scan on every scheduler tick; O(n) memory use scales with run history |
| **CHECK constraints** | Notification config integrity, DocSourceType validity, limits ranges | None — must validate in app code | Silent bad data written to storage |

---

## Tiered Recommendations

### Tier 1 — SQL Serverless auto-pause (Recommended)

**Cost:** ~£5–10/month in a low-load environment (auto-pauses after 1 hr idle; ~£0 at weekends).  
**Code changes required:** Zero.  
**Schema changes required:** Zero.  
**Ops changes required:** Change SQL tier from Basic/Standard to General Purpose Serverless in the Bicep/Terraform modules; set `autoPauseDelay = 60` (minutes).

**Reasoning:** The entire cost concern is the always-on baseline of Basic S0 (~£30–60/mo). Serverless GP with auto-pause eliminates this. The vCore billing model means idle minutes cost nothing. At the document volumes DTS operates at (scheduled polling workloads, not continuous stream processing), the DB will be idle for large portions of each day. The first resume from cold start adds ~6–15 s latency to the first query after the pause window — acceptable given this is a background pipeline, not a user-facing API.

**This is the only option that preserves all current correctness guarantees, compliance properties, and codebase stability.**

### Tier 2 — Cosmos DB Serverless

**Cost:** Near-zero idle; pay per RU consumed. Rough estimate: £2–8/month at DTS polling volumes.  
**Code changes required:** Significant — replace all Dapper SQL with Cosmos SDK calls. Stored procedures must be rewritten as Cosmos JS stored procedures (per-partition only) or moved to app-layer transactions with conditional writes. Temporal versioning must be implemented manually.  
**Correctness preservation:**
- ETags replace `rowversion` for optimistic concurrency — viable 1:1 swap.
- Conditional writes (`IfMatchEtag`) replace stored procedure atomic state transitions — requires careful implementation.
- Cosmos transactions are scoped to a logical partition — watermark commit atomicity preserved if workload data shares a partition key.
- Cross-partition joins must move to client-side — acceptable for the known query patterns.
- Temporal history requires manual versioning (copy-on-write to a history container) — adds complexity but preserves compliance capability.

**Reasoning:** Cosmos DB Serverless is a credible middle path. It eliminates the idle-cost problem while retaining enough SDK capability to preserve data model correctness. The migration would take 4–6 sprints of focused development and re-testing. It is appropriate if the Tier 1 serverless cost reduction is insufficient or if there is a strategic preference to eliminate SQL dependencies entirely. Cosmos DB Table API is a further simplification: the SDK surface is familiar and closer to Table Storage, but query capability is still significantly richer than native Table Storage.

### Tier 3 — Full Azure Table Storage

**Cost:** ~£0–2/month.  
**Code changes required:** Complete rewrite of all data-access code (8 feature modules), loss of stored procedures, loss of temporal auditing, loss of FK integrity, redesign of all concurrency controls.  
**Not recommended unless:**
- Workload volume will permanently remain at a single low-throughput workload
- Regulatory audit trail requirements are relaxed or met externally (e.g., blob immutability only)
- The team accepts eventual consistency for watermark commits and document state machines

**Reasoning:** The cost saving over Tier 1 is £5–10/month. The implementation cost of the pivot is weeks to months of re-development, with measurable correctness regression risk during the transition. The risk-to-saving ratio is poor. If cost is the only driver, Tier 1 is strictly superior.

---

## Summary Decision Matrix

| Option | Monthly cost | Code change | Audit trail | Correctness guarantees | Recommendation |
|---|---|---|---|---|---|
| SQL Basic S0 (current) | £30–60 | None | Full temporal | Full ACID | Baseline |
| **SQL Serverless GP** | **£5–10** | **None** | **Full temporal** | **Full ACID** | **Recommended** |
| Cosmos DB Serverless | £2–8 | Significant | Manual versioning | ETag OCC; partial txn | Viable if SQL removed strategically |
| Azure Table Storage | £0–2 | Near-rewrite | Lost | App-layer only | Last resort only |

# Apollo DTS — Architecture Overview

> **Status:** Milestone 1 skeleton — expand during Milestone 2 implementation.

## System Context

Apollo Document Transfer Service (DTS) is an Azure Functions v4 application running on the Flex Consumption hosting plan. It polls external partner APIs (Whitespace initially), retrieves risk documents, validates them, and delivers them to one or more downstream destinations (Azure Blob Storage, SharePoint, SFTP, Azure File Share, Network Share).

```
┌─────────────────────────────────────────────────────────┐
│  Partner APIs (Whitespace, future partners)             │
└────────────────────────┬────────────────────────────────┘
                         │ HTTPS / polling
                         ▼
┌─────────────────────────────────────────────────────────┐
│  Apollo DTS  (Azure Functions Flex Consumption)         │
│                                                         │
│  ┌────────────────┐    ┌─────────────────────────────┐  │
│  │  Discovery     │───▶│  Service Bus Topic          │  │
│  │  Module        │    │  dts-risk-delivery          │  │
│  └────────────────┘    └──────────────┬──────────────┘  │
│                                       │                  │
│                        ┌─────────────▼──────────────┐   │
│                        │  Delivery Module            │   │
│                        └─────────────────────────────┘   │
│                                       │                  │
│  ┌──────────────────────────────────┐ │                  │
│  │  SQL Database (config + state)   │ │                  │
│  └──────────────────────────────────┘ │                  │
└───────────────────────────────────────┼─────────────────┘
                                        │
              ┌─────────────────────────▼──────────────────┐
              │  Destinations                               │
              │  - Azure Blob Storage                       │
              │  - Azure File Share                         │
              │  - SharePoint Online                        │
              │  - SFTP                                     │
              │  - Network Share (SMB)                      │
              └─────────────────────────────────────────────┘
```

## Hosting

| Attribute | Value |
|-----------|-------|
| Runtime | Azure Functions v4, .NET 10 isolated worker |
| Hosting plan | Flex Consumption (VNet-integrated, scale-to-zero) |
| Region | UK South (primary), UK West (DR) |
| Language version | C# 14 |

## Vertical Slice Architecture

Each feature lives entirely within a single slice folder. A slice contains:

```
Feature/
  <Feature>Trigger.cs        // Timer / Service Bus / HTTP trigger
  <Feature>Orchestrator.cs   // Durable orchestrator (if orchestrated)
  <Feature>Activity.cs       // Durable activity (if orchestrated)
  <Feature>Handler.cs        // Core business logic — no Azure types
  <Feature>Sql.cs            // Dapper queries
```

Handlers depend only on ports (interfaces). All Azure SDK types are kept in Triggers and Activities.

## Module Boundaries

| Module | Responsibilities | May reference |
|--------|-----------------|---------------|
| SharedKernel | Cross-cutting types (no Azure SDK) | Nothing internal |
| Contracts | Service Bus message schemas | Nothing internal |
| Discovery | Partner polling, document retrieval, archive expansion | SharedKernel, Contracts |
| Delivery | Destination dispatch, envelope building, record writing | SharedKernel, Contracts |
| Host | DI wiring, startup | All modules |
| Database | SQL schema (DACPAC) | N/A |

Discovery and Delivery are strictly decoupled — they communicate only via the `dts-risk-delivery` Service Bus topic.

## Key Design Decisions

Architecture Decision Records in `docs/adr/` govern all material decisions. Key ADRs:

| ADR | Decision |
|-----|---------|
| ADR-0001 | Azure Functions v4 + Durable Functions on Flex Consumption |
| ADR-0003 | Azure Storage task hub (not Netherite/MSSQL) |
| ADR-0005 | Vertical slice architecture |
| ADR-0008 | Stream-never-buffer for document transit |
| ADR-0009 | Deterministic idempotency key strategy |
| ADR-0015 | SQL config-as-code via DACPAC MERGE |
| ADR-0018 | Managed identity everywhere; Key Vault for third-party creds only |

## Data Flow — Discovery

1. `DispatchDueWorkloadsTrigger` fires on a timer and evaluates active partner schedules.
2. `SyncPartnerChangesTrigger` launches a Durable orchestration per due workload.
3. The orchestration pages through partner change records, enriches each with a risk plan, and fans out to per-document processing.
4. Each document is downloaded as a stream (never buffered), SHA-256 hashed, type-validated, size-checked, and uploaded to staging Blob Storage.
5. A `RiskDocumentsReadyForDelivery` message is published to the Service Bus topic.

## Data Flow — Delivery

1. `DeliverDocumentsTrigger` consumes messages from `sub-delivery`.
2. A Durable orchestration resolves active destinations, builds the target path, and fans out per-destination delivery.
3. Each destination implementation streams directly from staging Blob to target.
4. Delivery outcome is recorded to SQL; an audit event is emitted.

## Compliance

- UK GDPR Art 5(1)(f), Art 25, Art 32: encryption in transit (TLS 1.2+) and at rest (Storage Service Encryption), access via Managed Identity.
- UK GDPR Art 17: document deletion capability via `DeleteDocumentActivity`.
- SYSC 9: audit trail written for every document disposition event.
- SYSC 15A: retry/circuit-breaker strategy per ADR-0006; DR region per ADR-0021.
- SMCR: all config changes are code-reviewed and deployed via pipeline — no manual production access.

<!-- TODO Milestone 2: expand with sequence diagrams per flow, component diagram, dependency graph -->

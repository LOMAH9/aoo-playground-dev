# BUILD PROMPT v3 — Apollo Document Transfer Service (DTS)

Self-contained build specification. Supersedes v2 and all earlier drafts.
Decisions marked **pre-accepted** are recorded as ADRs with status `Accepted` and are not re-opened.

---

## 0. Role and operating rules

You are a senior secure-by-design .NET/Azure engineer and solution architect building a production
system for a **UK FCA/PRA-regulated London Market insurance underwriter**. You work in VS Code on the
repository described in §5.

Operating rules, in priority order:

1. **Never invent third-party behaviour.** Whitespace facts in §6.1 come from published OpenAPI documents
   and are *evidence, unverified* until Milestone 0 sandbox capture. Anything not in §6.1 or the
   assumption register (§21) is unknown: add an assumption (`ASM-nnn`), make it configurable, back it with
   a WireMock.Net stub. Do not guess.
2. **Never invent SDK APIs.** If you are not certain a type or member exists in the pinned package version,
   prove it by compiling or consult official Microsoft/Azure documentation. If you cannot verify it, mark
   the line `// VERIFY:` and list it in the milestone report.
3. **Security and auditability outrank convenience.** No secrets in code, config, logs or test fixtures.
   Managed identity everywhere. If something cannot be done securely, stop and write an ADR with options.
4. **ADR before code** for any decision with more than one reasonable answer: `/docs/adr/NNNN-title.md`,
   MADR format.
5. **Vertical milestones (§23).** Each ends green (§0.1). Stop, report, and do not start the next milestone
   until asked.
6. **Ask before assuming anything about the customer environment.** Use placeholders `<<LIKE_THIS>>`,
   list them in `/docs/environment-inputs.md` (§25), and never hardcode them.
7. **Report honestly.** Every milestone ends with a report containing: what was built; commands run and
   their actual results; what is NOT tested or verified; outstanding `// VERIFY:` items; assumptions and
   ADRs added. Never claim something works if you have not run it.
8. **Small, reviewable commits** (Conventional Commits), one concern each. No drive-by refactors.

### 0.1 Commands that must pass at the end of every milestone

```bash
dotnet restore
dotnet build -c Release -warnaserror
dotnet format --verify-no-changes
dotnet test -c Release --no-build            # integration tests require Docker (Testcontainers)
az bicep build --file infra/main.bicep       # plus bicep lint; from Milestone 3
```

`az deployment group what-if` needs Azure credentials. If none are available, state that it was not run.

---

## 1. Business problem and scope

Underwriters log into the **Whitespace Platform** (a Lloyd's-recognised electronic placing platform) daily.
They manually identify risks whose documents changed, download them (mostly PDFs, plus XLSX schedules of
values, DOCX, MSG, images; from a few KB to several hundred MB) and copy them to a shared drive. The process
is slow, error-prone and has no reliable audit trail.

**Goal:** a generic, enterprise-grade **Document Transfer Service (DTS)**. The first workload is
*Whitespace → Apollo document import*: automated discovery, validated download, versioned evidential
storage and routing to one or more configured destinations, with a tamper-evident audit trail fit for
regulatory inspection.

The design must also support these workloads without redesign:

- **InternalTransfer**: internal location → one or a mix of destinations;
- **PartnerInbound**: other partners, e.g. PPL, including partner-published Service Bus topics;
- **PartnerOutbound**: submitting documents or quotes to partners via POST, behind a human approval gate.

**In scope now:** the workload/routing/schedule model, the scheduler, the Discovery module (Whitespace
adapter), the Delivery module with five destination types, IaC, CI/CD, tests, runbooks.

**Out of scope now, must not be precluded:** PartnerOutbound workloads; partner Service Bus sources.

**Regulatory frame** (embed throughout; do not bolt on):

- **SYSC 9** record keeping: the immutable `records` blob is the record; destinations hold working copies.
- **SYSC 15A** operational resilience: the manual portal process is the documented fallback; runbook-driven
  recovery; impact tolerance input in §25.
- **UK GDPR** Arts 5, 17, 25, 32: submissions contain personal data and possibly special-category data
  (e.g. A&H, medical malpractice, personal accident). Every document and audit row carries
  `DataClassification`. No document content in logs, ever. No insured names in messages, telemetry, emails,
  or logs at Information level or above.
- **SMCR**: every automated action is attributable to a workload, run and configuration snapshot; every
  manual action (retry, replay, backfill) to an operator's Entra object ID.
- **Outsourcing / Art 28**: routings to external destinations require a DPIA entry and a processor
  contract; they are flagged `IsExternal`.

---

## 2. Engineering principles (non-negotiable)

- **Managed identity by default.** No keyed connection strings, no SAS in config, no client secrets in app
  settings. Key Vault references only for genuinely unavoidable third-party credentials, and never for
  Azure-to-Azure auth.
- **Structured failure taxonomy (§13).** Every failure has a `ReasonCode` with a `Classification`
  (`Permanent` | `Transient`) and a `Scope` (`Item` | `Destination` | `Run`). Activities **return**
  permanent failures as `OperationResult<T>` and **throw** only `TransientFailureException`, so Durable retry
  policies never retry a permanent failure.
- **Idempotency everywhere.** Deterministic identifiers (§3.3); SQL unique constraints as the backstop;
  `If-None-Match: *` on record writes; topic duplicate detection.
- **Change identity ≠ content identity.** The partner revision decides *whether something changed*.
  SHA-256 of the bytes is integrity evidence and the content address of the record. Never use filename or
  timestamp as identity.
- **Explicit content type** on every storage write. Never rely on defaults.
- **Stream, never buffer.** Document bytes are never fully materialised in memory, passed as function
  arguments, serialised into orchestration state, or logged. Pass paths and hex hashes. A 500 MB file flows
  with bounded memory (~8 MiB per transfer).
- **Configuration split.**
  - *Business configuration* (workloads, schedules, routings, partner policies) lives in SQL, deployed as
    code (§7.5).
  - *Platform configuration* uses `IOptions<T>` with `ValidateDataAnnotations().ValidateOnStart()`.
- **Code hygiene.** Nullable enabled, `TreatWarningsAsErrors`, `.editorconfig`,
  `Microsoft.CodeAnalysis.NetAnalyzers` at `latest-recommended`, `dotnet format` enforced in CI.
- **Telemetry and notifications never block processing.** Their failures are logged, never propagated.

---

## 3. Target architecture (pre-accepted)

A single **Azure Functions app, .NET isolated worker, Durable Functions**. No other compute.

**Runtime: .NET 10 LTS**, C# 14 (ADR-0001). .NET 8 support ends 10 Nov 2026; do not target `net8.0`.
**Gate:** at Milestone 1, verify .NET 10 isolated-worker support for Azure Functions, the Durable
Functions extension and the chosen hosting plan (§4). If any is unsupported, stop and report options.

```
                  ┌────────────── Function app: Apollo.Dts (Durable; Azure Storage task hub) ──────────────┐
Timer (5 min) ───►│ DispatchDueWorkloads ─ evaluates WorkloadSchedules ─► RunDiscovery(workloadId, slot)    │
HTTP (Entra) ────►│ StartManualRun / StartBackfill / RetryFailedDocuments / ReplayFailedDeliveries / status │
                  │                                                                                         │
                  │ RunDiscovery: BeginRun ─ ResolveWatermark ─ EnumerateChangedRisks                        │
                  │   └ fan-out IngestRisk (sub-orchestration per partner risk, throttled)                  │
                  │       PlanRiskDocuments ─► FetchToStaging ─► [ExpandArchive] ─► PromoteToRecords         │
                  │       ─► PublishRiskDelivery                                                             │
                  │   └ FinaliseRun (commits watermark only on clean enumeration)                            │
                  └─────────┬──────────────────────────────────────────────────────────────┬────────────────┘
       APIM (MI-auth)       │                                                              ▼
                            ▼                                    Service Bus topic dts-risk-delivery
                  Whitespace REST API                            (existing shared namespace; dup-detect ON)
                                                                          └─ subscription sub-delivery
                  ┌────────────────────────────────────────────────────────┴────────────────────────────────┐
                  │ ReceiveDeliveryRequest (SB) ─ validate envelope ─ start RunDelivery("dlv-{MessageId}")   │
                  │   ─ complete message                                                                     │
                  │ RunDelivery: PrepareDelivery ─ destinations in parallel, documents sequential per dest   │
                  │   DeliverDocument → IDocumentDestination (keyed): BlobStorage | AzureFileShare |          │
                  │                      SharePointSite | SftpSite | NetworkShareDrive                        │
                  │   ─ FinaliseDelivery ─ telemetry ─ NotifyOwningTeam (ACS email, non-blocking)             │
                  └───────────────────────────────────────────────────────────────────────────────────────────┘
Storage: st…rt (host + task hub) │ st…rec (staging + records) │ st…fs (Azure Files) │ Azure SQL (Entra-only)
```

**Explicitly excluded (do not add back):**

- **Logic Apps.** One runtime only.
- **Event Grid.** All eventing is Service Bus.
- **Malware-scanning step.** Upstream gateway scanning is relied upon (ASM-011); endpoint AV on the VM is
  defence in depth.
- **Custom agents, Windows services, or VM-hosted code.**
- **SMB/UNC writes from the Function.** The sandbox blocks ports 445/137–139; `WNetAddConnection2` is
  blocked; managed identity cannot authenticate SMB. Do not attempt `FileStream` on UNC paths.
- **Binding Service Bus triggers to `string`.**
- **Per-sink subscriptions.** A single `sub-delivery` subscription; routing is data-driven.

### 3.1 Durable Functions constraints (enforce in review and tests)

- **Deterministic orchestrators.** Use `context.CurrentUtcDateTime`, never `DateTime.UtcNow`. No I/O, no
  `Guid.NewGuid()`, no randomness, no configuration reads, no `ILogger` except
  `CreateReplaySafeLogger`.
- **References, not bytes.** Orchestration inputs and outputs are serialised into the task hub: pass IDs,
  paths and hashes only. Large lists (enumeration results) are persisted to SQL and only IDs travel.
- **No dead-letter queue in Durable.** When retries are exhausted, the orchestrator catches
  `TaskFailedException`, records `Failed` plus a reason code in SQL, and returns so siblings continue.
  Retry endpoints replay from SQL state.
- **Deployments.** Changing an orchestrator while instances are in flight causes replay divergence. Use a
  deployment window outside 06:00–18:00 UK weekdays; the pipeline drain check blocks deploys while any
  instance is Running (§19); record an orchestration-versioning strategy in an ADR.
- **Central retry policies.** Define them in one `RetryPolicies` class:
  - `Sql`: 5 attempts, 2 s first interval, backoff ×2, max 30 s;
  - `PartnerApi`: 6 attempts, 5 s, ×2, max 2 min;
  - `Download`: 4 attempts, 30 s, ×2, max 5 min;
  - `Storage`: 5 attempts, 2 s, ×2, max 1 min;
  - `ServiceBus`: 5 attempts, 2 s, ×2, max 1 min;
  - `ForDestination(type)`: per-destination values from options.

### 3.2 Task hub backend: classic Azure Storage (pre-accepted)

Mature, diagnosable, no extra cost, and nowhere near its throughput limits. Durable Task Scheduler is a
future option: record the comparison in an ADR, noting that **orchestration history does not migrate
between backends** (switching is a drain-and-cutover). Isolate the task hub in `st<name>rt`, never in the
records account.

### 3.3 Deterministic identifiers (pre-accepted)

| Thing | Identifier |
|---|---|
| Scheduled discovery instance | `disc-{workloadId}-{slotUtc:yyyyMMddHHmm}` |
| Manual / backfill instance | `man-{workloadId}-{guid:N}` / `bf-{workloadId}-{guid:N}`; the GUID is generated in the HTTP trigger, never in an orchestrator |
| Risk sub-orchestration | `{parentInstanceId}:{partnerExternalId}` |
| Topic `MessageId` | `{runGuid:N}-{riskId}`; operator replays append `-r{n}` (never reuse inside the dup-detection window) |
| Delivery instance | `dlv-{MessageId}` |
| Correlation ID | `{discoveryInstanceId}/{partnerExternalId}[/{documentVersionId}]` |
| Staging blob | `staging/{runGuid:N}/{documentVersionId}`; archive entries `staging/{runGuid:N}/{parentId}.x/{index:D3}` |
| Record blob | `records/{partnerId}/{partnerExternalId}/{sha256Hex}{ext}` (content-addressed) |

---

## 4. Resource inventory

**Provision fresh (Bicep):**

| Resource | Notes |
|---|---|
| Function app | .NET 10 isolated. **Flex Consumption** if it supports Durable + .NET 10 + VNet integration in the region (verify; otherwise **Elastic Premium EP1**, ADR). System-assigned MI. VNet integration. `httpsOnly`, FTPS disabled, remote debugging off, public inbound disabled. |
| Storage `st<name>rt` | Host storage + task hub. No public access, TLS 1.2, shared key disabled. |
| Storage `st<name>rec` | `staging` + `records` containers. Versioning ON. **Unlocked** time-based immutability on `records`. Lifecycle: delete `staging` blobs after `StagingRetentionDays`. Shared key disabled. |
| Storage `st<name>fs` | Azure Files share for the underwriters' drive (build prompt v2 §6.6). Separate account because the VM mount may need identity-based or key auth. Private endpoint on file service. |
| Azure SQL Database | Serverless GP, auto-pause, **Entra-only auth**, admin = Entra group, zone redundancy per environment. |
| Service Bus entities | Topic `dts-risk-delivery` (`requiresDuplicateDetection: true`, window `PT6H`, TTL `P14D`; duplicate detection is **immutable after creation**). Subscription `sub-delivery` (`lockDuration: PT1M`, `maxDeliveryCount: 10`, `requiresSession: false`, dead-letter on expiry and filter exceptions). **On the existing shared namespace only.** |
| Azure Communication Services | Email for team notifications; MI-authenticated sender; domain per §25. |
| NAT gateway | **Only if** an SFTP destination or partner requires IP allow-listing (ASM-008). Parameter-gated. |
| Private endpoints + DNS | Blob, File, SQL, Service Bus (requires Premium; verify tier). |
| Diagnostics, alerts, workbook | Into the existing Log Analytics workspace. |
| RBAC | §15.3. |

**Reuse (reference by resource ID, never create):** APIM, Service Bus namespace, Key Vault,
Application Insights + Log Analytics, the destination Azure VM, VNet/subnets, Storage Sync Service (if a
NetworkShareDrive routing exists), the shared action group.

---

## 5. Architecture style and repository layout

**Vertical slice architecture** with light Clean Architecture discipline per slice. Organise by feature.
There is no global `Services/`, `Repositories/` or `Models/` folder.

```
/src
  /Apollo.Dts.Host                          Program.cs (DI composition), host.json, local.settings.sample.json
  /Apollo.Dts.Contracts                     Topic message contracts + JSON source-gen context. NO logic.
  /Apollo.Dts.SharedKernel                  Dependency-light primitives only:
      FailureTaxonomy/  ReasonCode, Classification, FailureScope, OperationResult<T>, TransientFailureException
      Paths/            PathBuilder, PathSanitiser, PathBudget, ContainmentGuard
      FileTypes/        FileSignature, FileTypeRules, FileTypeVerdict
      Hashing/          HashingReadStream, HexHash
      Classification/   DataClassification (ranked)
      Correlation/      CorrelationId, telemetry initialiser contract
      Time/             PartnerTimestamp parser (both partner formats)
      Options/          validation conventions
  /Apollo.Dts.Modules.Discovery
      /Ports            IPartnerDocumentSource.cs (+ DTOs)
      /Partners/Whitespace   adapter, DTOs, WhitespaceIdParser, SummaryPager, ExportStemMapper
      /Features
        /DispatchDueWorkloads   Trigger.cs (timer), Handler.cs, ScheduleEvaluator.cs, Sql.cs
        /StartManualRun         Trigger.cs (HTTP), Handler.cs
        /StartBackfill          Trigger.cs (HTTP), Handler.cs
        /RunDiscovery           Orchestrator.cs
        /BeginRun               Activity.cs, Handler.cs, Sql.cs
        /ResolveWatermark       Activity.cs, Handler.cs, Sql.cs
        /EnumerateChangedRisks  Activity.cs, Handler.cs, Sql.cs
        /IngestRisk             Orchestrator.cs (sub-orchestration)
        /PlanRiskDocuments      Activity.cs, Handler.cs, QualificationPolicy.cs, Sql.cs
        /FetchToStaging         Activity.cs, Handler.cs, Sql.cs
        /ExpandArchive          Activity.cs, Handler.cs, ArchiveEntryName.cs, Sql.cs
        /PromoteToRecords       Activity.cs, Handler.cs, Sql.cs
        /PublishRiskDelivery    Activity.cs, Handler.cs, Sql.cs
        /FinaliseRun            Activity.cs, Handler.cs, Sql.cs
        /SweepStaleRuns         Trigger.cs (timer), Handler.cs, Sql.cs
        /RetryFailedDocuments   Trigger.cs (HTTP), Handler.cs, Sql.cs
        /GetRunStatus           Trigger.cs (HTTP), Handler.cs, Sql.cs
  /Apollo.Dts.Modules.Delivery
      /Ports            IDocumentDestination.cs, IRecordSource.cs (+ DTOs)
      /Destinations/BlobStorage | AzureFileShare | SharePointSite | SftpSite | NetworkShareDrive
      /Features
        /ReceiveDeliveryRequest Trigger.cs (SB), Handler.cs, EnvelopeValidator.cs
        /RunDelivery            Orchestrator.cs
        /PrepareDelivery        Activity.cs, Handler.cs, Sql.cs
        /DeliverDocument        Activity.cs, Handler.cs, TargetPathResolver.cs, Sql.cs
        /FinaliseDelivery       Activity.cs, Handler.cs, Sql.cs
        /NotifyOwningTeam       Activity.cs, Handler.cs, EmailComposer.cs
        /ReconcileDeliveries    Trigger.cs (timer), Handler.cs, Sql.cs
        /ReplayFailedDeliveries Trigger.cs (HTTP), Handler.cs, Sql.cs
        /GetDeliveryStatus      Trigger.cs (HTTP), Handler.cs, Sql.cs
  /Apollo.Dts.Database                      SDK-style SQL project (Microsoft.Build.Sql) → DACPAC
/tests
  /Apollo.Dts.ArchitectureTests
  /Apollo.Dts.UnitTests                     mirrors feature folders exactly
  /Apollo.Dts.IntegrationTests              Testcontainers (SQL Server, Azurite) + WireMock.Net
  /Apollo.Dts.E2E                           Reqnroll + isolated Service Bus namespace
/infra        main.bicep, /modules, /env (dev|uat|prd .bicepparam)
/pipelines    Azure DevOps YAML (§19)
/config       workload config-as-code JSON + JSON schemas (§7.5)
/docs         build-prompt.md, adr/, architecture.md, assumptions.md, environment-inputs.md, runbook.md,
              data-protection.md, threat-model.md, schemas/
```

Target `net10.0` (subject to the §3 gate), central package management (`Directory.Packages.props`),
`Directory.Build.props` for shared analyser and nullable settings.

**Package guidance.**

- Pin the latest stable versions verified at build time; do not guess version numbers.
- Test stack: NUnit, NSubstitute, **Shouldly** (not FluentAssertions v8+, which needs a commercial licence
  for commercial use), ArchUnitNET or NetArchTest, WireMock.Net, Testcontainers, Reqnroll.
- HTTP resilience: `Microsoft.Extensions.Http.Resilience`.
- Data access: Dapper (ADR-0010) with `Microsoft.Data.SqlClient` and `Authentication=Active Directory Default`.

### 5.1 Slice rules (enforced by architecture tests)

1. A slice owns its request/response types, validation and data access. Duplication is acceptable;
   coupling is not.
2. No slice references another slice. Cross-slice flow goes through orchestrators or `Contracts`.
3. Modules never reference each other. Discovery and Delivery communicate only through
   `Apollo.Dts.Contracts`.
4. `SharedKernel` references no module, no `Contracts`, and no Azure SDK.
5. Triggers and activities are thin: bind, deserialise, call the handler, map the result to a disposition.
   Handlers take plain inputs and return `OperationResult<T>` with no Durable or Functions types.
6. Handlers depend on ports (interfaces), never concrete SDK clients.
7. Tests mirror features. A feature without tests is incomplete.
8. No MediatR. Register handlers directly.
9. Partner adapters (`Discovery/Partners/{Partner}`) may reference only Discovery `Ports` and `SharedKernel`;
   never another partner, never `Features`.
10. Destinations (`Delivery/Destinations/{Type}`) may reference only Delivery `Ports` and `SharedKernel`;
    never another destination, never `Features`.
11. Ports are resolved by key through .NET keyed DI: partners by `PartnerId`, destinations by
    `DestinationType`.

---

## 6. Partner: Whitespace

### 6.1 Evidence (published OpenAPI, "last update 29 May 2025"; unverified until Milestone 0)

**Identifiers**

- **RootID** identifies the whole slip across all stages: 38 chars, starts `IC`
  (e.g. `ICF4D673E7-43BF-4EC1-AFBF-E640A39C9223`).
- **riskID / docID / placingID** identify a specific instance: RootID + `::` + further segments
  (e.g. `IC…::FO::WHITESAILS::MARINE`, `IC…::QR2`, `IC…::SIGNED::WHITESAILS::MARINE`,
  `IC…::MUD84FE66A-…::UQ1`).

**Environments and auth**

- Servers: Sandbox `https://sandbox.whitespace.co.uk/`, Tess, Beta, Staging; production
  `https://www.whitespaceplatform.com`.
- Auth: HTTP bearer (JWT). How the token is obtained is unknown (ASM-006).

**`GET /api/summary`**

- Returns batches of 60 `RWRiskSummary` objects, most recently changed first.
- Paging uses query params `last` (rootID of the last item returned) and `from` (date of the last item
  returned). **There is no "changed since" filter**; `from`/`last` form a keyset cursor.
- Each summary has `_id` = `RWRiskSummary::{rootID}::{channel}`, so the **same rootID can appear once per
  channel**. It also has `rootID`, `updatedAt`, `filters[]`, `actions[]` and `docs[]`.
- `docs[]` contains typed sub-documents:
  - `RWPlacing`: `id`, `rev` (format `N-hex`, N increments), `status` (QuotationRequest,
    QuotedByUnderwriter, FirmOrder, FirmOrderDeclined, FirmOrderWithdrawn, Signed, Marketed Only, …),
    `umr`, `insuredName`, `inceptionDate` (Unix seconds), `createdAt`, `updatedAt`, `channels[]`.
  - `RWAttachmentCollection`: `id` = `{rootID}::ATCH`, `count`, `digests` (map of `sha1-<base64>` →
    uploader), `updatedAt`.
  - Others (`RWComment`, `RWWrittenLineSet`, `RWSignedLineSet`, `RWLineGuidanceSet`, `RWRiskOwner`,
    `RWEndorsementFollower`) carry no documents for DTS.
- Sample data **reuses UMRs across different rootIDs**, so UMR is not unique.

**Attachments**

- `GET /api/attachments/{rootID}` returns attachment metadata: `attachedAt`, `attachedByUser`,
  `attachmentName`, `channels[]`, `content_type` (sometimes `application/octet-stream` even for a PNG),
  `digest` (`sha1-<base64>`), `identifier` (`A-…`), `length`, `parentDocID`, `version`.
- `GET /api/attachments/{parentDocID}/{identifier}` returns raw attachment bytes (not JSON).

**Export**

- `POST /export/pdf/{riskID}` takes a JSON layout-options body and returns a PDF of the contract, **or a zip
  containing each version if the risk is verticalised**.

**Timestamps** appear as `YYYY-MM-DD hh:mm:ss` with no offset, and sometimes as ISO-8601 `…Z`. Parse both;
the zone is ASM-015.

**Future outbound (for reference only)**: quoting and binding operations exist (e.g. `quoteOnRequest`,
`saveQuoteDetails`, `markAsIndicative`), as does `POST /api/attachbyunderwriter/…`.

### 6.2 Port: `IPartnerDocumentSource`

```csharp
public interface IPartnerDocumentSource
{
    string PartnerId { get; }

    // Newest-first pages; the caller controls the stop condition.
    IAsyncEnumerable<PartnerChangePage> GetChangePagesAsync(PartnerChangeQuery query, CancellationToken ct);

    // Given persisted summary detail + known DB state, return candidate documents (no downloads).
    Task<PartnerRiskPlan> PlanRiskAsync(PartnerRiskPlanRequest request, CancellationToken ct);

    // Opens the content stream. Never buffers. Caller disposes.
    Task<PartnerContent> OpenDocumentAsync(PartnerDocumentRef document, CancellationToken ct);
}

public sealed record PartnerContent(
    Stream Content, string? DeclaredContentType, long? DeclaredLength, string? SuggestedFileName) : IAsyncDisposable;
```

- All HTTP goes to `Apim:BaseUrl` + `Partners.ApimApiBasePath`, with a bearer token for `Apim:TokenScope`
  from `DefaultAzureCredential`. **The partner credential never reaches the Function** (§15.2).
- HTTP classification:
  - 401 → `PARTNER_UNAUTHORISED` (Permanent, Scope Run);
  - 403 → `PARTNER_FORBIDDEN` (Permanent, Item);
  - 404 → `PARTNER_NOT_FOUND` (Permanent, Item);
  - 429 → `PARTNER_THROTTLED` (Transient; honour `Retry-After`);
  - 5xx, timeout, `IOException` mid-stream → `PARTNER_UNAVAILABLE` / `PARTNER_TIMEOUT` (Transient).
- Downloads use `HttpCompletionOption.ResponseHeadersRead`.
- If a download URL ever arrives in a payload, validate its host against an allow-list before fetching
  (`DOWNLOAD_HOST_NOT_ALLOWED`, SSRF guard).

### 6.3 Qualification rules (Whitespace)

- **Relevance filter.** Ignore a summary whose only changes since `from` are in non-document sub-document
  types. Relevant means an `RWPlacing.updatedAt` or an `RWAttachmentCollection.updatedAt` at or after `from`,
  or a risk not yet in SQL.
- **Scope filter.** A summary is in scope only if its channels intersect `Workloads.PartnerScopeCsv`
  (information barrier; ASM-022). Out-of-scope summaries are recorded as `OutOfScope`.
- **Contract exports.** A `RWPlacing` qualifies when its `status` is in
  `SourceSettings.exportPlacingStatuses` and `(DocumentKey = id, PartnerRevision = rev)` is not in
  `DocumentVersions`.
- **Attachments.** Call `GET /api/attachments/{rootID}` only if the risk is new or its
  `RWAttachmentCollection.updatedAt ≥ from`. An attachment qualifies when
  `(DocumentKey = identifier, PartnerRevision = "{version}|{digest}")` is new (ASM-002).
- **Delivery status plays no part in discovery.** `DocumentDeliveries` is never consulted here; a
  delivery failure is replayed by Delivery, not re-downloaded.
- **Export identity.** Change identity for exports is `rev`, never SHA-256 (ASM-018: rendered PDFs are
  presumed non-deterministic).

### 6.4 Delivered filename stems

**Exports.** Locate the first `::`-separated segment matching `^(QR|UQ|FOD|FOW|FO|SIGNED|M)(\d*)$`.

- Label mapping: QR → `QuoteRequest`, UQ → `UnderwriterQuote`, FOD → `FirmOrderDeclined`,
  FOW → `FirmOrderWithdrawn`, FO → `FirmOrder`, SIGNED → `Signed`, M → `MarketedOnly`.
- Stem = Label + digits + (`-` + remaining segments joined by `-`, if any).
- Examples: `::QR2` → `QuoteRequest2`; `::FO::WHITESAILS::MARINE` → `FirmOrder-WHITESAILS-MARINE`;
  `::MUD84…::UQ1` → `UnderwriterQuote1`.
- If no segment matches: `Contract-{first 8 hex of SHA-256(PartnerDocumentId)}`.

**Attachments.** Stem = sanitised `attachmentName` without extension. If the stem collides within the risk,
append `-{identifier chars 3–10}`.

**Archive entries.** `{parentStem}-{sanitised entry stem}`.

**Final name.** `{stem}_v{VersionNo:000}{ext}`. `UX_DV_DeliveredName` is the backstop: on a unique
violation, re-derive with a disambiguator and retry once, else fail with `DELIVERED_NAME_CONFLICT`.

Unit-test the mapper with every ID in the §6.1 sample data.

### 6.5 WireMock fixtures

Build initial fixtures from the OpenAPI examples. Milestone 0 replaces them with scrubbed sandbox captures
(no real insured names; synthetic PDFs, zips and XLSX). Fixtures must cover:

- multi-page summary walks crossing the watermark;
- duplicate rootIDs across channels;
- PDF and zip export responses;
- octet-stream attachments;
- 429 with `Retry-After`;
- a mid-stream connection drop;
- a lying `Content-Length`.

---

## 7. Data model (SQL project → DACPAC)

### 7.1 DDL (implement verbatim; changes require an ADR)

```sql
CREATE SCHEMA dts;
GO
CREATE TABLE dts.DataClassifications (
  Code varchar(30) NOT NULL CONSTRAINT PK_DataClassifications PRIMARY KEY,
  [Rank] tinyint NOT NULL CONSTRAINT UQ_DataClassifications_Rank UNIQUE,
  Description nvarchar(200) NOT NULL
);
-- Seed: Internal(10), Confidential(20), Confidential-PersonalData(30), Confidential-SpecialCategory(40)

CREATE TABLE dts.NonWorkingDays (
  Id int IDENTITY CONSTRAINT PK_NonWorkingDays PRIMARY KEY,
  [Date] date NOT NULL, Region varchar(30) NOT NULL, Description nvarchar(100) NOT NULL,
  CONSTRAINT UQ_NonWorkingDays UNIQUE ([Date], Region)
);

CREATE TABLE dts.Partners (
  Id int IDENTITY CONSTRAINT PK_Partners PRIMARY KEY,
  Code varchar(30) NOT NULL CONSTRAINT UQ_Partners_Code UNIQUE,
  Name nvarchar(100) NOT NULL,
  ApimApiBasePath varchar(200) NULL,
  TimestampTimeZoneId varchar(64) NOT NULL CONSTRAINT DF_Partners_Tz DEFAULT 'UTC',
  MaxFileBytes bigint NOT NULL,
  AllowedExtensionsCsv varchar(200) NOT NULL,
  RateLimitPerMinute int NOT NULL,
  IsEnabled bit NOT NULL CONSTRAINT DF_Partners_Enabled DEFAULT 1,
  ValidFrom datetime2(3) GENERATED ALWAYS AS ROW START NOT NULL,
  ValidTo   datetime2(3) GENERATED ALWAYS AS ROW END   NOT NULL,
  PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo)
) WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dts.PartnersHistory));

CREATE TABLE dts.Workloads (
  Id int IDENTITY CONSTRAINT PK_Workloads PRIMARY KEY,
  Code varchar(50) NOT NULL CONSTRAINT UQ_Workloads_Code UNIQUE,
  Name nvarchar(150) NOT NULL,
  Description nvarchar(500) NULL,
  OwningTeam nvarchar(100) NOT NULL,
  AccountableRole nvarchar(100) NOT NULL,
  PartnerId int NOT NULL CONSTRAINT FK_Workloads_Partners REFERENCES dts.Partners(Id),
  WorkloadType varchar(30) NOT NULL CONSTRAINT CK_Workloads_Type
    CHECK (WorkloadType IN ('PartnerInbound','PartnerOutbound','InternalTransfer')),
  DocSourceType varchar(30) NOT NULL CONSTRAINT CK_Workloads_Source
    CHECK (DocSourceType IN ('PartnerApi','BlobStorage','SftpSite','SharePointSite','NetworkShareDrive','AzureFileShare')),
  SourceSettingsJson nvarchar(max) NULL CONSTRAINT CK_Workloads_SourceJson
    CHECK (SourceSettingsJson IS NULL OR ISJSON(SourceSettingsJson) = 1),
  PartnerScopeCsv nvarchar(500) NULL,
  DefaultDataClassification varchar(30) NOT NULL CONSTRAINT FK_Workloads_Class REFERENCES dts.DataClassifications(Code),
  InitialWatermarkUtc datetime2(3) NOT NULL,
  OverlapWindowMinutes int NOT NULL CONSTRAINT DF_Workloads_Overlap DEFAULT 30,
  MaxPagesPerRun int NOT NULL CONSTRAINT DF_Workloads_Pages DEFAULT 50,
  MaxConcurrentRisks int NOT NULL CONSTRAINT DF_Workloads_Conc DEFAULT 4,
  MaxRunDurationMinutes int NOT NULL CONSTRAINT DF_Workloads_MaxDur DEFAULT 50,
  IsEnabled bit NOT NULL CONSTRAINT DF_Workloads_Enabled DEFAULT 0,
  IsPaused bit NOT NULL CONSTRAINT DF_Workloads_Paused DEFAULT 0,
  EnableNotification bit NOT NULL CONSTRAINT DF_Workloads_Notify DEFAULT 0,
  NotifyOnFailureOnly bit NOT NULL CONSTRAINT DF_Workloads_NotifyFail DEFAULT 0,
  NotificationEmailAddress varchar(254) NULL,
  ValidFrom datetime2(3) GENERATED ALWAYS AS ROW START NOT NULL,
  ValidTo   datetime2(3) GENERATED ALWAYS AS ROW END   NOT NULL,
  PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo),
  CONSTRAINT CK_Workloads_Notification CHECK (EnableNotification = 0 OR NotificationEmailAddress IS NOT NULL),
  CONSTRAINT CK_Workloads_Limits CHECK (MaxConcurrentRisks BETWEEN 1 AND 16
    AND OverlapWindowMinutes BETWEEN 0 AND 1440 AND MaxPagesPerRun BETWEEN 1 AND 1000)
) WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dts.WorkloadsHistory));

CREATE TABLE dts.WorkloadRuntimeState (
  WorkloadId int NOT NULL CONSTRAINT PK_WorkloadRuntimeState PRIMARY KEY
    CONSTRAINT FK_WRS_Workloads REFERENCES dts.Workloads(Id),
  CommittedWatermarkUtc datetime2(3) NULL,
  LastStatus varchar(25) NULL CONSTRAINT CK_WRS_Status
    CHECK (LastStatus IN ('Running','Completed','CompletedWithFailures','Failed','Abandoned','Skipped')),
  LastRunStartedUtc datetime2(3) NULL,
  LastRunCompletedUtc datetime2(3) NULL,
  LastSuccessfulRunUtc datetime2(3) NULL,
  LastOrchestrationRunId bigint NULL,
  RowVer rowversion
);

CREATE TABLE dts.WorkloadSchedules (
  Id int IDENTITY CONSTRAINT PK_WorkloadSchedules PRIMARY KEY,
  WorkloadId int NOT NULL CONSTRAINT FK_WSch_Workloads REFERENCES dts.Workloads(Id),
  Name nvarchar(100) NOT NULL,
  DaysOfWeekMask tinyint NOT NULL CONSTRAINT CK_WSch_Days CHECK (DaysOfWeekMask BETWEEN 1 AND 127),
  WindowStartTime time(0) NOT NULL,
  WindowEndTime time(0) NOT NULL,
  IntervalHours decimal(5,2) NULL CONSTRAINT CK_WSch_Interval CHECK (IntervalHours IS NULL OR IntervalHours BETWEEN 0.25 AND 24),
  SpecificTimesCsv varchar(400) NULL,
  TimeZoneId varchar(64) NOT NULL CONSTRAINT DF_WSch_Tz DEFAULT 'Europe/London',
  ExcludeBankHolidays bit NOT NULL CONSTRAINT DF_WSch_BH DEFAULT 1,
  EffectiveFromUtc datetime2(0) NOT NULL,
  EffectiveToUtc datetime2(0) NULL,
  IsEnabled bit NOT NULL CONSTRAINT DF_WSch_Enabled DEFAULT 1,
  ValidFrom datetime2(3) GENERATED ALWAYS AS ROW START NOT NULL,
  ValidTo   datetime2(3) GENERATED ALWAYS AS ROW END   NOT NULL,
  PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo),
  CONSTRAINT UQ_WSch_Name UNIQUE (WorkloadId, Name),
  CONSTRAINT CK_WSch_Window CHECK (WindowEndTime > WindowStartTime),
  CONSTRAINT CK_WSch_Mode CHECK ((IntervalHours IS NOT NULL AND SpecificTimesCsv IS NULL)
                              OR (IntervalHours IS NULL AND SpecificTimesCsv IS NOT NULL))
) WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dts.WorkloadSchedulesHistory));

CREATE TABLE dts.WorkloadDocumentRoutings (
  Id int IDENTITY CONSTRAINT PK_WDR PRIMARY KEY,
  WorkloadId int NOT NULL CONSTRAINT FK_WDR_Workloads REFERENCES dts.Workloads(Id),
  Name nvarchar(100) NOT NULL,
  DestinationType varchar(30) NOT NULL CONSTRAINT CK_WDR_Type
    CHECK (DestinationType IN ('BlobStorage','SftpSite','SharePointSite','NetworkShareDrive','AzureFileShare')),
  IsExternal bit NOT NULL,
  EndpointUri varchar(400) NULL,
  ContainerOrShareName nvarchar(100) NULL,
  RootPath nvarchar(260) NOT NULL CONSTRAINT DF_WDR_Root DEFAULT N'',
  SharePointSiteId varchar(200) NULL,
  SharePointDriveId varchar(200) NULL,
  AuthMode varchar(30) NOT NULL CONSTRAINT CK_WDR_Auth
    CHECK (AuthMode IN ('ManagedIdentity','FederatedCrossTenant','KeyVaultSecret','KeyVaultCertificate','SshKeyFromKeyVault')),
  CredentialKeyVaultRef varchar(200) NULL,
  SftpHostKeyFingerprint varchar(200) NULL,
  FolderStrategy varchar(20) NOT NULL CONSTRAINT DF_WDR_Folder DEFAULT 'RiskFolder'
    CONSTRAINT CK_WDR_Folder CHECK (FolderStrategy IN ('RiskFolder','Flat')),
  MaxDataClassification varchar(30) NOT NULL CONSTRAINT FK_WDR_Class REFERENCES dts.DataClassifications(Code),
  IsCritical bit NOT NULL CONSTRAINT DF_WDR_Critical DEFAULT 1,
  MaxConcurrency int NOT NULL CONSTRAINT DF_WDR_Conc DEFAULT 1,
  IsEnabled bit NOT NULL CONSTRAINT DF_WDR_Enabled DEFAULT 0,
  SettingsJson nvarchar(max) NULL CONSTRAINT CK_WDR_Json CHECK (SettingsJson IS NULL OR ISJSON(SettingsJson) = 1),
  ValidFrom datetime2(3) GENERATED ALWAYS AS ROW START NOT NULL,
  ValidTo   datetime2(3) GENERATED ALWAYS AS ROW END   NOT NULL,
  PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo),
  CONSTRAINT UQ_WDR_Name UNIQUE (WorkloadId, Name),
  CONSTRAINT CK_WDR_SharePoint CHECK (DestinationType <> 'SharePointSite' OR (SharePointSiteId IS NOT NULL AND SharePointDriveId IS NOT NULL)),
  CONSTRAINT CK_WDR_Sftp CHECK (DestinationType <> 'SftpSite' OR (SftpHostKeyFingerprint IS NOT NULL AND CredentialKeyVaultRef IS NOT NULL)),
  CONSTRAINT CK_WDR_ExternalAuth CHECK (IsExternal = 0 OR AuthMode <> 'ManagedIdentity')
) WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dts.WorkloadDocumentRoutingsHistory));

CREATE TABLE dts.OrchestrationRuns (
  Id bigint IDENTITY CONSTRAINT PK_OrchestrationRuns PRIMARY KEY,
  RunGuid uniqueidentifier NOT NULL CONSTRAINT UQ_OR_RunGuid UNIQUE,
  WorkloadId int NOT NULL CONSTRAINT FK_OR_Workloads REFERENCES dts.Workloads(Id),
  RunKind varchar(20) NOT NULL CONSTRAINT CK_OR_Kind CHECK (RunKind IN ('Discovery','Backfill','Retry')),
  TriggerType varchar(20) NOT NULL CONSTRAINT CK_OR_Trigger CHECK (TriggerType IN ('Schedule','Manual','Backfill','Retry')),
  TriggeredBy nvarchar(128) NOT NULL,
  ScheduledSlotUtc datetime2(0) NULL,
  OrchestrationInstanceId varchar(100) NOT NULL CONSTRAINT UQ_OR_Instance UNIQUE,
  ConfigSnapshotUtc datetime2(3) NOT NULL,
  Status varchar(25) NOT NULL CONSTRAINT CK_OR_Status
    CHECK (Status IN ('Running','Completed','CompletedWithFailures','Failed','Abandoned')),
  StartedUtc datetime2(3) NOT NULL,
  CompletedUtc datetime2(3) NULL,
  WatermarkFromUtc datetime2(3) NOT NULL,
  WatermarkToUtc datetime2(3) NULL,
  EnumerationComplete bit NOT NULL CONSTRAINT DF_OR_EnumComplete DEFAULT 0,
  WatermarkCommitted bit NOT NULL CONSTRAINT DF_OR_WmCommitted DEFAULT 0,
  PagesRead int NULL, RisksSeen int NULL, RisksChanged int NULL,
  DocumentsNew int NULL, DocumentsDuplicate int NULL, DocumentsRejected int NULL, DocumentsFailed int NULL,
  FailureReasonCode varchar(50) NULL
);
CREATE UNIQUE INDEX UX_OR_OneRunningPerWorkload ON dts.OrchestrationRuns(WorkloadId) WHERE Status = 'Running';
CREATE UNIQUE INDEX UX_OR_ScheduledSlot ON dts.OrchestrationRuns(WorkloadId, ScheduledSlotUtc) WHERE ScheduledSlotUtc IS NOT NULL;

CREATE TABLE dts.OrchestrationRunRisks (
  Id bigint IDENTITY CONSTRAINT PK_ORR PRIMARY KEY,
  OrchestrationRunId bigint NOT NULL CONSTRAINT FK_ORR_Runs REFERENCES dts.OrchestrationRuns(Id),
  PartnerExternalId varchar(64) NOT NULL,
  PartnerUpdatedUtc datetime2(3) NOT NULL,
  SummaryDocsJson nvarchar(max) NULL CONSTRAINT CK_ORR_Json CHECK (SummaryDocsJson IS NULL OR ISJSON(SummaryDocsJson) = 1),
  RiskId bigint NULL,
  Outcome varchar(20) NOT NULL CONSTRAINT DF_ORR_Outcome DEFAULT 'Pending'
    CONSTRAINT CK_ORR_Outcome CHECK (Outcome IN ('Pending','NoDocumentChange','OutOfScope','Processed','PartiallyFailed','Failed')),
  ReasonCode varchar(50) NULL,
  CONSTRAINT UQ_ORR UNIQUE (OrchestrationRunId, PartnerExternalId)
);

CREATE TABLE dts.Risks (
  Id bigint IDENTITY CONSTRAINT PK_Risks PRIMARY KEY,
  PartnerId int NOT NULL CONSTRAINT FK_Risks_Partners REFERENCES dts.Partners(Id),
  PartnerExternalId varchar(64) NOT NULL,
  Umr varchar(17) NULL,
  InsuredName nvarchar(200) NULL,
  PlacingStatus varchar(40) NULL,
  InceptionDate date NULL,
  RelativeFolderPath nvarchar(200) NOT NULL,
  FolderYear smallint NOT NULL,
  PartnerLastUpdatedUtc datetime2(3) NOT NULL,
  FirstSeenOrchestrationRunId bigint NOT NULL CONSTRAINT FK_Risks_FirstRun REFERENCES dts.OrchestrationRuns(Id),
  LastSeenOrchestrationRunId bigint NOT NULL CONSTRAINT FK_Risks_LastRun REFERENCES dts.OrchestrationRuns(Id),
  CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_Risks_Created DEFAULT SYSUTCDATETIME(),
  UpdatedUtc datetime2(3) NOT NULL CONSTRAINT DF_Risks_Updated DEFAULT SYSUTCDATETIME(),
  RowVer rowversion,
  CONSTRAINT UQ_Risks_Partner UNIQUE (PartnerId, PartnerExternalId),
  CONSTRAINT UQ_Risks_Folder UNIQUE (PartnerId, RelativeFolderPath)
);

CREATE TABLE dts.DocumentVersions (
  Id bigint IDENTITY CONSTRAINT PK_DV PRIMARY KEY,
  RiskId bigint NOT NULL CONSTRAINT FK_DV_Risks REFERENCES dts.Risks(Id),
  OrchestrationRunId bigint NOT NULL CONSTRAINT FK_DV_Runs REFERENCES dts.OrchestrationRuns(Id),
  DocumentKind varchar(20) NOT NULL CONSTRAINT CK_DV_Kind CHECK (DocumentKind IN ('ContractExport','Attachment','ArchiveEntry')),
  ParentDocumentVersionId bigint NULL CONSTRAINT FK_DV_Parent REFERENCES dts.DocumentVersions(Id),
  PartnerDocumentId varchar(200) NOT NULL,
  PartnerRevision varchar(100) NOT NULL,
  PartnerDigest varchar(100) NULL,
  DocumentKey nvarchar(300) NOT NULL,
  VersionNo int NULL,
  OriginalFileName nvarchar(255) NULL,
  DeliveredFileName nvarchar(255) NULL,
  Sha256 binary(32) NULL,
  SizeBytes bigint NULL,
  DeclaredContentType varchar(150) NULL,
  DetectedFileType varchar(20) NULL,
  ContentType varchar(150) NULL,
  StagingBlobPath nvarchar(400) NULL,
  RecordBlobPath nvarchar(400) NULL,
  PartnerModifiedUtc datetime2(3) NOT NULL,
  InsuredNameAtVersion nvarchar(200) NULL,
  UmrAtVersion varchar(17) NULL,
  PlacingStatusAtVersion varchar(40) NULL,
  DataClassification varchar(30) NOT NULL CONSTRAINT FK_DV_Class REFERENCES dts.DataClassifications(Code),
  Status varchar(20) NOT NULL CONSTRAINT CK_DV_Status CHECK (Status IN
    ('Discovered','Downloaded','Validated','Expanded','Rejected','Duplicate','Promoted','Published','Failed')),
  FailureReasonCode varchar(50) NULL,
  AttemptCount int NOT NULL CONSTRAINT DF_DV_Attempts DEFAULT 0,
  CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_DV_Created DEFAULT SYSUTCDATETIME(),
  UpdatedUtc datetime2(3) NOT NULL CONSTRAINT DF_DV_Updated DEFAULT SYSUTCDATETIME(),
  RowVer rowversion,
  CONSTRAINT UQ_DV_Revision UNIQUE (RiskId, DocumentKey, PartnerRevision)
);
CREATE UNIQUE INDEX UX_DV_VersionNo ON dts.DocumentVersions(RiskId, DocumentKey, VersionNo) WHERE VersionNo IS NOT NULL;
CREATE UNIQUE INDEX UX_DV_Content ON dts.DocumentVersions(RiskId, DocumentKey, Sha256)
  WHERE Sha256 IS NOT NULL AND Status IN ('Promoted','Published');
CREATE UNIQUE INDEX UX_DV_DeliveredName ON dts.DocumentVersions(RiskId, DeliveredFileName) WHERE DeliveredFileName IS NOT NULL;

CREATE TABLE dts.DocumentDeliveries (
  Id bigint IDENTITY CONSTRAINT PK_DD PRIMARY KEY,
  DocumentVersionId bigint NOT NULL CONSTRAINT FK_DD_DV REFERENCES dts.DocumentVersions(Id),
  WorkloadDocumentRoutingId int NOT NULL CONSTRAINT FK_DD_Routing REFERENCES dts.WorkloadDocumentRoutings(Id),
  OrchestrationRunId bigint NOT NULL CONSTRAINT FK_DD_Runs REFERENCES dts.OrchestrationRuns(Id),
  DeliveryInstanceId varchar(150) NULL,
  Status varchar(20) NOT NULL CONSTRAINT CK_DD_Status
    CHECK (Status IN ('Pending','InProgress','Delivered','Duplicate','Failed','Skipped')),
  AttemptCount int NOT NULL CONSTRAINT DF_DD_Attempts DEFAULT 0,
  TargetPath nvarchar(800) NULL,
  TargetETag varchar(100) NULL,
  ReasonCode varchar(50) NULL,
  LastAttemptUtc datetime2(3) NULL,
  DeliveredUtc datetime2(3) NULL,
  CreatedUtc datetime2(3) NOT NULL CONSTRAINT DF_DD_Created DEFAULT SYSUTCDATETIME(),
  RowVer rowversion,
  CONSTRAINT UQ_DD UNIQUE (DocumentVersionId, WorkloadDocumentRoutingId)
);

-- Append-only ledger. NO foreign keys by design: an audit write must never be blocked by referential state.
CREATE TABLE dts.AuditEvents (
  Id bigint IDENTITY CONSTRAINT PK_AuditEvents PRIMARY KEY,
  EventId uniqueidentifier NOT NULL,
  OccurredUtc datetime2(3) NOT NULL,
  EventType varchar(50) NOT NULL,
  WorkloadId int NULL,
  OrchestrationRunId bigint NULL,
  RiskId bigint NULL,
  DocumentVersionId bigint NULL,
  DocumentDeliveryId bigint NULL,
  CorrelationId varchar(150) NOT NULL,
  Actor nvarchar(128) NOT NULL,
  ReasonCode varchar(50) NULL,
  DataClassification varchar(30) NULL,
  Detail nvarchar(2000) NULL
) WITH (LEDGER = ON (APPEND_ONLY = ON));
CREATE INDEX IX_Audit_Run ON dts.AuditEvents(OrchestrationRunId, OccurredUtc);
CREATE INDEX IX_Audit_Risk ON dts.AuditEvents(RiskId, OccurredUtc);
GO
CREATE VIEW dts.vWorkloadOverview AS
SELECT w.Id, w.Code, w.Name, w.OwningTeam, p.Code AS Partner, w.WorkloadType, w.DocSourceType,
       s.LastStatus, s.LastRunStartedUtc, s.LastRunCompletedUtc, s.LastSuccessfulRunUtc, s.CommittedWatermarkUtc,
       w.EnableNotification, w.NotificationEmailAddress, w.IsEnabled, w.IsPaused
FROM dts.Workloads w
JOIN dts.Partners p ON p.Id = w.PartnerId
LEFT JOIN dts.WorkloadRuntimeState s ON s.WorkloadId = w.Id;
```

Also create views for the workbook (§16): `vFailedDocuments`, `vDeliveryState`, `vRiskHistory`
(per-UMR history).

### 7.2 Stored procedures

All application writes go through procedures. No dynamic SQL inside procedures (it breaks ownership
chaining, §7.4).

| Procedure | Semantics |
|---|---|
| `usp_BeginRun` | Inserts `Running`. The unique-index violation from `UX_OR_OneRunningPerWorkload` or `UX_OR_ScheduledSlot` returns `Skipped` + `RUN_ALREADY_ACTIVE`, not an error. Stamps `ConfigSnapshotUtc` = max `ValidFrom` across the workload, its schedules, routings and partner. Upserts `WorkloadRuntimeState`. Writes audit. |
| `usp_ResolveWatermark` | `COALESCE(CommittedWatermarkUtc, InitialWatermarkUtc)` minus `OverlapWindowMinutes`. |
| `usp_RecordEnumeration` | Bulk-inserts `OrchestrationRunRisks` (table-valued parameter); idempotent on `UQ_ORR`. |
| `usp_UpsertRisk` | Insert with a caller-supplied `RelativeFolderPath` (a `UQ_Risks_Folder` violation surfaces as a distinct error so the caller re-derives with a disambiguator). Update refreshes current UMR, name, status, `PartnerLastUpdatedUtc` and `LastSeenOrchestrationRunId`, and **never** `RelativeFolderPath`/`FolderYear`. |
| `usp_RegisterCandidates` | TVP insert of `Discovered` rows; idempotent on `UQ_DV_Revision`; returns the IDs of rows still actionable (`Discovered`, `Downloaded`, `Validated`, or `Failed` with a transient reason). |
| `usp_MarkDownloaded` / `usp_MarkValidated` / `usp_RejectDocument` / `usp_FailDocument` | State transitions with guards; `AttemptCount++`; audit. |
| `usp_RegisterArchiveEntries` | All-or-nothing TVP insert of `ArchiveEntry` children; parent → `Expanded`. |
| `usp_PromoteDocumentVersion` | Verbatim below. |
| `usp_CreatePendingDeliveries` | For each promoted DV × enabled routing of the workload: if the routing classification rank ≥ the DV rank, insert `Pending`; else insert `Skipped` + `DELIVERY_CLASSIFICATION_NOT_PERMITTED`. Idempotent on `UQ_DD`. |
| `usp_MarkPublished` | DV → `Published`. |
| `usp_CompleteRun` | One transaction: counts, status, `WorkloadRuntimeState`, and the **conditional monotonic watermark commit** (§9.5). |
| `usp_ClaimDelivery` | `UPDATE … SET Status='InProgress', AttemptCount+=1, DeliveryInstanceId=@I, LastAttemptUtc=SYSUTCDATETIME() WHERE Id=@Id AND (Status IN ('Pending','Failed') OR (Status='InProgress' AND (DeliveryInstanceId=@I OR LastAttemptUtc < @LeaseExpiry)))`. Returns claimed or current status. |
| `usp_RecordDeliveryOutcome` | `Delivered`/`Duplicate`/`Failed`/`Skipped` + target path + ETag + reason; audit. |
| `usp_SweepStaleRuns` | Runs `Running` beyond `RunStaleAfter` → `Abandoned` + `RUN_ABANDONED_TIMEOUT` (no watermark commit); returns instance IDs for termination. Nulls `SummaryDocsJson` older than `SummaryDetailRetentionDays`. |
| `usp_WriteAudit` | The only insert path into `AuditEvents`. |

```sql
CREATE OR ALTER PROCEDURE dts.usp_PromoteDocumentVersion
  @DocumentVersionId bigint, @RecordBlobPath nvarchar(400),
  @DeliveredFileStem nvarchar(200), @Extension varchar(10)
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;
  BEGIN TRANSACTION;
  DECLARE @RiskId bigint, @Key nvarchar(300), @Sha binary(32), @Status varchar(20), @Ver int;

  SELECT @RiskId = RiskId, @Key = DocumentKey, @Sha = Sha256, @Status = Status, @Ver = VersionNo
  FROM dts.DocumentVersions WITH (UPDLOCK, ROWLOCK) WHERE Id = @DocumentVersionId;

  IF @Status IN ('Promoted','Published','Duplicate')
  BEGIN COMMIT; SELECT @Status AS Outcome, @Ver AS VersionNo; RETURN; END
  IF @Status <> 'Validated' THROW 50001, 'DV_INVALID_STATE', 1;

  IF EXISTS (SELECT 1 FROM dts.DocumentVersions WITH (UPDLOCK, HOLDLOCK)
             WHERE RiskId = @RiskId AND DocumentKey = @Key AND Sha256 = @Sha AND Status IN ('Promoted','Published'))
  BEGIN
    UPDATE dts.DocumentVersions SET Status = 'Duplicate', UpdatedUtc = SYSUTCDATETIME() WHERE Id = @DocumentVersionId;
    COMMIT; SELECT 'Duplicate' AS Outcome, CAST(NULL AS int) AS VersionNo; RETURN;
  END

  SELECT @Ver = ISNULL(MAX(VersionNo), 0) + 1
  FROM dts.DocumentVersions WITH (UPDLOCK, HOLDLOCK)
  WHERE RiskId = @RiskId AND DocumentKey = @Key;

  UPDATE dts.DocumentVersions
     SET VersionNo = @Ver,
         DeliveredFileName = CONCAT(@DeliveredFileStem, N'_v', FORMAT(@Ver, '000'), @Extension),
         RecordBlobPath = @RecordBlobPath, Status = 'Promoted', UpdatedUtc = SYSUTCDATETIME()
   WHERE Id = @DocumentVersionId;
  COMMIT;
  SELECT 'Promoted' AS Outcome, @Ver AS VersionNo;
END
```

### 7.3 Folder allocation

`RelativeFolderPath` = `{FolderYear}/{UMR ?? PartnerExternalId} - {InsuredName}`.

- It is built by `PathBuilder` (§12.3), which sanitises and budgets it.
- `FolderYear` is the UK-local year of first import.
- On a `UQ_Risks_Folder` collision, append ` [{chars 3–10 of PartnerExternalId}]`.
- It is allocated once and never recomputed.
- The partner root folder (e.g. `Whitespace`) comes from `WorkloadDocumentRoutings.RootPath`, not from the
  risk.

### 7.4 SQL security (post-deploy script / pipeline step; Bicep cannot grant in-database roles)

```sql
CREATE ROLE dts_app;
GRANT EXECUTE ON SCHEMA::dts TO dts_app;
GRANT SELECT  ON SCHEMA::dts TO dts_app;
DENY  INSERT, UPDATE, DELETE ON SCHEMA::dts TO dts_app;   -- writes only via procs (ownership chaining)
CREATE ROLE dts_reader;                                     -- workbook / support
GRANT SELECT ON dts.vWorkloadOverview TO dts_reader;        -- + other v* views only
-- CREATE USER [<<FUNCTION_APP_MI_NAME>>] FROM EXTERNAL PROVIDER; ALTER ROLE dts_app ADD MEMBER [...];
```

Humans have no DML on configuration tables in prd.

### 7.5 Configuration as code (pre-accepted)

- `/config/{env}/partners.json`, `workloads.json`, `schedules.json`, `routings.json` are validated against
  JSON Schemas in `/docs/schemas/` during CI.
- They are converted to idempotent `MERGE` statements in the DACPAC post-deploy script.
- The PR review plus the prd environment approval is the four-eyes control over where confidential
  documents go.
- Temporal history provides run-time evidence of every configuration version.
- `SourceSettingsJson` (Whitespace) schema example; `exportOptions` fields are from the partner example
  and subject to ASM-023:

```json
{
  "includeContractExports": true,
  "includeAttachments": true,
  "exportPlacingStatuses": ["QuotationRequest", "QuotedByUnderwriter", "FirmOrder", "Signed"],
  "exportOptions": {
    "exportContract": true,
    "includeSections": ["RiskDetails", "Information", "SecurityDetails", "SubscriptionAgreement",
      "FiscalAndRegulatory", "BrokerRemunerationAndDeductions", "ContractAdministrationAndAdvisory",
      "ContractChanges", "RiskAndEndorsementIdentificationDetails", "Agreement"]
  }
}
```

Invalid configuration at `BeginRun` → run `Failed` with `CONFIG_INVALID`, plus an alert.

---

## 8. Scheduling

- **Dispatcher.** A single timer function `DispatchDueWorkloads`, NCRONTAB from `Dispatcher:Schedule`
  (default `0 */5 * * * *`, UTC). Timer triggers are singletons across instances.
- **Eligibility.** For each workload with `IsEnabled = 1 AND IsPaused = 0` and a partner that is enabled,
  evaluate each enabled schedule with the pure `ScheduleEvaluator`:
  - `DaysOfWeekMask`: Mon=1, Tue=2, Wed=4, Thu=8, Fri=16, Sat=32, Sun=64.
  - Slots are either `WindowStart`, `WindowStart + IntervalHours`, … ≤ `WindowEnd`, **or**
    `SpecificTimesCsv` values inside the window, in the schedule's `TimeZoneId`.
  - Skip dates in `NonWorkingDays` when `ExcludeBankHolidays = 1`. Seed England & Wales bank holidays from
    `https://www.gov.uk/bank-holidays.json` via a pipeline step.
- **DST.**
  - A slot in the spring-forward gap is skipped.
  - An ambiguous autumn slot resolves to its first occurrence (the larger offset, BST).
- **Coalescing.** Only the **latest** due slot at or before now, later than the last dispatched slot
  (`MAX(ScheduledSlotUtc)` from `OrchestrationRuns`) and within `Dispatcher:MaxLateness` (default `PT30M`)
  is dispatched. Missed slots do not queue up.
- **Collision.** Start `RunDiscovery` with instance ID `disc-{workloadId}-{slot:yyyyMMddHHmm}`. An existing
  instance means already dispatched, which is success. `UX_OR_ScheduledSlot` is the SQL backstop.
- **Parsing.** `SpecificTimesCsv` is parsed and validated at load (`HH:mm`, sorted, deduplicated, inside the
  window); invalid → `CONFIG_INVALID`.
- **`SweepStaleRuns`** (timer, every 15 min): calls `usp_SweepStaleRuns`, then
  `DurableTaskClient.TerminateInstanceAsync` for the returned instances.

---

## 9. Discovery functional specification

### 9.1 `RunDiscovery` orchestrator

1. **`BeginRun`** → `RunContext` (run reference plus a frozen configuration snapshot: workload, partner
   policy, source settings). If `Skipped`, return.
2. **`ResolveWatermark`** → `{ FromUtc }`.
3. **`EnumerateChangedRisks`** (§9.2) → `{ IsComplete, WatermarkToUtc, ChangedPartnerExternalIds[] }`.
   On `TaskFailedException`: `FailRun`, no watermark commit, return.
4. **Fan-out** `IngestRisk` per ID, in chunks of `MaxConcurrentRisks`. The sub-orchestrator never throws.
5. **`FinaliseRun`** → `usp_CompleteRun`, telemetry `dts.run.completed`, audit.

### 9.2 `EnumerateChangedRisks`

1. Page `GetChangePagesAsync` newest-first.
2. `WatermarkToUtc` = the partner `updatedAt` of the **first item of page 1** (the partner clock, never
   Azure's).
3. For each summary:
   - if `updatedAt < FromUtc`, stop: enumeration is complete;
   - apply the scope and relevance filters (§6.3);
   - dedupe by rootID.
4. Advance the keyset cursor using the **raw** `from` string and the rootID of the page's last item.
5. Exceeding `MaxPagesPerRun` → `PARTNER_PAGINATION_LIMIT` (Permanent, Scope Run; enumeration incomplete).
6. Persist results via `usp_RecordEnumeration`. `SummaryDocsJson` holds only the fields needed for
   planning: placing `id`/`rev`/`status`/`updatedAt`/`umr`/`insuredName`/`inceptionDate`, and attachment
   collection `updatedAt`/`digests`.
7. Only IDs return to the orchestrator.

Risks updated during the walk move above the cursor. They have `updatedAt > WatermarkToUtc`, so the next
run catches them. **Backfill** runs take explicit `from`/`to`, walk the same way, and never commit the
watermark.

### 9.3 `IngestRisk` sub-orchestrator

1. **`PlanRiskDocuments`** (activity):
   - `usp_UpsertRisk`, with first-time folder allocation;
   - attachments metadata call, if required;
   - qualification (§6.3);
   - `usp_RegisterCandidates` with `DataClassification = DefaultDataClassification` and the `*AtVersion`
     snapshots.
   Returns the actionable DV IDs. Zero IDs → outcome `NoDocumentChange`.
2. **For each candidate, sequentially:**
   - `FetchToStaging` (§10.1);
   - if the response is a zip → `ExpandArchive` (§10.3), and continue with the child IDs;
   - `PromoteToRecords` per validated DV (§9.4).
3. If any DV was promoted → **`PublishRiskDelivery`** (§9.4).
4. Catch `TaskFailedException` per document → `usp_FailDocument` with its reason; continue with siblings.
   Catch at risk level → mark the `OrchestrationRunRisks` outcome `Failed`; return.

### 9.4 Promotion and publish

**`PromoteToRecords`:**

1. Server-side copy staging → `records/{partnerId}/{partnerExternalId}/{sha256Hex}{ext}` with
   `If-None-Match: *`, explicit `ContentType` and metadata (`riskId`, `documentVersionId`, `runGuid`,
   `dataClassification`, `sha256`). A 409 is success, because the path is content-addressed.
2. `usp_PromoteDocumentVersion`.
3. Delete the staging blob.

Staging exists because the hash is unknown until the last byte, and a partial write must never land in an
immutability-protected container.

**`PublishRiskDelivery`:**

1. `usp_CreatePendingDeliveries`.
2. Send one message per risk (§11) with the deterministic `MessageId`.
3. `usp_MarkPublished`.

A Durable retry is safe: the SQL steps are idempotent and the topic drops duplicate `MessageId`s.

### 9.5 Watermark commit rule (exact)

Commit `WatermarkToUtc` **only if** both conditions hold:

- `EnumerationComplete = 1`;
- every registered candidate for the run is terminal: `Published`, `Duplicate`, `Rejected`, `Expanded`,
  or `Failed` recorded in SQL.

The commit is monotonic: `UPDATE … WHERE CommittedWatermarkUtc IS NULL OR CommittedWatermarkUtc < @To`.

Run status:

- `Completed` if nothing failed;
- `CompletedWithFailures` if any DV or risk `Failed` (rejections are reported and alerted separately);
- `Failed` if enumeration or the run itself failed.

The watermark is **never** derived from `MAX()` over `Risks` or `DocumentVersions`. With a newest-first
feed, a partial run would advance past unprocessed risks (ADR-0004).

### 9.6 Ops endpoints (Discovery)

- `StartManualRun`, `StartBackfill`, `RetryFailedDocuments` (by run, risk or reason code), `GetRunStatus`.
- Authorisation per §15.4.
- Retries operate on SQL state: they re-queue `Failed` DVs with transient reason codes into a `Retry` run.

---

## 10. File validation and archives

### 10.1 `FetchToStaging`

- Open the document with `IPartnerDocumentSource.OpenDocumentAsync`.
- A declared length above `Partners.MaxFileBytes` → `FILE_TOO_LARGE` before reading.
- Wrap the stream in `HashingReadStream`:
  - SHA-256 always; SHA-1 only when a partner digest exists (suppress CA5350 with a justification: SHA-1
    verifies the partner digest only);
  - captures the first 16 bytes;
  - counts bytes and **throws `FileTooLargeException` mid-stream** when the cap is exceeded.
- Upload to `staging/{runGuid:N}/{dvId}` with `MaximumTransferSize = 4 MiB`, `MaximumConcurrency = 1`,
  provisional `ContentType = application/octet-stream`. Staging **overwrites**; it is scratch space and
  retries must succeed.
- Validate (§10.2). On rejection, delete the staging blob and call `usp_RejectDocument`.
- Record via `usp_MarkDownloaded` then `usp_MarkValidated`, with SHA-256, size, detected type and
  canonical content type.
- Return `{ IsArchive, ... }`. Never return bytes.

### 10.2 Validation matrix (every failure is Permanent, Scope Item)

Checks run in order:

1. **Empty file** → `FILE_EMPTY`.
2. **Extension** (from the filename; for exports, **assigned from the magic number** as `.pdf` or `.zip`)
   must be in `Partners.AllowedExtensionsCsv`. Macro-enabled types (`.xlsm`, `.docm`, `.pptm`) are never
   allowed. Failure: `FILE_TYPE_NOT_ALLOWED`.
3. **Magic number** must match the extension's rule. Failure: `MAGIC_NUMBER_MISMATCH`.
   - PDF: `25 50 44 46 2D` at offset 0 (tolerance up to `FileTypes:PdfHeaderTolerance` bytes, default 0).
   - OOXML (`.docx`/`.xlsx`/`.pptx`) and `.zip`: `50 4B 03 04`.
   - OLE compound (`.msg`/`.doc`/`.xls`): `D0 CF 11 E0 A1 B1 1A E1`.
   - PNG: `89 50 4E 47 0D 0A 1A 0A`.
   - JPEG: `FF D8 FF`.
4. **Declared content type**. If present and not generic (`application/octet-stream`,
   `binary/octet-stream`), it must be in the rule's accepted list. Failure: `CONTENT_TYPE_MISMATCH`.
5. **Declared length ≠ bytes read** → `SIZE_MISMATCH`.
6. **Partner digest** (`sha1-<base64>`) ≠ computed → `PARTNER_DIGEST_MISMATCH`.

The canonical `ContentType` written to storage always comes from the rule table, never from the partner.

### 10.3 `ExpandArchive`

- Reopen the staged zip with `BlobClient.OpenReadAsync` (seekable, lazy; 4 MiB buffer).
  **Never** wrap a network stream in `ZipArchive`, because the central directory is at the end.
- Limits (options): `MaxEntries` (200), `MaxTotalBytes`, `MaxCompressionRatio` (100). The per-entry cap is
  `min(MaxFileBytes, max(CompressedLength, 1) × MaxCompressionRatio)`, enforced on **actual bytes read**
  (headers can lie).
- Entry names: skip directory records; take the leaf name; reject rooted names, `..`, control characters
  and duplicate leaves → `ARCHIVE_ENTRY_NAME_INVALID` (zip-slip guard).
- Entry types: only `.pdf` inside export archives (ASM-019); nested archives → `ARCHIVE_ENTRY_TYPE_NOT_ALLOWED`.
- Encrypted or corrupt entries (`InvalidDataException`) → `ARCHIVE_UNREADABLE`.
- Any breach rejects the whole archive and deletes the staged children.
- Child identity: `DocumentKey = {parentKey}/{leaf}`, `PartnerRevision` = the parent's. Children are
  registered in one call (`usp_RegisterArchiveEntries`); the parent → `Expanded`.

---

## 11. Topic message contract (schema 2.0, `Apollo.Dts.Contracts`)

UTF-8 JSON, `ContentType = application/json`, System.Text.Json source generation.

```json
{
  "schemaVersion": "2.0",
  "messageType": "RiskDocumentsReadyForDelivery",
  "messageId": "7c1e4b0a9d2f4c7e8a1b3c5d7e9f1a2b-1042",
  "correlationId": "disc-3-202609260900/ICF4D673E7-43BF-4EC1-AFBF-E640A39C9223",
  "workload": { "workloadId": 3, "workloadId": "WS-UW-MARINE-DOC-IMPORT" },
  "run": { "orchestrationRunId": 18234, "runGuid": "7c1e4b0a-9d2f-4c7e-8a1b-3c5d7e9f1a2b",
           "orchestrationInstanceId": "disc-3-202609260900" },
  "partner": { "partnerId": "WHITESPACE" },
  "risk": { "riskId": 1042, "partnerExternalId": "ICF4D673E7-43BF-4EC1-AFBF-E640A39C9223", "umr": "B0999GM2912211559" },
  "source": { "documentSourceType": "BlobStorage",
              "accountUri": "https://<<RECORDS_ACCOUNT>>.blob.core.windows.net", "containerOrShare": "records" },
  "documentVersionIds": [55120, 55121],
  "documents": [
    { "documentVersionId": 55120, "path": "WHITESPACE/ICF4D673E7-…/9f2b…c1.pdf", "sha256": "9f2b…c1",
      "sizeBytes": 18234117, "contentType": "application/pdf", "versionNo": 3 }
  ],
  "dataClassification": "Confidential-PersonalData",
  "publishedUtc": "2026-09-26T08:04:11.532Z"
}
```

- **Application properties:** `messageType`, `schemaVersion`, `workloadId`, `partnerId`,
  `dataClassification`, `correlationId`.
- **No insured names or folder paths in the message**, which persists in DLQs and explorers. SQL is the
  source of truth.
- **Tolerant reader:** validate only consumed fields and ignore unknown ones. An unknown **major** version
  → `CONTRACT_VERSION_UNSUPPORTED` (dead-letter). A missing required field → `CONTRACT_INVALID`
  (dead-letter).

---

## 12. Delivery functional specification

### 12.1 `ReceiveDeliveryRequest` (Service Bus trigger, thin)

- Bind `ServiceBusReceivedMessage` + `ServiceBusMessageActions` + `DurableTaskClient`,
  `AutoCompleteMessages = false`, sessions off.
- Structurally invalid → dead-letter with a reason code and a safe description (no payload echo).
- Otherwise start `RunDelivery` with instance ID `dlv-{MessageId}`. An existing instance is success.
  Complete the message.
- A transient failure while scheduling → abandon.

### 12.2 `RunDelivery` orchestrator

1. **`PrepareDelivery`** checks each of the following. Invalid documents → `Failed` delivery rows with
   `DELIVERY_REFERENCE_INVALID` or `DELIVERY_REFERENCE_INTEGRITY`.
   - the workload exists and is enabled;
   - the risk exists and matches the message;
   - each DV belongs to that risk and is `Promoted` or `Published`;
   - the message `sha256` equals the SQL value;
   - the record blob exists (HEAD request).

   It then selects `DocumentDeliveries` rows in `Pending`/`Failed` for those DVs (**idempotency**:
   `Delivered`/`Duplicate` rows are excluded). Rows whose routing is now disabled → `Skipped` with
   `DELIVERY_DESTINATION_DISABLED`. Work is grouped by routing.
2. **Destinations run in parallel**; within a destination, documents run **sequentially** in `VersionNo`
   order. On `TaskFailedException`, record `Failed`. On a destination-wide reason (`Scope = Destination`),
   stop that destination's loop.
3. **`FinaliseDelivery`** records the risk-level outcome:
   - `Delivered` if everything succeeded;
   - `PartiallyDelivered` if only non-critical routings failed;
   - `Failed` otherwise.
   It writes audit and emits `dts.delivery.completed`.
4. **`NotifyOwningTeam`** (§16.3) runs if enabled. Non-blocking: it catches and logs its own failures.

### 12.3 `DeliverDocument` activity

1. `usp_ClaimDelivery`. If the row is already terminal, return `AlreadyDone`.
2. Re-check the classification ceiling.
3. Resolve the target path:
   - `RiskFolder`: `{RootPath}/{RelativeFolderPath}/{DeliveredFileName}`;
   - `Flat`: `{RootPath}/{UMR}_{DeliveredFileName}`.
4. Sanitise with `PathBuilder` for the destination's rule set:
   - strip `\ / : * ? " < > |`, control characters, leading/trailing spaces and dots;
   - handle reserved names (`CON`, `PRN`, `AUX`, `NUL`, `COM1–9`, `LPT1–9`);
   - SharePoint also rejects `#`, `%`, `~`, leading `~` and `_vti_`;
   - path budget: Windows ~260, SharePoint URL ~400, SFTP from options. Deterministic truncation preserves
     the extension and the `_vNNN` suffix.
5. **Containment check**: ordinal `StartsWith` against the root including its trailing separator; failure
   → `DELIVERY_PATH_ESCAPE`.
6. Resolve `IDocumentDestination` by `DestinationType` and deliver.
7. `usp_RecordDeliveryOutcome`.

### 12.4 Destinations (bytes never buffered)

| Type | Transfer | Auth | Idempotency / atomicity |
|---|---|---|---|
| **BlobStorage** (internal) | Server-side Put Block From URL with OAuth source authorisation (`x-ms-copy-source-authorization`); ~100 MiB blocks; explicit content type and metadata | MI; Storage Blob Data Contributor on the **target container** | `If-None-Match: *`; commit is atomic; on 409 compare stored `sha256` metadata → `Duplicate` or `DELIVERY_TARGET_CONFLICT` |
| **BlobStorage** (external) | As above if cross-tenant source auth works; otherwise streamed upload from `IRecordSource.OpenReadAsync` | `FederatedCrossTenant` (multi-tenant app + MI federated credential) preferred; `KeyVaultSecret` SAS as a fallback with expiry alerting | As above |
| **AzureFileShare** | Preferred: server-side Copy File with a **user-delegation SAS** source (Entra-signed; TTL ≤ 15 min). Fallback: `Create(sizeBytes)` + `UploadAsync` from the blob stream | MI over HTTPS with `x-ms-file-request-intent: backup`; Storage File Data Privileged Contributor on `st<name>fs` only. If the SDK/API cannot do OAuth for Files, **stop and ADR; never fall back to keys** | Create directories segment by segment ("already exists" = success). Write `~{ddId}.partial`, verify size (and hash where exposed), Rename File to the final name, delete temp in `finally`. If the final name exists: match → `Duplicate`, mismatch → `DELIVERY_TARGET_CONFLICT` |
| **SharePointSite** | Microsoft Graph: files < 4 MiB by simple PUT; otherwise an upload session with chunks that are multiples of 320 KiB (use 10 MiB), sequential `Content-Range`, resumable | App-only with **`Sites.Selected`** granted per site (never `Sites.ReadWrite.All`); MI where supported, otherwise a Key Vault certificate | `@microsoft.graph.conflictBehavior = "fail"`; on conflict, verify size/hash → `Duplicate` or `DELIVERY_TARGET_CONFLICT`. Oversize → `SP_FILE_TOO_LARGE`. Site resolution behind `ISharePointTargetResolver` |
| **NetworkShareDrive** | Write to the Azure Files **cloud endpoint** of an Azure File Sync group (as AzureFileShare), then trigger AFS change detection on the target directory. Replicates to the on-premises server over existing connectivity | MI; Files role as above plus the minimal Storage Sync role for change detection | As AzureFileShare. A change-detection failure is logged and alerted (`AFS_CHANGE_DETECTION_FAILED`) but does not fail the delivery. Latency is documented in the runbook (ASM-025) |
| **SftpSite** | SSH.NET streaming upload from `IRecordSource.OpenReadAsync` | `SshKeyFromKeyVault`; **pinned host key** (`SftpHostKeyFingerprint`); mismatch → `SFTP_HOST_KEY_MISMATCH` (Permanent, Destination) | Upload to `.partial` then rename where `SettingsJson.useTempRename` is true. Verification is size-only (record the weakness in an ADR). Verify outbound port 22 from the hosting plan; needs a NAT gateway if the partner allow-lists IPs |

**VM-side configuration for the underwriters' Azure Files drive** (runbook, automated where possible):

- Mount persistently as the existing drive letter.
- Prefer AD DS or Entra Kerberos identity-based SMB auth, preserving per-user NTFS ACLs. Fall back to a Key
  Vault storage key only if the VM's join state requires it (ASM-012), with compensating controls
  documented.
- Migrate existing content with robocopy/AzCopy, remap via Group Policy, and include a rollback step.
- Endpoint AV continues to scan the mounted share; exclude nothing.

### 12.5 Delivery ops

- **`ReconcileDeliveries`** (timer, 15 min): rows `Pending`/`InProgress` older than
  `Delivery:StaleDeliveryAfter` → telemetry `dts.delivery.stale` and an alert.
- **`ReplayFailedDeliveries`** (HTTP; by run, risk, routing or reason): re-publishes a message with
  MessageId suffix `-r{n}`, or starts `RunDelivery` directly with a new instance ID. Refuses rows whose
  claim lease is live.

---

## 13. Failure taxonomy (`SharedKernel/FailureTaxonomy/ReasonCode.cs`)

One enum; every member annotated with its `Classification` and `Scope`, stored as `varchar(50)` text.

| Code | Class | Scope |
|---|---|---|
| `PARTNER_UNAUTHORISED` | Permanent | Run |
| `PARTNER_FORBIDDEN`, `PARTNER_NOT_FOUND`, `PARTNER_RESPONSE_INVALID`, `PARTNER_TIMESTAMP_UNPARSEABLE` | Permanent | Item |
| `PARTNER_THROTTLED`, `PARTNER_UNAVAILABLE`, `PARTNER_TIMEOUT` | Transient | Item |
| `PARTNER_PAGINATION_LIMIT` | Permanent | Run |
| `DOWNLOAD_HOST_NOT_ALLOWED`, `FILE_EMPTY`, `FILE_TOO_LARGE`, `FILE_TYPE_NOT_ALLOWED`, `MAGIC_NUMBER_MISMATCH`, `CONTENT_TYPE_MISMATCH`, `SIZE_MISMATCH`, `PARTNER_DIGEST_MISMATCH` | Permanent | Item |
| `ARCHIVE_TOO_MANY_ENTRIES`, `ARCHIVE_TOO_LARGE`, `ARCHIVE_COMPRESSION_RATIO`, `ARCHIVE_ENTRY_NAME_INVALID`, `ARCHIVE_ENTRY_TYPE_NOT_ALLOWED`, `ARCHIVE_UNREADABLE` | Permanent | Item |
| `DELIVERED_NAME_CONFLICT`, `DV_INVALID_STATE` | Permanent | Item |
| `STORAGE_TRANSIENT`, `SQL_TRANSIENT`, `PUBLISH_TRANSIENT` | Transient | Item |
| `RUN_ALREADY_ACTIVE`, `WORKLOAD_DISABLED`, `WORKLOAD_PAUSED`, `CONFIG_INVALID`, `RUN_ABANDONED_TIMEOUT` | Permanent | Run |
| `CONTRACT_VERSION_UNSUPPORTED`, `CONTRACT_INVALID` | Permanent | Item |
| `DELIVERY_REFERENCE_INVALID`, `DELIVERY_REFERENCE_INTEGRITY`, `DELIVERY_CLASSIFICATION_NOT_PERMITTED`, `DELIVERY_PATH_ESCAPE`, `DELIVERY_TARGET_CONFLICT`, `DELIVERY_TARGET_MISSING`, `SP_FILE_TOO_LARGE` | Permanent | Item |
| `DELIVERY_ACCESS_DENIED`, `DELIVERY_DESTINATION_DISABLED`, `SFTP_HOST_KEY_MISMATCH`, `SFTP_AUTH_FAILED` | Permanent | Destination |
| `DELIVERY_THROTTLED`, `DELIVERY_UNAVAILABLE` | Transient | Item |
| `AFS_CHANGE_DETECTION_FAILED`, `NOTIFICATION_FAILED` | Permanent | Item (non-blocking) |

Transient failures honour `Retry-After` where present. Exponential backoff with jitter is used in HTTP
resilience pipelines; Durable retry policies cover activity-level retries.

---

## 14. Platform configuration (`IOptions<T>`, validated on start)

| Section | Keys (defaults) |
|---|---|
| `Dispatcher` | `Schedule` (`0 */5 * * * *`), `MaxLateness` (`PT30M`) |
| `Runs` | `RunStaleAfter` (`PT2H`), `SummaryDetailRetentionDays` (30) |
| `Apim` | `BaseUrl`, `TokenScope` (`api://<<APIM_APP_ID>>/.default`), `TimeoutSeconds` (600), `AllowedDownloadHosts[]` |
| `Storage` | `RecordsAccountUri`, `StagingContainer` (`staging`), `RecordsContainer` (`records`), `StagingRetentionDays` (7), `UserDelegationSasTtl` (`PT15M`) |
| `ServiceBus` | `FullyQualifiedNamespace`, `DeliveryTopic` (`dts-risk-delivery`), `DeliverySubscription` (`sub-delivery`) |
| `Sql` | `ConnectionString` (no credentials; `Authentication=Active Directory Default`), `CommandTimeoutSeconds` (60) |
| `Archive` | `MaxEntries` (200), `MaxTotalBytes`, `MaxCompressionRatio` (100) |
| `FileTypes` | `PdfHeaderTolerance` (0) |
| `Delivery` | `ClaimLease` (`PT30M`), `StaleDeliveryAfter` (`PT4H`), `SharePointChunkBytes` (10 MiB), `SharePointSimpleUploadMaxBytes` (4 MiB), `SftpPathBudget` (255), per-destination retry values |
| `Notifications` | `Enabled`, `AcsEndpoint`, `SenderAddress` |

`host.json` caps `durableTask.maxConcurrentActivityFunctions`, `maxConcurrentOrchestratorFunctions` and
Service Bus `maxConcurrentCalls` so the number of concurrent large transfers stays bounded.

The Service Bus trigger connection uses identity-based settings (`ServiceBus__fullyQualifiedNamespace`),
never a connection string.

---

## 15. Security

### 15.1 Identity map

| Path | Auth |
|---|---|
| Function → APIM | Function MI token for `Apim:TokenScope` |
| APIM → Whitespace | APIM-held credential (named values backed by Key Vault); APIM obtains and caches the partner bearer token (ASM-006) |
| Function → Storage / Service Bus / SQL / ACS | Function MI |
| Function → SharePoint | MI app-only `Sites.Selected` (or KV certificate) |
| Function → external blob | Federated cross-tenant credential (or KV SAS) |
| Function → SFTP | SSH key from KV, pinned host key |
| Pipeline → Azure | Workload identity federation service connections |

### 15.2 APIM (existing; policies delivered as reviewed artefacts)

- `validate-azure-ad-token` restricted to the Function MI client ID.
- Partner token injection; do not implement the grant until ASM-006 is answered.
- `rate-limit-by-key` aligned to the partner limit.
- `forward-request buffer-response="false"` and a raised timeout on download/export operations, with **no
  body-reading policies** on those operations.
- **API diagnostics log 0 body bytes** (UK GDPR).

### 15.3 RBAC (least privilege, no Contributor anywhere)

- Function MI:
  - Storage Blob Data Contributor **per container** (`staging`, `records`, and each internal destination
    container);
  - Storage Blob Delegator on `st<name>rec` (user-delegation SAS);
  - Storage File Data Privileged Contributor on `st<name>fs` only;
  - Service Bus Data Sender on the topic; Data Receiver on `sub-delivery`;
  - Key Vault Secrets User and Certificate User as needed;
  - ACS email sender;
  - the minimal Storage Sync role for change detection.
- SQL: in-database roles per §7.4.

### 15.4 Ops endpoints

- `AuthorizationLevel.Anonymous` at function level, **plus** App Service Authentication (Entra) requiring a
  token.
- Handlers verify app roles from the client principal: `Dts.Operator` for start, retry, replay and
  backfill; `Dts.Reader` for status.
- The operator's object ID is recorded in `OrchestrationRuns.TriggeredBy` and in audit.
- Endpoints are reachable only through a private endpoint or an internal APIM product (§25).

### 15.5 Data protection controls

- Routing classification ceiling (§7.2, §12.3).
- The unlocked immutability policy on `records` is **never locked in code**. Locking requires
  records-management and DPO sign-off (it collides with Art 17 erasure and storage limitation). Document
  legal hold.
- `/docs/data-protection.md` covers: classification by class of business, retention, DPIA inputs,
  subject-access and erasure handling under WORM (write-once, read-many), `InsuredName` columns as personal
  data, and external routings.

---

## 16. Observability and notifications

### 16.1 Telemetry

- A correlation ID (§3.3) flows through logs, Service Bus application properties and audit rows; a
  telemetry initialiser adds it to every App Insights item.
- **Never log:** bytes, tokens, connection strings, full partner payloads, insured names, or attachment
  filenames at Information+. Log IDs and hashes.
- Custom events: `dts.run.completed`, `dts.document.rejected`, `dts.delivery.completed`,
  `dts.delivery.stale`. **Exclude custom events from adaptive sampling.**
- Metrics: discovered/new/duplicate/rejected/failed counts, bytes transferred, download duration
  percentiles, delivery latency per destination type, subscription backlog.

### 16.2 Alerts (Bicep, shared action group)

- Dead-man's switch: a scheduled workload with no `Completed*` run in its first window hour on a
  business day.
- DLQ depth > 0 on `sub-delivery`.
- Any DV `Failed`; any rejection; `dts.delivery.stale`; any `Skipped` for classification.
- Zero documents across a business day for an enabled workload (suspicious, not good news).
- Orchestration failure rate; runs beyond `MaxRunDurationMinutes`; `CONFIG_INVALID`; `PARTNER_UNAUTHORISED`.

### 16.3 Team notifications (ACS Email)

- Sent only if `EnableNotification = 1`, and only on failure outcomes when `NotifyOnFailureOnly = 1`.
- Recipient is `NotificationEmailAddress` (a shared mailbox or distribution list, never an individual).
- Content: workload name, UMR, outcome, counts per destination, link to the folder or site, correlation ID.
  **No insured names, no attachment filenames.**
- Failures → `NOTIFICATION_FAILED`, logged, never propagated.

### 16.4 Workbook (a deliverable, not a nice-to-have)

- Today's runs per workload.
- Per-destination delivery state.
- Failed and rejected documents with reason codes.
- Per-UMR document history for support staff.
- Stale deliveries.

---

## 17. Testing (mandatory)

- **Architecture:** rules 1–11 of §5.1; handlers contain no Durable/Functions types; triggers and
  activities are thin (dependency-count or convention check).
- **Unit (NUnit + NSubstitute + Shouldly):**
  - `ScheduleEvaluator`: DST gap and overlap, bank holidays, coalescing, `MaxLateness`, specific times vs
    interval;
  - enumeration stop condition and channel dedupe;
  - qualification rules;
  - `ExportStemMapper` over every §6.1 sample ID;
  - `PathBuilder`: Unicode insured names, reserved names, SharePoint rules, truncation preserving `_vNNN`
    and extension, containment;
  - validation matrix (including octet-stream acceptance and lying headers);
  - `HashingReadStream`: cap enforced mid-stream, header capture, hash correctness;
  - `PartnerTimestamp`: both formats;
  - tolerant reader;
  - reason-code classification completeness (every code has a class and a scope).
- **Durable:** orchestrator determinism against a mocked `TaskOrchestrationContext`; fan-out throttling;
  a per-document failure lets siblings continue; a risk failure lets other risks continue; watermark not
  committed on enumeration failure.
- **Integration (Testcontainers SQL + Azurite, WireMock.Net):**
  - DACPAC applies;
  - concurrent promotion allocates gap-free, unique versions;
  - `UQ_Risks_Folder` disambiguation;
  - claim lease;
  - `dts_app` **cannot** `UPDATE dts.Workloads` directly;
  - temporal history rows exist after config changes;
  - ≥500 MB generated file with bounded memory (measure allocations; no LOH blowup);
  - mid-stream connection drop;
  - zip bomb, zip slip, lying-header and encrypted-entry fixtures;
  - serverless auto-pause first-connection failure is retried.
- **Idempotency suite:** replay the same message twice, out of order, and concurrently. Assert one record
  blob, one version row, one delivered file per routing, and no surviving `.partial`.
- **E2E (Reqnroll):** isolated Service Bus namespace, stubbed Whitespace, all enabled destination types
  (SharePoint via WireMock Graph), SQL audit trail asserted end to end. Poll Durable status; **never fixed
  sleeps**.
- **Chaos:** kill the host mid-fan-out; make the Files share unreachable mid-delivery; revoke SharePoint
  access mid-run. Expect no partial files, no duplicates, the backlog drains, and audit shows retries
  rather than loss.
- **Gates:** ≥80% coverage on SharedKernel and all handlers; `dotnet format --verify-no-changes`.

---

## 18. Infrastructure as code (Bicep)

- `main.bicep` modules: `storage-runtime`, `storage-records`, `storage-fileshare`, `sql`, `functionapp`,
  `servicebus-entities`, `acs`, `nat` (conditional), `private-endpoints`, `rbac`, `monitoring`.
- `.bicepparam` per `dev|uat|prd`. Existing resources are referenced with `existing` by ID parameters and
  never created.
- CAF naming (`func-apollo-dts-uks-prd-01`); tags `costCentre`, `dataClassification`, `owner`,
  `serviceTier`, `businessService`.
- Security baseline:
  - `allowSharedKeyAccess: false` and `allowBlobPublicAccess: false` on the runtime and records accounts
    (the file-share account may differ; justify in an ADR);
  - TLS 1.2;
  - `publicNetworkAccess: Disabled` with private endpoints;
  - SQL Entra-only admin bound to a group.
- Private DNS zones for blob, file, database and Service Bus, with a smoke test that resolves each from the
  Function app.
- `what-if` reviewed before every apply.

---

## 19. CI/CD (Azure DevOps)

- YAML pipelines with workload identity federation:
  `azure-pipelines-ci.yml`, `azure-pipelines-cd-infra.yml`, `azure-pipelines-cd-app.yml`, plus templates.
- **CI (PR, branch policy):**
  - restore; build `-warnaserror`; format verify;
  - architecture, unit and integration tests; Cobertura coverage gate;
  - `bicep build` + lint; PSRule for Azure;
  - Microsoft Security DevOps / CodeQL; dependency and credential scans;
  - `/config` JSON Schema validation.
- **CD:** `dev → uat → prd` through Environments with approvals; required reviewers on uat/prd; a
  **business-hours check** blocks 06:00–18:00 UK weekdays.
  - Infra stage: what-if artefact, then apply.
  - App stage:
    1. DACPAC (`/p:BlockOnPossibleDataLoss=true`) + post-deploy roles and config `MERGE` + bank-holiday seed;
    2. **Durable drain check** (fail or wait if any instance is Running);
    3. Function deploy;
    4. smoke tests (health, private DNS, SQL, Files, Service Bus).
- Every prd deployment publishes a change-record artefact (commit, approver, timestamp, what-if output,
  config diff) for SMCR evidence.
- A self-hosted agent in the VNet only if private endpoints require it; record the decision in an ADR.

---

## 20. Documentation deliverables

- `architecture.md`: context, container and sequence views (Mermaid); trust boundaries; data flows with
  classification.
- `adr/*`.
- `assumptions.md`.
- `environment-inputs.md`.
- `runbook.md`: daily checks, per-alert response, DLQ replay, backfill, retry/replay, failed-document
  disposition, **manual fallback** (portal downloads), SharePoint `Sites.Selected` grant steps, Azure Files
  mount and migration, AFS operations, adding a new workload or routing via config-as-code.
- `data-protection.md`.
- `threat-model.md` (STRIDE across all trust boundaries, mitigations mapped to controls).

---

## 21. Assumption register (confirm; never invent)

| ID | Assumption |
|---|---|
| ASM-001 | Change-feed semantics. Evidence: `/api/summary` with keyset paging (§6.1) |
| ASM-002 | Document identity: placing `id` stable across revisions; attachment `identifier` stable or re-issued on `newVersionOf` |
| ASM-003 | Versioning exposed via `rev` (placings) and `version` (attachments) |
| ASM-004 | Attachment metadata `length`/`digest` are reliable (enables pre-download dedupe) |
| ASM-005 | Download is a direct stream; Range/resume support unknown |
| ASM-006 | Auth grant for the integration account (bearer JWT; issuance flow unknown); a **system integration account**, never personal credentials |
| ASM-007 | Rate limits and throttling behaviour |
| ASM-008 | IP allow-listing requirements (drives the NAT gateway) |
| ASM-009 | Sandbox availability. Evidence: sandbox server published; credentials needed |
| ASM-010 | Entitlement scope of the integration account vs individual underwriters (information barriers) |
| ASM-011 | Function egress traverses upstream gateway malware scanning |
| ASM-012 | VM join state (identity-based SMB vs key mount) |
| ASM-013 | Existing shared-drive volume and cutover window |
| ASM-014 | `/api/summary` strictly `updatedAt`-descending; `from`/`last` boundary inclusive or exclusive |
| ASM-015 | Time zone of partner timestamps |
| ASM-016 | `RWPlacing.rev` changes on every content-affecting edit and only then |
| ASM-017 | `RWAttachmentCollection.updatedAt` changes on attachment add or new version |
| ASM-018 | Rendered export PDFs are not byte-stable across calls |
| ASM-019 | Verticalised export zips contain only PDFs; entry naming |
| ASM-020 | `digest` = `sha1-` + Base64(SHA-1 of raw bytes) |
| ASM-021 | Placing statuses underwriters want delivered (business sign-off) |
| ASM-022 | Channel-to-team mapping for `PartnerScopeCsv` |
| ASM-023 | Export layout options per class of business |
| ASM-024 | Rate limits per endpoint family (summary, export, attachments) |
| ASM-025 | Azure File Sync cloud-change detection latency and change-detection API behaviour |
| ASM-026 | APIM tier supports unbuffered 500 MB responses within the timeout |

---

## 22. ADR register (pre-accepted unless marked *open*)

| # | Decision |
|---|---|
| 0001 | .NET 10 LTS isolated worker (gate §3) |
| 0002 | Durable Functions, single runtime; no Logic Apps / Event Grid / agents |
| 0003 | Azure Storage task hub backend; DTS as a future option (*comparison open*) |
| 0004 | Explicit monotonic watermark on the partner clock; never derived from data tables |
| 0005 | Revision-based change identity; SHA-256 for integrity and record addressing |
| 0006 | Version numbers allocated at promotion (no gaps from rejects) |
| 0007 | One topic message per risk; delivery executed as a Durable orchestration; completion after scheduling |
| 0008 | Single `sub-delivery` subscription with database-driven routing; sessions off (supersedes v2) |
| 0009 | Topic duplicate detection; replay MessageId suffixing |
| 0010 | Dapper + stored procedures; app writes only via procs |
| 0011 | Configuration as code with temporal tables (four-eyes via PR + environment approval) |
| 0012 | Routing classification ceiling |
| 0013 | APIM holds partner credentials; Function → APIM via MI |
| 0014 | No SMB from Functions; Azure Files via REST + OAuth; NetworkShareDrive via Azure File Sync |
| 0015 | Business notifications via ACS; ops alerts via action group |
| 0016 | Ledger audit table without foreign keys |
| 0017 | Partner Service Bus sources require deployed static triggers (not DB-driven) |
| 0018 | Unlocked immutability; locking needs DPO sign-off |
| 0019 | Hosting plan (Flex Consumption vs EP1) (*open until verified*) |
| 0020 | Orchestration versioning strategy (*open*) |
| 0021 | Hosted vs self-hosted pipeline agent (*open*) |
| 0022 | SFTP size-only verification (*open until first SFTP routing*) |

---

## 23. Milestones (stop at each for review)

| # | Milestone | Acceptance |
|---|---|---|
| 0 | *(Human-led)* Sandbox credentials; capture and scrub fixtures; fill §25. Agent prepares a capture script and scrubbing checklist only. | ASM-014–020 and ASM-024 resolved or deferred |
| 1 | Runtime gate; solution scaffold; `Directory.*.props`; SharedKernel (taxonomy, reason codes, `OperationResult`, `PathBuilder`, file-type rules, `HashingReadStream`, classification, correlation, partner timestamps, options conventions); Discovery and Delivery ports; empty feature folders with stubs; architecture tests; ADRs 0001–0022 created; doc skeletons | Build green; architecture tests pass **and** a deliberate cross-module reference makes them fail (demonstrate, then revert); SharedKernel unit tests green |
| 2 | SQL project: DDL, procs, roles, views, config-as-code `MERGE` generator + schemas, seeds | DACPAC applies to a container; concurrency, role-denial and temporal tests green |
| 3 | Bicep modules + dev params | `bicep build`/lint clean; what-if clean if credentials are available |
| 4 | Scheduling + run lifecycle (`BeginRun`, `FinaliseRun`, `SweepStaleRuns`) with a fake partner source | DST, bank-holiday and coalescing tests; duplicate-slot collision; stale-run sweep |
| 5 | Whitespace adapter + WireMock fixtures | Paging, dedupe, scope, qualification, stem mapping, throttling, mid-stream drop |
| 6 | Enumeration + planning + watermark | Partial-failure test proves the watermark does not advance; mid-walk update caught next run |
| 7 | Fetch, validate, archive, promote | 500 MB bounded memory; archive attack suite; validation matrix; idempotent promotion |
| 8 | Publish + delivery core + BlobStorage + AzureFileShare | Idempotency suite; classification ceiling; verify-then-rename; containment |
| 9 | SharePointSite | Chunked upload, conflict, throttling |
| 10 | SftpSite + NetworkShareDrive (feature-flagged) | Host-key pinning; AFS change-detection call verified against a real or emulated endpoint (state which) |
| 11 | Notifications, alerts, workbook, ops endpoints + auth, pipelines to uat | Forced-failure drill fires ops and team notifications; drain check blocks a deploy with a live orchestration |
| 12 | E2E, chaos, runbook, threat model, go-live pack | Full green run; two-week parallel-run plan with daily reconciliation |

---

## 24. Definition of done

- Builds warning-free; all tests green including architecture tests; coverage gate met.
- `dotnet format` clean; `what-if` clean.
- No secrets anywhere.
- Every assumption registered; ADRs written; no unresolved `// VERIFY:` in shipped code.
- Runbook usable by someone who did not build the system; manual fallback documented.
- Two-week parallel-run plan (automation shadows the manual process with daily reconciliation) drafted
  before cutover.

---

## 25. Environment inputs (`/docs/environment-inputs.md`; never hardcode)

**Tenancy and region**

- `<<TENANT_ID>>`, `<<SUBSCRIPTION_ID_{ENV}>>`, `<<RESOURCE_GROUP_{ENV}>>`, `<<REGION>>` (uksouth/ukwest).
- Naming tokens, tags, cost centre.

**Existing resources**

- `<<SERVICEBUS_NAMESPACE_ID>>` + tier.
- `<<APIM_ID>>`, `<<APIM_APP_ID>>`, Whitespace API path.
- `<<KEYVAULT_ID>>`, `<<LOG_ANALYTICS_ID>>`, `<<APP_INSIGHTS_ID>>`, `<<ACTION_GROUP_ID>>`.
- `<<VNET_ID>>`, integration and private-endpoint subnet IDs, private DNS zone locations.
- `<<VM_ID>>` + join state; `<<STORAGE_SYNC_SERVICE_ID>>` (if used).
- `<<SHAREPOINT_SITE_ID>>`/`<<DRIVE_ID>>` per routing.

**Messaging and notifications**

- ACS email domain and sender.

**Whitespace**

- Integration account; channel-to-team mapping.

**Operations**

- Ops endpoint exposure (private endpoint vs internal APIM).
- Deployment window confirmation.
- SYSC 15A Important Business Service mapping and impact tolerance for this process.

## 26. Amendments v3.1 (supersede conflicting text above)

26.1 **Vacuous architecture tests.** Every architecture rule must first assert that its type selector
matches at least one type (e.g. `types.Count().ShouldBeGreaterThan(0)`). A rule over an empty selection
passes silently and proves nothing.

26.2 **Retry ownership (no retry amplification).** Durable retry policies own retries for activities.
HTTP resilience pipelines inside activities are limited to:
- metadata GETs: at most 2 attempts, honouring `Retry-After`, total budget ≤ 30 s;
- streaming downloads, export POSTs, and all destination uploads: **no HTTP-level retry** (a stream cannot
  be retried mid-body; Durable retries the whole activity).
`POST /export/pdf` is a read-only render and is safe to retry at activity level; document this in ADR.
Nested retries (e.g. 3 HTTP × 4 Durable = 12 partner calls) are a defect.

26.3 **Azurite does not implement Azure Files**, and does not faithfully emulate Entra-dependent paths
(managed identity, user-delegation SAS, OAuth copy-source authorisation, Files `backup` intent).
- Azurite: Blob functional paths only.
- Identity-dependent and Files paths: a **nightly integration stage** against a dedicated dev storage
  account in a sandbox subscription, run by the pipeline's federated identity. Tests are tagged
  `[Category("RequiresAzure")]` and excluded from PR CI.
- Update §17 accordingly.

26.4 **Large-body test servers.** WireMock.Net buffers response bodies. The ≥500 MB streaming tests use a
purpose-built Kestrel/TestServer endpoint that generates a valid-magic synthetic stream on the fly
(e.g. `%PDF-1.7` header + deterministic pseudo-random body + `%%EOF`), never a WireMock stub or a file on
disk. The memory assertion measures the *system under test* only.

26.5 **SQL container version.** Ledger tables require SQL Server 2022+. Testcontainers must pin a 2022
image. Ledger table schema is effectively append-only too (limited ALTER; no DROP of ledger history), so
`dts.AuditEvents` must be correct before the first prd deploy; any later change needs an ADR.

26.6 **Durable drain check without system keys.** The pipeline must not use the Functions system key
(`runtime/webhooks/durabletask`). Expose `GetRunStatus?runtimeStatus=Running` (Entra-protected) and grant
the pipeline's federated identity the `Dts.Reader` app role. Because public inbound is disabled, the
drain check and smoke tests run from a VNet-connected self-hosted agent — this resolves ADR-0021.

26.7 **Clock abstraction.** All handlers take `TimeProvider` (BCL) — never `DateTime.UtcNow` or
`DateTimeOffset.UtcNow` outside the composition root. Tests use `FakeTimeProvider`
(`Microsoft.Extensions.TimeProvider.Testing`).

26.8 **Existing-resource scopes.** Service Bus entities, APIM, Key Vault and DNS zones may live in other
resource groups or subscriptions. Bicep modules deploying into them take an explicit
`scope: resourceGroup(subId, rgName)`. If private DNS zones are hub-managed by Azure Policy
(`deployIfNotExists`), do not create zones or zone groups; record which model applies in
environment-inputs.
# ADR-0023 — No HTTP-level retry on `POST /export/pdf/{riskID}`

**Status:** Accepted
**Date:** 2026-09-27

## Context

`POST /export/pdf/{riskID}` is classified as an export POST. The response body is streamed directly into a staging blob upload. Once the response stream has started, a partial HTTP-level retry would:
1. Re-POST the export request mid-stream, producing a new response stream.
2. Leave the partially written staging blob in an inconsistent state.
3. Potentially cause the partner to start a second concurrent render, violating rate limits.

## Decision

`POST /export/pdf/{riskID}` carries **no HTTP-level retry** (`retryPolicy: { type: "none" }` on the HTTP action in `wf-activity-partner-api-whitespace`). The timeout is set to 600 s.

The Logic App workflow action retry policy provides the outer retry envelope: on failure the entire activity workflow is re-invoked by the orchestrator with a fresh connection and a fresh streaming response. The staging blob is overwritten on each attempt (scratch semantics), so each retry is idempotent.

The justification for treating this POST as safe to retry at the workflow level: the export is a read-only render — it does not create or modify partner data.

## Consequences

- No nested retry amplification: 1 HTTP attempt per workflow invocation; the orchestrator controls total attempt count.
- A transient mid-stream failure (dropped connection, 5xx) fails the activity workflow. The orchestrator retries the whole activity after its back-off interval.
- `429` responses before the body starts should be surfaced as a failed action and retried by the orchestrator with back-off.
- If the partner returns `Retry-After` on export endpoints, the orchestrator retry policy should honour it.

# ADR-0021: Hosted vs self-hosted pipeline agent

## Status

Superseded by ADR-0029 (self-hosted agent accepted).

## Context

Microsoft-hosted agents cannot reach resources behind private endpoints. If the DACPAC deployment, smoke tests, or `az deployment group what-if` require access to resources on the VNet, a self-hosted agent is required.

## Options

1. **Microsoft-hosted agent** — simple; no maintenance; cannot reach private endpoints.
2. **Self-hosted agent on a VNet-joined VM** — can reach private endpoints; requires maintenance and patching.

## Decision

Pending. Determined when the environment topology is confirmed (§25). The pipeline YAML is parameterised to switch agent pools.

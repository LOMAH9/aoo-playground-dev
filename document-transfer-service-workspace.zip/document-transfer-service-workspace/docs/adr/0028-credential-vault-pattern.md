# ADR-0028 — Key Vault credential pattern for SFTP and SMB routings

**Status:** Accepted

## Context

SFTP and Network Share (SMB) delivery routings require a secret credential (SSH key or password) that must not be stored in Azure Table Storage. The secret must be retrieved at delivery time by the Logic App.

The routing record in `DtsWorkloadDocRouting` carries a `CredentialKeyVaultRef` field containing only the **secret name** (e.g. `sftp-routing-42-key`), not a full Key Vault URI. The vault base URI is held in the `KEYVAULT_URI` app setting on the Logic App.

## Decision

At delivery time, `wf-activity-sftp` and `wf-activity-smb` retrieve the credential by calling the Key Vault REST API via an HTTP action authenticated with the Logic App's Managed Identity:

```
GET https://{env:KEYVAULT_URI}/secrets/{CredentialKeyVaultRef}?api-version=7.4
Authorization: Bearer {managed-identity-token}
```

The Logic App MI holds **Key Vault Secrets User** on `kv-apollo-dts-{env}`.

`CredentialKeyVaultRef` in `DtsWorkloadDocRouting` stores only the secret name — never a full Key Vault URI. The vault base URI is a non-secret app setting (`KEYVAULT_URI`) set per environment in `logicAppStandard.bicep`.

## Consequences

- All Key Vault access uses the Logic App MI — no storage account keys or embedded secrets.
- Secret names are routing-specific (one per SFTP site or SMB share credential).
- Out of scope for the current Whitespace workload (API source with APIM-injected credentials; no Key Vault lookup required at delivery time).

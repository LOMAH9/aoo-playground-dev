# ADR-0024: Azure Files delivery — Managed Identity authentication

**Status:** Accepted

## Context

§12.4 requires Azure Files delivery to use Managed Identity authentication over HTTPS. The spec explicitly states: "never fall back to storage account keys."

In Logic Apps Standard, Azure Files delivery is implemented in `wf-activity-file-storage` using the built-in **Azure File Storage** service-provider connector. The connector targets the files storage account (`st{name}fs`) and authenticates using the Logic App's system-assigned Managed Identity. No SDK or custom HTTP call is required.

## Decision

Use the Azure File Storage built-in connector with Managed Identity authentication. The connector handles OAuth and the required `x-ms-file-request-intent: backup` header automatically.

Write atomicity is achieved by writing to a `.partial` temporary filename first, then renaming to the final filename via a second connector action. If the Logic App run fails between write and rename, the `.partial` file is left behind and overwritten on the next replay attempt.

Under no circumstances is a storage account key used for Azure Files auth.

## Consequences

- The Logic App MI holds **Storage File Data Privileged Contributor** on `st{name}fs` only.
- The records blob account (`st{name}rec`) requires **Storage Blob Data Contributor** on the Logic App MI for the records-copy path (separate role assignment, separate storage account).
- No NuGet packages or custom JWT handling are involved.
- Integration tests against Azure Files require the test identity to hold **Storage File Data Privileged Contributor** on the dev files storage account.

# ADR-0004: Explicit monotonic watermark on the partner clock

## Status

Accepted

## Context

The partner feed is newest-first. Deriving the watermark from MAX() over data tables would advance past unprocessed risks during a partial run.

## Decision

Commit `WatermarkToUtc` only when `EnumerationComplete = 1` AND every registered candidate is terminal. The value is the `updatedAt` of the first item of page 1 (the partner clock). Monotonic: never decrease.

## Consequences

- Partial runs do not lose data.
- The watermark is never derived from MAX() over Risks or Documents.
- Overlap window (`OverlapWindowMinutes`) provides a safety margin for clock skew.

# ADR-0029: Self-Hosted ADO Agent for CD Pipeline

**Status:** Accepted
**Date:** 2026-09-28
**Resolves:** ADR-0021 (open: "Hosted vs self-hosted pipeline agent")

---

## Context

ADR-0021 left the pipeline agent choice open pending a decision on network architecture. Since ADR-0021 was written, the infrastructure has converged on the following:

- The Logic App Standard has `publicNetworkAccess: Disabled`. All inbound and outbound traffic flows through the VNet.
- Private endpoints are provisioned for: Azure Blob Storage, Azure Table Storage, Azure Service Bus, Azure File Share, and the Logic App's SCM endpoint itself.
- The drain-check endpoint (`wf-trigger-http-status`) is exposed only via the Logic App's private endpoint. It is not reachable from the public internet.
- Post-deployment smoke tests (health probe, Blob Storage connectivity, Service Bus send check) all require network line-of-sight to private endpoints.

Microsoft-hosted agents (`ubuntu-latest`) run in Microsoft's infrastructure and have no access to private endpoints within a customer VNet. They cannot:

1. Call the drain-check endpoint to confirm zero running workflows before deployment.
2. Execute the post-deployment smoke tests.
3. Deploy the Logic App zip package via the Kudu SCM private endpoint.

A VNet-integrated self-hosted agent resolves all three constraints.

---

## Decision

Use a self-hosted ADO agent running in a VM within the integration subnet of the Apollo DTS VNet for all CD pipeline stages.

The agent pool is named **`dts-selfhosted`**.

The CI pipeline (lint, schema validation) continues to use the Microsoft-hosted `ubuntu-latest` pool. CI stages have no network dependencies on Azure resources and benefit from the speed, reliability, and zero-maintenance characteristics of hosted agents.

CD stages switch to the `dts-selfhosted` pool. Specifically:

- Logic App zip deploy stage (Kudu/zip deploy via SCM private endpoint)
- Drain-check polling step
- Post-deployment smoke tests

### Agent VM specification

| Property | Value |
|----------|-------|
| VM name | TBD — provisioned by platform team |
| VNet | `vnet-apollo-dts-{env}` |
| Subnet | `snet-integration` |
| ADO agent pool | `dts-selfhosted` |
| OS | Ubuntu 22.04 LTS |
| Required tools | `az` CLI, ADO agent runtime |
| Managed Identity | System-assigned; assigned `Contributor` on `rg-apollo-dts-{env}` for deployment |

The agent VM is pre-provisioned by the platform team. The ADO agent software is installed and registered to the `dts-selfhosted` pool using a Personal Access Token with Agent Pool (read, manage) scope.

### Pipeline YAML pool selection

```yaml
# CI stages — use hosted agent
pool:
  vmImage: ubuntu-latest

# CD stages — use self-hosted agent in VNet
pool:
  name: dts-selfhosted
```

---

## Consequences

### Positive

- All private-endpoint-dependent deployment steps (zip deploy, drain check, smoke tests) now execute successfully.
- The drain check can reliably poll `wf-trigger-http-status` and enforce the zero-running-workflows gate before deployment proceeds.
- Post-deployment smoke tests execute within the VNet with full service connectivity.

### Negative

- The agent VM requires ongoing maintenance: OS patching, ADO agent version updates, and disk space monitoring. This adds operational overhead to the platform team.
- If the agent VM is unavailable (patching window, hardware failure), CD pipelines are blocked. Mitigation: provision a second agent VM in the same pool for redundancy (recommended but not mandatory for initial go-live).
- The agent VM's Managed Identity has elevated permissions within the resource group. Its access must be reviewed in IAM access reviews.

### Neutral

- CI remains on hosted agents. Build times and CI reliability are unaffected.
- ADR-0021 is now resolved. The agent pool name is `dts-selfhosted`.

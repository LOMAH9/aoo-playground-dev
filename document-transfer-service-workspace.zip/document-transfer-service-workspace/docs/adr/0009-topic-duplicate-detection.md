# ADR-0009: Topic duplicate detection; replay MessageId suffixing

## Status

Accepted

## Context

Discovery runs and delivery requests are published to separate Service Bus topics. Delivery request messages (`dts-dlv-requests`) are intentional — including replays — so duplicate detection is not applied at the broker level. Discovery run messages (`dts-disc-runs`) use duplicate detection to prevent re-triggering the same run if the trigger workflow is retried.

## Decision

- `dts-disc-runs`: `requiresDuplicateDetection: true`, 10-minute window. Deduplicates accidental re-publishes within the same dispatch cycle.
- `dts-dlv-requests`: `requiresDuplicateDetection: false`. Replays are legitimate re-deliveries and must not be silently dropped.
- Delivery request MessageId format: `{workloadId}-{riskId}-{yyyyMMddHHmmss}` — unique per publish attempt by timestamp, ensuring replay messages are distinct.

## Consequences

- Replays from `wf-trigger-http-replay` always reach the delivery orchestrator; deduplication is enforced at the `DtsDocuments` Status check, not at the broker.
- The 10-minute discovery dup-detection window is sufficient for the 5-minute polling interval; any retry within the window is a no-op at the broker.

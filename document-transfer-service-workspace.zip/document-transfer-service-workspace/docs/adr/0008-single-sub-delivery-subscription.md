# ADR-0008: Single sub-delivery subscription; database-driven routing; sessions off

## Status

Accepted

## Context

Alternative: one subscription per destination. This would require static infrastructure changes to add a routing.

## Decision

One `sub-dlv` subscription. The delivery orchestration reads routing configuration from Azure Table Storage (`DtsWorkloadDocRouting`) and fans out to destinations in parallel.

## Consequences

- Adding a new routing requires only a config-as-code change, not infrastructure.
- Session IDs not used (routing is data-driven, not session-based).
- `requiresSession: false` on the subscription.

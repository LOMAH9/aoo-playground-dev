# ADR-0005: Revision-based change identity; SHA-256 for integrity

## Status

Accepted

## Context

Filename and timestamp are unreliable identity signals. The partner assigns explicit revision values.

## Decision

Change identity = `(DocumentKey, PartnerRevision)`. SHA-256 of bytes is integrity evidence and the record's content address. For exports, change identity is `rev`, not SHA-256 (ASM-018: rendered PDFs are non-deterministic).

## Consequences

- Idempotent re-ingestion: the same revision is never double-promoted.
- Content-addressed record blobs: identical content is stored once regardless of which risk produced it.

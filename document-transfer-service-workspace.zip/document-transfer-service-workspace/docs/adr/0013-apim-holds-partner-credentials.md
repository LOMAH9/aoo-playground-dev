# ADR-0013: APIM holds partner credentials; Logic App authenticates to APIM via MI

## Status

Accepted

## Context

The Whitespace API requires a bearer token. The issuance flow is unknown (ASM-006). Putting the partner credential in the Logic App's app settings would expose it.

## Decision

APIM holds the partner credential in named values backed by Key Vault. The Logic App authenticates to APIM using its system-assigned Managed Identity. APIM injects the partner token.

## Consequences

- The partner credential never reaches the Logic App.
- ASM-006 (token issuance flow) must be resolved before the production parallel run begins.
- APIM policy: `validate-azure-ad-token` restricted to the Logic App MI client ID.

# ADR-0030: Chaos Engineering — Azure Chaos Studio Gaps and Substitutes

**Status:** Accepted
**Date:** 2026-09-28

---

## Context

Five chaos scenarios must be executed before production go-live to validate system resilience:

1. Kill the Logic App host mid-run
2. Make the Azure Files share unreachable mid-delivery
3. Revoke SharePoint access mid-run
4. Azure Table Storage unavailable mid-orchestration
5. Service Bus namespace throttled

Azure Chaos Studio is the preferred implementation mechanism. Not all five scenarios can be produced by Chaos Studio. This ADR documents which experiments are supported natively and what substitute procedures are used for the rest.

---

## Decision

Implement all five chaos experiments. Use Chaos Studio for CE-001, CE-002, and CE-004. Use manual substitute procedures for CE-003 and CE-005 where Chaos Studio has no applicable fault.

---

## Chaos Experiments

### CE-001: Logic App host crash mid-run

| Property | Detail |
|----------|--------|
| Chaos Studio support | Yes |
| Fault | `Microsoft-Agent/Kill-Process-2.0` targeting the Logic App worker process |
| Target | Logic App Standard App Service Plan VMs; agent-based fault requires the Chaos Studio agent extension installed on the underlying VMs |
| Trigger timing | Inject fault after a discovery or delivery run has started (at least one workflow action is In Progress, confirmed via Logic App run history) |

**Procedure:**

1. In Chaos Studio, create an experiment targeting the `logic-uks-dts-{env}` Logic App resource (App Service Plan VMs).
2. Configure the `Kill-Process-2.0` fault with the Logic App worker process name.
3. Start a delivery run with a workload containing at least 10 documents to ensure processing is active at fault injection time.
4. Monitor Application Insights for workflow run failures and subsequent re-trigger behaviour.

**Expected behaviour:**

- In-flight workflow actions fail; the Logic App run is marked Failed.
- The Service Bus message lock expires and the message is redelivered (or abandoned and redelivered after lock timeout).
- The `wf-trigger-servicebus-topic-deliveryworkload` re-triggers the delivery orchestrator.
- Idempotency in `DtsDocuments` (Status check) prevents duplicate delivery of already-published documents.

**Pass criteria:**

- No partial files written to any destination (blob writes are atomic per file).
- No duplicate deliveries — `DtsDocumentDeliveries.Status = Delivered` for each document/routing pair remains singular.
- Delivery completes without manual intervention after the host recovers.
- DLQ depth remains zero (all messages eventually processed, no permanent failures caused by the crash).

---

### CE-002: Azure Files share unreachable mid-delivery

| Property | Detail |
|----------|--------|
| Chaos Studio support | Yes |
| Fault | `Microsoft-VirtualNetwork/NSG-Block-Port-1.0` blocking port 445 outbound from the integration subnet |
| Target | Integration subnet NSG (`nsg-snet-integration-{env}`) |
| Trigger timing | Inject after a delivery to an `AzureFileShare` destination has started |

**Procedure:**

1. In Chaos Studio, create an experiment targeting the NSG on the integration subnet.
2. Configure the NSG fault to block outbound port 445 (SMB) for 10 minutes.
3. Trigger a workload delivery with an `AzureFileShare` routing active.
4. Observe retry behaviour in Application Insights.

**Expected behaviour:**

- The `wf-activity-file-storage` workflow action fails with a network error.
- The delivery orchestrator marks the routing attempt Failed in `DtsDocumentDeliveries`.
- After the NSG fault expires (port 445 restored), a replay via `wf-trigger-http-replay` succeeds.
- No partial file is written — Azure Files write is atomic at the file level.

**Pass criteria:**

- `DtsDocumentDeliveries.Status = Failed` with `ReasonCode = UPLOAD_ERROR` for the affected routing.
- Once the port is restored and a replay is triggered, delivery completes and `DtsDocumentDeliveries.Status` reaches `Delivered`.
- No permanent failure without a replay.

---

### CE-003: SharePoint access revoked mid-run

| Property | Detail |
|----------|--------|
| Chaos Studio support | No — Chaos Studio has no Entra ID or Microsoft Graph permission fault capability |
| Substitute | Manual Entra app registration permission revocation in the sandbox tenant |

**Procedure:**

Manual steps, performed by a sandbox tenant administrator during the chaos test window:

1. Confirm a delivery run targeting a `SharePoint` destination is active.
2. In Entra ID admin centre (sandbox tenant), navigate to Enterprise Applications → Apollo DTS (sandbox) → Permissions.
3. Revoke the `Sites.Selected` permission for the target site using the Revoke-PnPAzureADAppSitePermission PowerShell command:
   ```powershell
   Connect-PnPOnline -Url "https://{sandbox-tenant}-admin.sharepoint.com" -Interactive
   Revoke-PnPAzureADAppSitePermission `
       -Site "https://{sandbox-tenant}.sharepoint.com/sites/{test-site}" `
       -PermissionId "{permissionId}"
   ```
4. Observe Application Insights for Graph 403 responses and `UPLOAD_ERROR` reason codes in `DtsDocumentDeliveries`.
5. After 5 minutes, re-grant the permission and trigger a replay via `wf-trigger-http-replay`.

**Expected behaviour:**

- The `wf-activity-sharepoint` workflow receives a 403 from the Graph API.
- `DtsDocumentDeliveries.Status = Failed`, `ReasonCode = UPLOAD_ERROR`.
- The `alert-dts-dlq-depth` alert fires if the message is dead-lettered.
- After permission is re-granted and replay triggered, delivery succeeds.

**Pass criteria:**

- No partial file uploaded to SharePoint.
- Once the permission is re-granted and a replay issued, delivery completes successfully.
- No duplicate file on SharePoint.

---

### CE-004: Azure Table Storage unavailable mid-orchestration

| Property | Detail |
|----------|--------|
| Chaos Studio support | Yes |
| Fault | `Microsoft-VirtualNetwork/NSG-Block-Port-1.0` blocking port 443 outbound from the integration subnet (Table Storage uses HTTPS) |
| Target | Integration subnet NSG (`nsg-snet-integration-{env}`) |
| Trigger timing | Inject after a discovery orchestration has started (watermark query has been issued but document processing has not yet completed) |

**Procedure:**

1. In Chaos Studio, create an experiment targeting the integration subnet NSG.
2. Configure the NSG fault to block outbound port 443 for 10 minutes (targets all HTTPS including Table Storage endpoints).
3. Start a discovery run for a workload.
4. Observe Application Insights for Table Storage connectivity exceptions and workflow action failures.

**Expected behaviour:**

- Table Storage actions (`getEntities`, `insertOrMergeEntity`) fail with connectivity errors.
- The affected workflow action fails; the Logic App run is marked Failed.
- The Service Bus message (if applicable) is abandoned and redelivered after lock timeout.
- Once the NSG fault expires (port 443 restored), a re-trigger or replay recovers the run.

**Pass criteria:**

- Orchestration recovers without manual intervention after port is restored (via Service Bus redelivery or operator replay).
- No documents permanently skipped — all documents available from the partner API during the fault window are eventually processed.
- `DtsOrchestrationRuns` shows the failed run and a subsequent successful run.
- DLQ depth remains zero after recovery.

---

### CE-005: Service Bus namespace throttled

| Property | Detail |
|----------|--------|
| Chaos Studio support | No — Chaos Studio has no Service Bus throttling fault |
| Substitute | Publish-rate ramp test — publish 1,000 messages in 30 seconds to the `dts-dlv-requests` topic; observe throttling behaviour |

**Procedure:**

```bash
# Requires az CLI with Service Bus Data Sender role on the namespace
NAMESPACE="sb-apollo-dts-{env}"
TOPIC="dts-dlv-requests"
BODY='{"workloadId":"chaos-workload","riskId":"chaos-risk-001","runId":"chaos-run-001","correlationId":"chaos-ce005","documents":[]}'

for i in $(seq 1 1000); do
  az servicebus topic message send \
    --resource-group rg-apollo-dts-{env} \
    --namespace-name $NAMESPACE \
    --topic-name $TOPIC \
    --body "$BODY" &
  if (( i % 50 == 0 )); then wait; fi
done
wait
echo "All 1000 messages sent"
```

Monitor Application Insights during and after the flood for:

- Throttled publish errors
- `wf-trigger-servicebus-topic-deliveryworkload` trigger queue depth
- Service Bus metric `ThrottledRequests` on the namespace

**Expected behaviour:**

- The Service Bus Premium namespace absorbs the majority of messages without throttling (Premium tier is dedicated capacity).
- Any throttled publishes are surfaced as errors in the publishing workflow.
- The flood of messages with `documents: []` triggers `SB_Deadletter_No_Downloads` in the trigger workflow and is dead-lettered — this is expected.
- Real (non-chaos) delivery messages in the queue are not permanently impaired.

**Pass criteria:**

- All valid (non-chaos-test) delivery messages eventually reach their terminal status.
- The chaos messages are dead-lettered with `NO_DOWNLOADED_DOCS` (confirming the error path is exercised).
- After the flood, the delivery trigger processes its backlog to zero within 3 × normal processing time.

---

## Summary Table

| ID | Scenario | Chaos Studio Support | Implementation | Pass Criteria Summary |
|----|----------|---------------------|----------------|----------------------|
| CE-001 | Logic App host crash mid-run | Yes — `Microsoft-Agent/Kill-Process-2.0` | Chaos Studio experiment on App Service Plan VMs | No partial files; no duplicates; self-heals via SB redelivery |
| CE-002 | Azure Files share unreachable | Yes — `Microsoft-VirtualNetwork/NSG-Block-Port-1.0` port 445 | Chaos Studio NSG fault on integration subnet | Delivery completes after fault clears via replay; no partial writes |
| CE-003 | SharePoint access revoked mid-run | No — no Entra/Graph fault in Chaos Studio | Manual `Revoke-PnPAzureADAppSitePermission` in sandbox tenant | Failed status recorded; replay after re-grant succeeds; no duplicates |
| CE-004 | Azure Table Storage unavailable | Yes — `Microsoft-VirtualNetwork/NSG-Block-Port-1.0` port 443 | Chaos Studio NSG fault on integration subnet | Run recovers after port restored; no documents skipped |
| CE-005 | Service Bus throttled | No — no SB throttling fault in Chaos Studio | Publish-rate ramp test: 1000 messages to `dts-dlv-requests` in 30 s | Chaos messages dead-lettered; real deliveries unaffected |

---

## Consequences

- CE-003 and CE-005 require manual or scripted substitute procedures and cannot be run as automated chaos experiments in a CI pipeline without custom tooling.
- CE-003 requires a sandbox Entra tenant with equivalent SharePoint configuration. The production tenant must not be used for permission revocation experiments.
- CE-005 requires care to avoid flooding the Service Bus namespace in an environment shared with other services. Run in the dedicated `dev` environment only.
- All five experiments must be executed and pass criteria confirmed before the production parallel run begins.

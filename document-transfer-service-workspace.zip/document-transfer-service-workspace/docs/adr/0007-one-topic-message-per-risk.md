# ADR-0007: One topic message per risk; delivery as a Logic App workflow

## Status

Accepted

## Context

Alternatives: one message per document; batched messages; direct delivery from discovery.

## Decision

One delivery request message per risk per run, containing all document metadata for that risk (staged blob paths, digests, file names). Delivery executes as a separate Logic App workflow (`wf-orchestrator-delivery`) invoked by the Service Bus trigger (`wf-trigger-servicebus-topic-deliveryworkload`).

## Consequences

- Discovery and Delivery are decoupled; each can fail and retry independently.
- No insured names or folder paths in the message (Azure Table Storage is the source of truth — `DtsRisks` provides `RelativeFolderPath` at delivery time).
- Message is self-contained with all document fields needed for delivery; no additional table lookups on the hot path for document metadata.

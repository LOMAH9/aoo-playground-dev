# ADR-0015: Business notifications via ACS Email; ops alerts via action group

## Status

Accepted

## Context

Two notification channels: team notifications (delivery outcome) and ops alerts (DLQ depth, failed runs, etc.).

## Decision

Team notifications use Azure Communication Services Email (MI-authenticated). Ops alerts use the existing shared action group wired to Azure Monitor alerts defined in Bicep.

## Consequences

- Notification failures are non-blocking (`NOTIFICATION_FAILED` logged, never propagated).
- Recipient is always a shared mailbox or DL, never an individual's address.
- No insured names or attachment filenames in notification content.

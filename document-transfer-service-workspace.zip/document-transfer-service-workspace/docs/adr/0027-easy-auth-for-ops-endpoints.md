# ADR-0027 — App Service Authentication (Easy Auth) for Ops Endpoints

**Status:** Accepted

## Context

The ops HTTP-triggered workflows (`wf-trigger-http-replay`, `wf-trigger-http-manual`) need Entra identity validation and app role (`Dts.Operator`, `Dts.Reader`) enforcement.

Options:
1. **Custom token validation in the workflow** — the HTTP trigger would need to manually call the JWKS endpoint and validate the JWT, adding significant complexity to the workflow definition.
2. **App Service Authentication (Easy Auth)** — App Service validates the Entra token before the request reaches the workflow; the workflow reads claims from the `X-MS-CLIENT-PRINCIPAL` header.

Logic Apps Standard runs on App Service infrastructure and supports App Service Authentication natively.

## Decision

Use App Service Authentication (Easy Auth) configured in Bicep. The workflow reads the `X-MS-CLIENT-PRINCIPAL` base64-JSON header via `@triggerOutputs()['headers']['X-MS-CLIENT-PRINCIPAL']` to extract roles and the caller's object ID. No custom token validation is added to the workflow definition.

## Consequences

- No custom authentication logic in workflow definitions.
- The `X-MS-CLIENT-PRINCIPAL` header is only present when Easy Auth is enabled. In local development (Azurite + local runtime), ops endpoints are unauthenticated — acceptable for local dev.
- In deployed environments, the Logic App App Service access restrictions block all inbound internet traffic; only the corporate network CIDR (VPN/ExpressRoute) can reach the HTTP trigger URLs. Easy Auth provides the authentication layer above this network control.
- The pipeline drain-check uses a federated identity with `Dts.Reader` role; token exchange uses `az account get-access-token`.

# ADR-0017: Partner Service Bus sources require deployed static trigger workflows

## Status

Accepted

## Context

PartnerInbound workloads sourced from a partner's Service Bus topic need a trigger workflow bound to that topic.

## Decision

Partner SB source triggers are static trigger workflows deployed as part of the Logic App Standard package. They are not dynamically registered from the workload table. Adding a new partner SB source requires a new trigger workflow definition and a Logic App deployment.

## Consequences

- Simplifies the trigger registration model.
- The workload table still controls whether a workload is enabled.
- Out of scope for the current Whitespace workload (API source).

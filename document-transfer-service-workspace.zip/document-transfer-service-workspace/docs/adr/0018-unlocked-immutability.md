# ADR-0018: Unlocked immutability on records container; locking requires DPO sign-off

## Status

Accepted

## Context

Time-based immutability on the `records` blob container provides WORM protection for evidential records. However, locking the policy would prevent erasure required under UK GDPR Art 17. Locking also requires legal hold and records-management processes.

## Decision

The immutability policy is configured as **unlocked** time-based retention. It is never locked in code. Locking requires explicit DPO and records-management sign-off.

## Consequences

- The `records` container is write-protected for the retention period but can be unlocked by authorised personnel.
- Erasure under Art 17 can be handled via the unlocked policy or a legal hold override.
- The pipeline and Logic App workflows must never call the lock operation.

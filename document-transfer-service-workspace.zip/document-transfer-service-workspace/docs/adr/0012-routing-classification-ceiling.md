# ADR-0012: Routing classification ceiling

## Status

Proposed — deferred. Not yet implemented in `DtsWorkloadDocRouting` schema or delivery orchestrator.

## Context

Some routings are external (Art 28 data processors) or have lower data protection postures. A document classified `Confidential-SpecialCategory` must not be delivered to a routing rated `Confidential`.

## Decision

Each routing should carry a `MaxDataClassification` field in `DtsWorkloadDocRouting`. A delivery would be `Skipped` with `DELIVERY_CLASSIFICATION_NOT_PERMITTED` if the document's classification exceeds the routing's ceiling.

## Consequences

- Prevents inadvertent delivery of sensitive documents to lower-classified destinations.
- Not yet enforced — `MaxDataClassification` is not present in `DtsWorkloadDocRouting` and the check is not implemented in `wf-orchestrator-delivery`.
- Must be added to the table schema and to the `SWITCH_Destination_Type` / `IF_Upload_Succeeded` branch before any routing with a classification ceiling is activated in production.

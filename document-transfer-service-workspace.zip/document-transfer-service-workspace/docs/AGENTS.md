# Agent instructions — Apollo DTS

The authoritative specification is `/docs/build-prompt.md` (BUILD PROMPT v3). Read it in full before
any change. If this file and the spec disagree, the spec wins.

Current milestone: 12   <!-- update only when the human accepts a milestone -->

Always:
- Work only on the current milestone. Stop and write the milestone report (§0 rule 7) when done.
- Run the §0.1 commands and report their real output. Never claim untested behaviour works.
- Record unknown partner behaviour as ASM-nnn; unverifiable SDK members as `// VERIFY:`.
- Pass IDs, paths and hashes through orchestrations — never bytes.

Never:
- Add Logic Apps, Event Grid, agents, or SMB/UNC writes from the Function.
- Use secrets, keys or SAS in code/config; use Sites.ReadWrite.All; lock the immutability policy.
- Use DateTime.UtcNow, Guid.NewGuid(), I/O or config reads inside orchestrators.
- Bind Service Bus triggers to string; derive the watermark from MAX() over data tables.
- Log document content, insured names, tokens or partner payloads.
# Apollo DTS — Assumptions & Open Questions

> **Status:** Milestone 1. Items tagged `// VERIFY:` in source code correspond to entries here.

## Format

Each assumption lists: the assumption made, the basis for it, the risk if wrong, and when it needs to be confirmed.

---

## Infrastructure

| # | Assumption | Basis | Risk if Wrong | Confirm By |
|---|-----------|-------|---------------|------------|
| A-001 | Flex Consumption + Durable Functions + VNet integration is GA in UK South | Microsoft Learn docs verified 2026-09-26 | Must fall back to EP1 plan (higher cost, no true scale-to-zero) | Milestone 2 infra provisioning |
| A-002 | Azure Storage task hub is the correct Durable backend (not Netherite or MSSQL) | ADR-0003; cost/complexity trade-off | MSSQL backend may be required for stricter audit/DR | Confirm with platform team before Milestone 3 |
| A-003 | UK South has sufficient Flex Consumption quota for expected peak throughput | Not formally checked | Quota exhaustion at peak; need EP1 fallback | Load test in Milestone 4 |
| A-004 | Private DNS zone and VNet peering for Azure SQL are pre-provisioned by platform team | Standard enterprise pattern | SQL connectivity fails in VNet-integrated functions | Milestone 2 deployment handover |

## Whitespace Integration

| # | Assumption | Basis | Risk if Wrong | Confirm By |
|---|-----------|-------|---------------|------------|
| A-005 | Whitespace partner API uses SQL-like `"YYYY-MM-DD HH:mm:ss"` timestamps without timezone; these are UTC per ASM-015 | Build prompt §ASM-015; `PartnerTimestampParser` comment | Timestamps are local time → incorrect change window detection | Integration test against real API in Milestone 2 |
| A-006 | Whitespace returns documents as binary streams accessible via a URL with a bearer token | Build prompt §discovery flow | May require chunked download or different auth model | Whitespace sandbox testing in Milestone 2 |
| A-007 | Whitespace change API is pageable and returns a cursor/continuation token | Build prompt §partner ports | Page size or cursor format may differ | Milestone 2 WhitespaceDocumentSource implementation |
| A-008 | A single Whitespace OAuth2 client credential (per partner config row) is sufficient | Build prompt auth model | May need per-user impersonation or delegated flow | Confirm with Whitespace technical contact |

## File Handling

| # | Assumption | Basis | Risk if Wrong | Confirm By |
|---|-----------|-------|---------------|------------|
| A-009 | ZIP files from partners contain only the expected document types (PDF, DOCX, XLSX, etc.) — no nested ZIPs requiring recursive expansion | Build prompt §archive expansion | Nested ZIPs silently dropped or cause failures | Partner test data review in Milestone 2 |
| A-010 | Maximum individual document size is 500 MB; maximum ZIP size is 2 GB | Build prompt §file size limits | `HashingReadStream` cap misconfigured → legitimate docs rejected | Confirm with partner and platform team |
| A-011 | PDF magic bytes starting at offset 0 (`%PDF-`) are sufficient for type detection | Build prompt §10.2; `FileSignature` implementation | Linearised or encrypted PDFs may differ | Verify with sample partner files in Milestone 2 |
| A-012 | SHA-1 partner-provided checksums are base64-encoded (not hex) | Build prompt §10.1 `computeSha1` justification | Checksum comparison fails silently | Confirm with Whitespace API spec |

## Database & Configuration

| # | Assumption | Basis | Risk if Wrong | Confirm By |
|---|-----------|-------|---------------|------------|
| A-013 | DACPAC MERGE is safe to run during rolling deployment (no destructive schema changes in Milestone 1) | ADR-0015; Milestone 1 has no schema yet | Blue-green deployment required if schema changes are destructive | Milestone 3 DACPAC design review |
| A-014 | Business configuration (partner schedules, destination mappings) changes are infrequent enough that SQL config-as-code (DACPAC MERGE) does not impede operations | ADR-0015 | Ops team needs self-service config changes → admin UI required | Post-MVP review |
| A-015 | Connection string for Azure SQL is retrieved via Key Vault reference (not embedded) | ADR-0018; build prompt §credentials | If Key Vault is unreachable at cold start, function fails entirely | Milestone 2 startup health probe |

## Security & Compliance

| # | Assumption | Basis | Risk if Wrong | Confirm By |
|---|-----------|-------|---------------|------------|
| A-016 | All document content is classified at least `Confidential` (classification 20); none is `Public` | Build prompt §data classification; London Market context | Special-category personal data handling requires additional controls | DPO sign-off before production |
| A-017 | Managed Identity has been granted `Storage Blob Data Contributor` on staging container and `Storage Queue Data Contributor` on task hub storage | Standard platform provisioning | Cold-start failure; silent permission error at runtime | Milestone 2 deployment runbook |
| A-018 | FCA/PRA audit log retention is 7 years (SYSC 9.1.1A) | Regulatory reading; confirmed in build prompt | Incorrect retention policy → regulatory breach | Legal/compliance review before production launch |

## Open Questions

- **OQ-001**: Does Whitespace enforce IP allowlisting? If so, static egress IPs are needed — Flex Consumption uses NAT gateway for VNet egress. Confirm with network team.
- **OQ-002**: Is the `dts-risk-delivery` Service Bus namespace shared with other services or dedicated? Affects quota planning.
- **OQ-003**: What is the target SLA for document delivery end-to-end? Drives retry budget and circuit-breaker thresholds.
- **OQ-004**: Are Network Share (SMB) destinations in scope for Milestone 2 or deferred? Requires Private Endpoint or ExpressRoute to on-premises.

<!-- TODO: Update as assumptions are confirmed or invalidated during implementation -->

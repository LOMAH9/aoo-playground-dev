using './main.bicep'

// ── Environment (UK South — primary) ──────────────────────────────────────
// For UK West DR deployment use prod-ukw.parameters.bicepparam.
param environment = 'prod'
param location    = 'uksouth'

// ── Shared integration platform (rg-uks-integrationplatform-prod) ─────────
// Pipeline overrides this via SHARED_RESOURCE_GROUP variable group variable.
// Value here is used for local az CLI runs only.
param sharedInfraResourceGroupName = 'rg-uks-integrationplatform-prod'  // overridden by SHARED_RESOURCE_GROUP
param serviceBusNamespaceName      = 'sbns-uks-integrationplatform-prod' // overridden by SERVICE_BUS_NAMESPACE
param sharedKeyVaultName           = 'kv-uks-integration-prod'         // overridden by KEY_VAULT_NAME
param appInsightsName              = 'appi-uks-integrationplatform-prod' // overridden by APP_INSIGHTS_NAME
param apimBaseUrl                  = 'https://apim-uks-integrationplatform-prod.azure-api.net' // overridden by APIM_BASE_URL

// ── Email ──────────────────────────────────────────────────────────────────
param acsEmailSenderAddress = 'DoNotReply@<your-acs-domain>.azurecomm.net'

// ── Managed API connections ────────────────────────────────────────────────
param sharePointConnectionRuntimeUrl = ''

using './main.bicep'

// ── Environment (UK West — DR replica of prod) ─────────────────────────────
// Deployed to rg-ukw-dts-prod in UK West. The Logic App and storage accounts
// (staukwdtsconfigprod, staukwdtsdataprod) are provisioned here independently.
// Shared integration platform resources (KV, SB, APIM, AppInsights) remain in
// UK South and are referenced cross-region — no separate DR instances.
param environment = 'prod'
param location    = 'ukwest'

// ── Shared integration platform (rg-uks-integrationplatform-prod — UK South) ─
// Shared infra is not replicated to UK West. The DR Logic App reads secrets
// from the UK South KV and publishes to the UK South Service Bus namespace.
// Pipeline overrides this via SHARED_RESOURCE_GROUP variable group variable.
// Value here is used for local az CLI runs only.
param sharedInfraResourceGroupName = 'rg-uks-integrationplatform-prod'  // overridden by SHARED_RESOURCE_GROUP
param serviceBusNamespaceName      = 'sbns-uks-integrationplatform-prod' // overridden by SERVICE_BUS_NAMESPACE
param sharedKeyVaultName           = 'kv-uks-integration-prod'         // overridden by KEY_VAULT_NAME
param appInsightsName              = 'appi-uks-integrationplatform-prod' // overridden by APP_INSIGHTS_NAME
param apimBaseUrl                  = 'https://apim-uks-integrationplatform-prod.azure-api.net' // overridden by APIM_BASE_URL

// ── Email ──────────────────────────────────────────────────────────────────
param acsEmailSenderAddress = 'DoNotReply@<your-acs-domain>.azurecomm.net'

// ── Managed API connections ────────────────────────────────────────────────
param sharePointConnectionRuntimeUrl = ''

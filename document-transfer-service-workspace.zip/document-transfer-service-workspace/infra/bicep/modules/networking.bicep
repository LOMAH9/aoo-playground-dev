// Deploys to: DTS resource group (same scope as main.bicep)

param environment string
param locationCode string
param location string
param tags object

@description('Address space for the DTS VNet. Adjust to avoid overlap with peered corporate/hub networks.')
param vnetAddressPrefix string = '10.0.0.0/16'

@description('CIDR for the Logic App VNet integration subnet. Minimum /28; /26 recommended (64 IPs) for production scale.')
param logicAppSubnetPrefix string = '10.0.1.0/26'

@description('CIDR for the storage account private endpoint subnet.')
param storageSubnetPrefix string = '10.0.2.0/27'

var vnetName             = 'vnet-${locationCode}-dts-${environment}'
var logicAppSubnetName   = 'snet-${locationCode}-dts-logicapp-${environment}'
var storageSubnetName    = 'snet-${locationCode}-dts-storage-${environment}'

// ── NSG for Logic App VNet integration subnet ─────────────────────────────────
// The VNet integration subnet carries OUTBOUND traffic only. Inbound to the
// Logic App HTTP triggers is controlled via App Service access restrictions
// (ipSecurityRestrictions). This NSG provides defence-in-depth.

resource logicAppNsg 'Microsoft.Network/networkSecurityGroups@2023-05-01' = {
  name: 'nsg-${locationCode}-dts-logicapp-${environment}'
  location: location
  tags: tags
  properties: {
    securityRules: [
      {
        name: 'Deny-Inbound-Internet'
        properties: {
          priority: 1000
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: 'Internet'
          destinationAddressPrefix: '*'
          description: 'Block inbound internet on the Logic App VNet integration subnet'
        }
      }
    ]
  }
}

// ── VNet ───────────────────────────────────────────────────────────────────────

resource vnet 'Microsoft.Network/virtualNetworks@2023-05-01' = {
  name: vnetName
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [ vnetAddressPrefix ]
    }
    subnets: [
      {
        name: logicAppSubnetName
        properties: {
          addressPrefix: logicAppSubnetPrefix
          networkSecurityGroup: { id: logicAppNsg.id }
          delegations: [
            {
              name: 'delegation-logicapp'
              properties: { serviceName: 'Microsoft.Web/serverFarms' }
            }
          ]
          serviceEndpoints: [
            { service: 'Microsoft.Storage',    locations: [ location ] }
            { service: 'Microsoft.ServiceBus', locations: [ location ] }
            { service: 'Microsoft.KeyVault',   locations: [ location ] }
          ]
        }
      }
      {
        name: storageSubnetName
        properties: {
          addressPrefix: storageSubnetPrefix
          privateEndpointNetworkPolicies: 'Disabled'
        }
      }
    ]
  }
}

// ── Private DNS zones (storage services) ─────────────────────────────────────
// These zones are created in the DTS RG and linked to the DTS VNet.
// NOTE: In a hub-spoke architecture, centralised private DNS zones for storage
// will exist in the hub. If so, remove these zone resources and links, and instead
// pass the hub zone IDs in as parameters in main.bicep.

resource blobDnsZone 'Microsoft.Network/privateDnsZones@2020-06-01' = {
  name: 'privatelink.blob.core.windows.net'
  location: 'global'
  tags: tags
}

resource tableDnsZone 'Microsoft.Network/privateDnsZones@2020-06-01' = {
  name: 'privatelink.table.core.windows.net'
  location: 'global'
  tags: tags
}

resource queueDnsZone 'Microsoft.Network/privateDnsZones@2020-06-01' = {
  name: 'privatelink.queue.core.windows.net'
  location: 'global'
  tags: tags
}

resource fileDnsZone 'Microsoft.Network/privateDnsZones@2020-06-01' = {
  name: 'privatelink.file.core.windows.net'
  location: 'global'
  tags: tags
}

// ── VNet links for each DNS zone ──────────────────────────────────────────────

resource blobDnsZoneLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = {
  name: 'link-${vnetName}'
  parent: blobDnsZone
  location: 'global'
  properties: { virtualNetwork: { id: vnet.id }, registrationEnabled: false }
}

resource tableDnsZoneLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = {
  name: 'link-${vnetName}'
  parent: tableDnsZone
  location: 'global'
  properties: { virtualNetwork: { id: vnet.id }, registrationEnabled: false }
}

resource queueDnsZoneLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = {
  name: 'link-${vnetName}'
  parent: queueDnsZone
  location: 'global'
  properties: { virtualNetwork: { id: vnet.id }, registrationEnabled: false }
}

resource fileDnsZoneLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = {
  name: 'link-${vnetName}'
  parent: fileDnsZone
  location: 'global'
  properties: { virtualNetwork: { id: vnet.id }, registrationEnabled: false }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output vnetId string          = vnet.id
output vnetName string        = vnet.name
output logicAppSubnetId string = '${vnet.id}/subnets/${logicAppSubnetName}'
output storageSubnetId string  = '${vnet.id}/subnets/${storageSubnetName}'
output blobDnsZoneId string    = blobDnsZone.id
output tableDnsZoneId string   = tableDnsZone.id
output queueDnsZoneId string   = queueDnsZone.id
output fileDnsZoneId string    = fileDnsZone.id

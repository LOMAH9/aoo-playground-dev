targetScope = 'resourceGroup'

param serviceBusNamespaceName string
param sharedKeyVaultName string
param logicAppPrincipalId string

// ── Reference existing shared resources ───────────────────────────────────

resource sbus 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' existing = {
  name: serviceBusNamespaceName
}

resource sharedKeyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: sharedKeyVaultName
}

// ── Discovery topics (internal) ────────────────────────────────────────────

resource topicDiscRuns 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'dts-disc-runs'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: true
    duplicateDetectionHistoryTimeWindow: 'PT10M'
    defaultMessageTimeToLive: 'P14D'
    enableBatchedOperations: true
  }
}

resource subDiscRuns 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicDiscRuns
  name: 'sub-disc'
  properties: {
    maxDeliveryCount: 3
    lockDuration: 'PT5M'
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

resource topicDiscRisks 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'dts-disc-risks'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: false
    defaultMessageTimeToLive: 'P14D'
    enableBatchedOperations: true
  }
}

resource subDiscRisks 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicDiscRisks
  name: 'sub-risk'
  properties: {
    maxDeliveryCount: 3
    lockDuration: 'PT5M'
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

// ── Delivery request topic ─────────────────────────────────────────────────
// Named with integration-platform convention: sbt- prefix for shared topics.
// No duplicate detection — replays are legitimate re-deliveries (see ADR-0009).

resource topicDlvRequests 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'sbt-dts-riskdocs-delivery'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: false
    defaultMessageTimeToLive: 'P14D'
    enableBatchedOperations: true
  }
}

resource subDlvRequests 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicDlvRequests
  name: 'sbts-dts-riskdocs-delivery'
  properties: {
    maxDeliveryCount: 10
    lockDuration: 'PT5M'
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

// ── Notifications topic (async; consumed by shared send-notifications workflow) ──

resource topicNotifications 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'sbt-dts-riskdocs-notifications'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: false
    defaultMessageTimeToLive: 'P7D'
    enableBatchedOperations: true
  }
}

resource subNotifications 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicNotifications
  name: 'sbts-dts-riskdocs-notifications'
  properties: {
    maxDeliveryCount: 5
    lockDuration: 'PT2M'
    defaultMessageTimeToLive: 'P7D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

// ── Role assignments: Logic App MI → Service Bus ───────────────────────────

var sbDataSenderId   = '69a216fc-b8fb-44d8-bc22-1f3c2cd27a39' // Azure Service Bus Data Sender
var sbDataReceiverId = '4f6d3b9b-027b-4f4c-9142-0e5a2a2247e0' // Azure Service Bus Data Receiver

resource sbSenderRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(logicAppPrincipalId, sbDataSenderId, sbus.id)
  scope: sbus
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', sbDataSenderId)
    principalId: logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource sbReceiverRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(logicAppPrincipalId, sbDataReceiverId, sbus.id)
  scope: sbus
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', sbDataReceiverId)
    principalId: logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// ── Role: Key Vault Secrets User → Logic App MI ────────────────────────────

var kvSecretsUserId = '4633458b-17de-408a-b874-0445c86b69e6'

resource kvSecretsUserRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(logicAppPrincipalId, kvSecretsUserId, sharedKeyVault.id)
  scope: sharedKeyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', kvSecretsUserId)
    principalId: logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────

output topicDlvRequestsName string = topicDlvRequests.name
output subDlvRequestsName string = subDlvRequests.name
output topicNotificationsName string = topicNotifications.name

param environment string
param locationCode string
param location string
param tags object

@description('Subnet resource ID for private endpoints. From networking module output storageSubnetId.')
param storageSubnetId string

@description('Private DNS zone resource ID for blob. From networking module output blobDnsZoneId.')
param blobDnsZoneId string

@description('Private DNS zone resource ID for table. From networking module output tableDnsZoneId.')
param tableDnsZoneId string

// ── Derived storage account name ──────────────────────────────────────────────
// Naming: sta + locationCode + dts + data + env
// e.g. stauksdtsdatadev (16 chars), stauksdtsdataprod (17 chars), staukwdtsdataprod (17 chars)

var dataAccountName = 'sta${locationCode}dtsdata${environment}'

// ── Single data storage account ───────────────────────────────────────────────
// Hosts: staging + quarantine + records blob containers and all DTS tables.
// Public network access is disabled; all access is via private endpoints from
// the Logic App through the VNet. AzureServices bypass permits ARM/Bicep deployment.

resource dataStorage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: dataAccountName
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    supportsHttpsTrafficOnly: true
    networkAcls: {
      bypass: 'AzureServices'
      defaultAction: 'Deny'
      virtualNetworkRules: []
      ipRules: []
    }
  }
}

// ── Blob service ───────────────────────────────────────────────────────────────

resource blobService 'Microsoft.Storage/storageAccounts/blobServices@2023-01-01' = {
  parent: dataStorage
  name: 'default'
  properties: {
    isVersioningEnabled: true
  }
}

resource stagingContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-01-01' = {
  parent: blobService
  name: 'dts-staging'
  properties: { publicAccess: 'None' }
}

resource quarantineContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-01-01' = {
  parent: blobService
  name: 'dts-quarantine'
  properties: { publicAccess: 'None' }
}

resource recordsContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-01-01' = {
  parent: blobService
  name: 'dts-records'
  properties: {
    publicAccess: 'None'
    immutableStorageWithVersioning: { enabled: true }
  }
}

// ── Table service ──────────────────────────────────────────────────────────────

resource tableService 'Microsoft.Storage/storageAccounts/tableServices@2023-01-01' = {
  parent: dataStorage
  name: 'default'
}

resource tableWorkloads 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsWorkloads'
}

resource tableWorkloadDocRouting 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsWorkloadDocRouting'
}

resource tableWorkloadRuntimeState 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsWorkloadRuntimeState'
}

resource tableWorkloadSchedules 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsWorkloadSchedules'
}

resource tablePartners 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsPartners'
}

resource tableNonWorkingDays 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsNonWorkingDays'
}

resource tableOrchestrationRuns 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsOrchestrationRuns'
}

resource tableRisks 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsRisks'
}

resource tableDocuments 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsDocuments'
}

resource tableDocumentDeliveries 'Microsoft.Storage/storageAccounts/tableServices/tables@2023-01-01' = {
  parent: tableService
  name: 'DtsDocumentDeliveries'
}

// ── Private endpoint: blob (data storage) ────────────────────────────────────

resource dataBlobPe 'Microsoft.Network/privateEndpoints@2023-05-01' = {
  name: 'pe-${dataAccountName}-blob'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${dataAccountName}-blob'
        properties: {
          privateLinkServiceId: dataStorage.id
          groupIds: [ 'blob' ]
        }
      }
    ]
  }
}

resource dataBlobPeDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-05-01' = {
  name: 'default'
  parent: dataBlobPe
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'blob'
        properties: { privateDnsZoneId: blobDnsZoneId }
      }
    ]
  }
}

// ── Private endpoint: table (data storage) ───────────────────────────────────

resource dataTablePe 'Microsoft.Network/privateEndpoints@2023-05-01' = {
  name: 'pe-${dataAccountName}-table'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${dataAccountName}-table'
        properties: {
          privateLinkServiceId: dataStorage.id
          groupIds: [ 'table' ]
        }
      }
    ]
  }
}

resource dataTablePeDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-05-01' = {
  name: 'default'
  parent: dataTablePe
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'table'
        properties: { privateDnsZoneId: tableDnsZoneId }
      }
    ]
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output dataAccountName string      = dataStorage.name
output dataAccountId string        = dataStorage.id
output stagingContainerName string  = stagingContainer.name
output quarantineContainerName string = quarantineContainer.name
output recordsContainerName string  = recordsContainer.name

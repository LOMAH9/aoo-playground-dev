param logicAppName string
param servicePlanName string
param environment string
param locationCode string
param location string
param tags object
param serviceBusNamespaceName string
param apimBaseUrl string
param logAnalyticsWorkspaceId string
param sharedKeyVaultName string

// ── Blob storage account names (per container type) ───────────────────────────
// All default to the same data account. Set independently to split containers
// across separate storage accounts — the Logic App MI requires the appropriate
// Storage Blob Data Contributor role on each target account.

param blobStagingAccountName string
param blobRecordsAccountName string
param blobQuarantineAccountName string
param tableStorageAccountName string

param blobStagingContainerName string
param blobRecordsContainerName string
param blobQuarantineContainerName string
param sbusTopicDlvRequests string
param sbusSubDlvRequests string
param sbusTopicNotifications string
param sharePointConnectionRuntimeUrl string
param sharePointConnectionResourceId string = ''
param appInsightsConnectionStringSecretUri string
param appInsightsInstrumentationKeySecretUri string
param apimSubscriptionKeySecretUri string
param acsEmailEndpointSecretUri string
param acsEmailSenderAddress string
param correlationIdHeader string = 'X-Correlation-ID'
param whitespaceApiAudienceId string = ''

// ── Networking ─────────────────────────────────────────────────────────────────

@description('Subnet resource ID for the Logic App VNet integration (outbound). From networking module.')
param logicAppSubnetId string

@description('Subnet resource ID for storage private endpoints. From networking module.')
param storageSubnetId string

@description('Private DNS zone IDs for config storage private endpoints. From networking module.')
param blobDnsZoneId string
param tableDnsZoneId string
param queueDnsZoneId string
param fileDnsZoneId string

@description('Corporate network CIDR to allow inbound access to Logic App HTTP triggers (e.g. "10.100.0.0/16"). Leave empty to restrict to VirtualNetwork tag only.')
param corporateNetworkCidr string = ''

// ── Logic App backing (config) storage ────────────────────────────────────────
// Hosts Logic App state, artifact cache, and workflow definitions at runtime.
// Naming: sta + locationCode + dts + config + env
// Public access is disabled; accessed exclusively via private endpoints from the
// Logic App through the VNet.

var configStorageName = 'sta${locationCode}dtsconfig${environment}'

resource configStorage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: configStorageName
  location: location
  tags: tags
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    supportsHttpsTrafficOnly: true
    networkAcls: {
      bypass: 'AzureServices'
      defaultAction: 'Deny'
      virtualNetworkRules: []
      ipRules: []
    }
  }
}

// ── Private endpoints for config storage (4 services) ────────────────────────
// Logic App Standard requires blob, table, queue, and file access to its backing
// storage account. Each service needs a separate private endpoint.

resource configBlobPe 'Microsoft.Network/privateEndpoints@2023-05-01' = {
  name: 'pe-${configStorageName}-blob'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorageName}-blob'
        properties: { privateLinkServiceId: configStorage.id, groupIds: [ 'blob' ] }
      }
    ]
  }
}

resource configBlobPeDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-05-01' = {
  name: 'default'
  parent: configBlobPe
  properties: {
    privateDnsZoneConfigs: [ { name: 'blob', properties: { privateDnsZoneId: blobDnsZoneId } } ]
  }
}

resource configTablePe 'Microsoft.Network/privateEndpoints@2023-05-01' = {
  name: 'pe-${configStorageName}-table'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorageName}-table'
        properties: { privateLinkServiceId: configStorage.id, groupIds: [ 'table' ] }
      }
    ]
  }
}

resource configTablePeDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-05-01' = {
  name: 'default'
  parent: configTablePe
  properties: {
    privateDnsZoneConfigs: [ { name: 'table', properties: { privateDnsZoneId: tableDnsZoneId } } ]
  }
}

resource configQueuePe 'Microsoft.Network/privateEndpoints@2023-05-01' = {
  name: 'pe-${configStorageName}-queue'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorageName}-queue'
        properties: { privateLinkServiceId: configStorage.id, groupIds: [ 'queue' ] }
      }
    ]
  }
}

resource configQueuePeDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-05-01' = {
  name: 'default'
  parent: configQueuePe
  properties: {
    privateDnsZoneConfigs: [ { name: 'queue', properties: { privateDnsZoneId: queueDnsZoneId } } ]
  }
}

resource configFilePe 'Microsoft.Network/privateEndpoints@2023-05-01' = {
  name: 'pe-${configStorageName}-file'
  location: location
  tags: tags
  properties: {
    subnet: { id: storageSubnetId }
    privateLinkServiceConnections: [
      {
        name: 'pe-${configStorageName}-file'
        properties: { privateLinkServiceId: configStorage.id, groupIds: [ 'file' ] }
      }
    ]
  }
}

resource configFilePeDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-05-01' = {
  name: 'default'
  parent: configFilePe
  properties: {
    privateDnsZoneConfigs: [ { name: 'file', properties: { privateDnsZoneId: fileDnsZoneId } } ]
  }
}

// ── App Service Plan ───────────────────────────────────────────────────────────

resource servicePlan 'Microsoft.Web/serverfarms@2022-09-01' = {
  name: servicePlanName
  location: location
  tags: tags
  sku: {
    name: 'WS1'
    tier: 'WorkflowStandard'
  }
  kind: 'windows'
  properties: {
    targetWorkerCount: 1
    targetWorkerSizeId: 0
    maximumElasticWorkerCount: 20
  }
}

// ── Logic App Standard ─────────────────────────────────────────────────────────

var configStorageConnectionString = 'DefaultEndpointsProtocol=https;AccountName=${configStorage.name};AccountKey=${configStorage.listKeys().keys[0].value};EndpointSuffix=${az.environment().suffixes.storage}'

resource logicApp 'Microsoft.Web/sites@2022-09-01' = {
  name: logicAppName
  location: location
  tags: tags
  kind: 'workflowapp,functionapp'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: servicePlan.id
    httpsOnly: true
    // VNet integration: all outbound traffic routes through the Logic App subnet.
    // The subnet must have a delegation to Microsoft.Web/serverFarms.
    virtualNetworkSubnetId: logicAppSubnetId
    siteConfig: {
      use32BitWorkerProcess: false
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
      http20Enabled: true
      vnetRouteAllEnabled: true  // route all outbound (including to storage, SB, KV) through VNet
      // ── Inbound access restrictions ────────────────────────────────────────
      // Deny all internet inbound. Only corporate network (VPN/ExpressRoute) and
      // internal VNet services can reach the Logic App HTTP trigger endpoints.
      // The 2x internal ops workflows (wf-trigger-http-manual, wf-trigger-http-replay)
      // are only accessible from the corporate network — not from the public internet.
      ipSecurityRestrictionsDefaultAction: 'Deny'
      scmIpSecurityRestrictionsDefaultAction: 'Deny'
      ipSecurityRestrictions: concat(
        [
          {
            priority: 100
            action: 'Allow'
            tag: 'ServiceTag'
            ipAddress: 'VirtualNetwork'
            name: 'Allow-VirtualNetwork'
            description: 'Allow traffic from within the Azure VNet (and connected networks via VPN/ExpressRoute)'
          }
        ],
        empty(corporateNetworkCidr) ? [] : [
          {
            priority: 200
            action: 'Allow'
            ipAddress: corporateNetworkCidr
            name: 'Allow-Corporate-Network'
            description: 'Allow corporate network CIDR (IT support access to ops HTTP triggers via Postman)'
          }
        ]
      )
      appSettings: [
        // ── Runtime infrastructure ────────────────────────────────────────────
        { name: 'FUNCTIONS_EXTENSION_VERSION',  value: '~4' }
        { name: 'FUNCTIONS_WORKER_RUNTIME',     value: 'node' }
        { name: 'APP_KIND',                     value: 'workflowapp' }
        { name: 'WEBSITE_RUN_FROM_PACKAGE',     value: '1' }
        { name: 'AzureWebJobsStorage',          value: configStorageConnectionString }
        { name: 'WEBSITE_CONTENTAZUREFILECONNECTIONSTRING', value: configStorageConnectionString }
        { name: 'AzureFunctionsJobHost__extensionBundle__id',      value: 'Microsoft.Azure.Functions.ExtensionBundle.Workflows' }
        { name: 'AzureFunctionsJobHost__extensionBundle__version', value: '[1.*, 2.0.0)' }
        // ── Observability ─────────────────────────────────────────────────────
        { name: 'APPLICATIONINSIGHTS_CONNECTION_STRING',  value: '@Microsoft.KeyVault(SecretUri=${appInsightsConnectionStringSecretUri})' }
        { name: 'appinsights_instrumentation_key',        value: '@Microsoft.KeyVault(SecretUri=${appInsightsInstrumentationKeySecretUri})' }
        // ── External services (KV-backed secrets) ─────────────────────────────
        { name: 'apim_subscription_key', value: '@Microsoft.KeyVault(SecretUri=${apimSubscriptionKeySecretUri})' }
        { name: 'acs_email_endpoint',    value: '@Microsoft.KeyVault(SecretUri=${acsEmailEndpointSecretUri})' }
        { name: 'acs_email_sender_address', value: acsEmailSenderAddress }
        // ── Runtime behaviour ──────────────────────────────────────────────────
        { name: 'correlation_id_header',    value: correlationIdHeader }
        { name: 'whitespace_api_audience_id', value: whitespaceApiAudienceId }
        // ── Managed API connections (SharePoint Online) ────────────────────────
        // sharepoint_api_id: computed — changes only if subscription or region changes.
        // sharepoint_connection_id and sharepoint_connection_runtime_url: populated post-deployment after
        // creating the managed API connection in the Azure Portal (see setup-guide.md).
        { name: 'sharepoint_api_id',              value: '/subscriptions/${subscription().subscriptionId}/providers/Microsoft.Web/locations/${location}/managedApis/sharepointonline' }
        { name: 'sharepoint_connection_id',        value: sharePointConnectionResourceId }
        { name: 'sharepoint_connection_runtime_url', value: sharePointConnectionRuntimeUrl }
        // ── DTS infrastructure bindings ────────────────────────────────────────
        { name: 'servicebus_fully_qualified_namespace', value: '${serviceBusNamespaceName}.servicebus.windows.net' }
        { name: 'sbus_topic_dlv_requests',  value: sbusTopicDlvRequests }
        { name: 'sbus_sub_dlv_requests',    value: sbusSubDlvRequests }
        { name: 'sbus_topic_notifications', value: sbusTopicNotifications }
        // ── Blob storage (per-container account names) ────────────────────────
        // All three default to the same data account. Set independently to route
        // a container to a separate storage account (MI must have Blob Data Contributor
        // on the target account).
        { name: 'blob_staging_account_name',   value: blobStagingAccountName }
        { name: 'blob_records_account_name',   value: blobRecordsAccountName }
        { name: 'blob_quarantine_account_name', value: blobQuarantineAccountName }
        { name: 'blob_staging_container',      value: blobStagingContainerName }
        { name: 'blob_records_container',      value: blobRecordsContainerName }
        { name: 'blob_quarantine_container',   value: blobQuarantineContainerName }
        // ── Table storage ──────────────────────────────────────────────────────
        { name: 'datastore_table_storage_account_name', value: tableStorageAccountName }
        // ── Key Vault ──────────────────────────────────────────────────────────
        { name: 'key_vault_name', value: sharedKeyVaultName }
        // ── Business configuration ─────────────────────────────────────────────
        { name: 'environment_name', value: environment }
        { name: 'apim_base_url',    value: apimBaseUrl }
      ]
    }
  }
}

// ── Diagnostic settings ────────────────────────────────────────────────────────

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'default'
  scope: logicApp
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        category: 'WorkflowRuntime'
        enabled: true
        retentionPolicy: { enabled: false, days: 0 }
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
        retentionPolicy: { enabled: false, days: 0 }
      }
    ]
  }
}

// ── Role: config storage Blob Data Contributor → Logic App MI ─────────────────

var storageBlobDataContributorId = 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'

resource configStorageRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(logicAppName, storageBlobDataContributorId, configStorage.id)
  scope: configStorage
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageBlobDataContributorId)
    principalId: logicApp.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output logicAppName string            = logicApp.name
output logicAppId string              = logicApp.id
output logicAppDefaultHostname string = logicApp.properties.defaultHostName
output logicAppPrincipalId string     = logicApp.identity.principalId
output servicePlanId string           = servicePlan.id
output configStorageAccountName string = configStorage.name

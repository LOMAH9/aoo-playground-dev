using './main.bicep'

// ── Environment ────────────────────────────────────────────────────────────
param environment = 'uat'
param location    = 'uksouth'

// ── Shared integration platform (rg-uks-integrationplatform-uat) ──────────
// Pipeline overrides this via SHARED_RESOURCE_GROUP variable group variable.
// Value here is used for local az CLI runs only.
param sharedInfraResourceGroupName = 'rg-uks-integrationplatform-uat'  // overridden by SHARED_RESOURCE_GROUP
param serviceBusNamespaceName      = 'sbns-uks-integrationplatform-uat' // overridden by SERVICE_BUS_NAMESPACE
param sharedKeyVaultName           = 'kv-uks-integration-uat'          // overridden by KEY_VAULT_NAME
param appInsightsName              = 'appi-uks-integrationplatform-uat' // overridden by APP_INSIGHTS_NAME
param apimBaseUrl                  = 'https://apim-uks-integrationplatform-uat.azure-api.net' // overridden by APIM_BASE_URL

// ── Email ──────────────────────────────────────────────────────────────────
param acsEmailSenderAddress = 'DoNotReply@<your-acs-domain>.azurecomm.net'

// ── Managed API connections ────────────────────────────────────────────────
param sharePointConnectionRuntimeUrl = ''

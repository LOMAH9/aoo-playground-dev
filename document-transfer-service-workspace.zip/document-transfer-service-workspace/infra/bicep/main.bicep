targetScope = 'resourceGroup'

// ── Parameters ─────────────────────────────────────────────────────────────

@description('Target environment: dev, uat, or prod')
@allowed(['dev', 'uat', 'prod'])
param environment string

@description('Azure region for all DTS resources. Determines locationCode used in resource names.')
@allowed(['uksouth', 'ukwest'])
param location string = 'uksouth'

@description('Tags applied to all resources')
param tags object = {
  product: 'dts'
  environment: environment
  managedBy: 'bicep'
}

// ── Shared integration platform ───────────────────────────────────────────────
// These resources already exist in the shared integration platform resource group.
// They are referenced (not created) by this deployment.

@description('Resource group containing the shared integration platform (KV, SB, APIM, AppInsights)')
param sharedInfraResourceGroupName string

@description('Shared Service Bus namespace name. Standard or Premium tier required for topics.')
param serviceBusNamespaceName string

@description('Shared Key Vault name. Holds APIM subscription key, AppInsights secrets, ACS endpoint.')
param sharedKeyVaultName string

@description('Shared Application Insights component name. Used to derive the Log Analytics workspace ID for diagnostic settings.')
param appInsightsName string

@description('APIM base URL for all outbound HTTP actions from workflow activities.')
param apimBaseUrl string

// ── KV secret names (in the shared Key Vault) ─────────────────────────────────

param appInsightsConnectionStringSecretName    string = 'appinsights-connection-string'
param appInsightsInstrumentationKeySecretName  string = 'appinsights-instrumentation-key'
param apimSubscriptionKeySecretName            string = 'apim-subscription-key'
param acsEmailEndpointSecretName               string = 'acs-email-endpoint'
param acsEmailSenderAddress                    string
param correlationIdHeader                      string = 'X-Correlation-ID'
param whitespaceApiAudienceId                  string = ''

// ── Managed API connection URLs ────────────────────────────────────────────────

@description('SharePoint Online managed connection runtime URL. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param sharePointConnectionRuntimeUrl string = ''

@description('SharePoint Online managed API connection resource ID. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param sharePointConnectionResourceId string = ''

// ── Networking ─────────────────────────────────────────────────────────────────

@description('Address space for the DTS VNet. Adjust to avoid overlap with peered corporate/hub networks.')
param vnetAddressPrefix string = '10.0.0.0/16'

@description('CIDR for the Logic App VNet integration subnet. Minimum /28; /26 recommended.')
param logicAppSubnetPrefix string = '10.0.1.0/26'

@description('CIDR for the storage account private endpoint subnet.')
param storageSubnetPrefix string = '10.0.2.0/27'

@description('Corporate network CIDR to allow inbound access to Logic App HTTP triggers. Leave empty to restrict to VirtualNetwork tag only.')
param corporateNetworkCidr string = ''

// ── Alerts ─────────────────────────────────────────────────────────────────────

@description('Email address for the DTS ops alert action group. Leave empty to deploy alert rules without email notification.')
param alertEmailAddress string = ''

// ── Derived values ─────────────────────────────────────────────────────────────

var locationCodeMap = {
  uksouth: 'uks'
  ukwest:  'ukw'
}
var locationCode = locationCodeMap[location]

var logicAppName   = 'logic-${locationCode}-dts-${environment}'
var servicePlanName = 'asp-${locationCode}-dts-${environment}'

// ── Service Bus topic/sub names (must match serviceBusResources.bicep) ─────────
var sbusTopicDlvRequests   = 'sbt-dts-riskdocs-delivery'
var sbusSubDlvRequests     = 'sbts-dts-riskdocs-delivery'
var sbusTopicNotifications = 'sbt-dts-riskdocs-notifications'

// ── Existing shared resources ──────────────────────────────────────────────────

resource sharedKeyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: sharedKeyVaultName
  scope: resourceGroup(sharedInfraResourceGroupName)
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' existing = {
  name: appInsightsName
  scope: resourceGroup(sharedInfraResourceGroupName)
}

// ── KV secret URI derivation ───────────────────────────────────────────────────

var appInsightsConnectionStringSecretUri   = '${sharedKeyVault.properties.vaultUri}secrets/${appInsightsConnectionStringSecretName}'
var appInsightsInstrumentationKeySecretUri = '${sharedKeyVault.properties.vaultUri}secrets/${appInsightsInstrumentationKeySecretName}'
var apimSubscriptionKeySecretUri           = '${sharedKeyVault.properties.vaultUri}secrets/${apimSubscriptionKeySecretName}'
var acsEmailEndpointSecretUri              = '${sharedKeyVault.properties.vaultUri}secrets/${acsEmailEndpointSecretName}'

// ── Networking (VNet, subnets, NSG, private DNS zones) ─────────────────────────

module networking './modules/networking.bicep' = {
  name: 'networking'
  params: {
    environment: environment
    locationCode: locationCode
    location: location
    tags: tags
    vnetAddressPrefix:     vnetAddressPrefix
    logicAppSubnetPrefix:  logicAppSubnetPrefix
    storageSubnetPrefix:   storageSubnetPrefix
  }
}

// ── Storage accounts ───────────────────────────────────────────────────────────

module storageAccounts './modules/storageAccounts.bicep' = {
  name: 'storageAccounts'
  params: {
    environment:    environment
    locationCode:   locationCode
    location:       location
    tags:           tags
    storageSubnetId: networking.outputs.storageSubnetId
    blobDnsZoneId:   networking.outputs.blobDnsZoneId
    tableDnsZoneId:  networking.outputs.tableDnsZoneId
  }
}

// ── Logic App Standard ─────────────────────────────────────────────────────────

module logicApp './modules/logicAppStandard.bicep' = {
  name: 'logicAppStandard'
  params: {
    logicAppName:     logicAppName
    servicePlanName:  servicePlanName
    environment:      environment
    locationCode:     locationCode
    location:         location
    tags:             tags
    serviceBusNamespaceName: serviceBusNamespaceName
    apimBaseUrl:             apimBaseUrl
    logAnalyticsWorkspaceId: appInsights.properties.WorkspaceResourceId
    sharedKeyVaultName:      sharedKeyVaultName
    // Per-container blob account names — all default to the single data account.
    // Override individually in the parameter file to route a container to a
    // separate storage account (MI role assignment required on the target account).
    blobStagingAccountName:   storageAccounts.outputs.dataAccountName
    blobRecordsAccountName:   storageAccounts.outputs.dataAccountName
    blobQuarantineAccountName: storageAccounts.outputs.dataAccountName
    tableStorageAccountName:  storageAccounts.outputs.dataAccountName
    blobStagingContainerName:   storageAccounts.outputs.stagingContainerName
    blobRecordsContainerName:   storageAccounts.outputs.recordsContainerName
    blobQuarantineContainerName: storageAccounts.outputs.quarantineContainerName
    sbusTopicDlvRequests:   sbusTopicDlvRequests
    sbusSubDlvRequests:     sbusSubDlvRequests
    sbusTopicNotifications: sbusTopicNotifications
    sharePointConnectionRuntimeUrl:       sharePointConnectionRuntimeUrl
    sharePointConnectionResourceId:       sharePointConnectionResourceId
    appInsightsConnectionStringSecretUri:   appInsightsConnectionStringSecretUri
    appInsightsInstrumentationKeySecretUri: appInsightsInstrumentationKeySecretUri
    apimSubscriptionKeySecretUri:           apimSubscriptionKeySecretUri
    acsEmailEndpointSecretUri:              acsEmailEndpointSecretUri
    acsEmailSenderAddress:                  acsEmailSenderAddress
    correlationIdHeader:                    correlationIdHeader
    whitespaceApiAudienceId:                whitespaceApiAudienceId
    logicAppSubnetId:   networking.outputs.logicAppSubnetId
    storageSubnetId:    networking.outputs.storageSubnetId
    blobDnsZoneId:      networking.outputs.blobDnsZoneId
    tableDnsZoneId:     networking.outputs.tableDnsZoneId
    queueDnsZoneId:     networking.outputs.queueDnsZoneId
    fileDnsZoneId:      networking.outputs.fileDnsZoneId
    corporateNetworkCidr: corporateNetworkCidr
  }
}

// ── Service Bus resources (scoped to shared integration platform RG) ───────────

module serviceBusResources './modules/serviceBusResources.bicep' = {
  name: 'serviceBusResources'
  scope: resourceGroup(sharedInfraResourceGroupName)
  params: {
    serviceBusNamespaceName: serviceBusNamespaceName
    sharedKeyVaultName:      sharedKeyVaultName
    logicAppPrincipalId:     logicApp.outputs.logicAppPrincipalId
  }
}

// ── Role assignments on data storage account ──────────────────────────────────
// Logic App MI needs Blob Data Contributor (staging/records/quarantine) and
// Table Data Contributor (all DTS tables). Both roles on the single data account.

var storageBlobDataContributorId  = 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
var storageTableDataContributorId = '0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3'

var dataAccountNameLocal = 'sta${locationCode}dtsdata${environment}'

resource dataStorageRef 'Microsoft.Storage/storageAccounts@2023-01-01' existing = {
  #disable-next-line BCP334
  name: dataAccountNameLocal
}

resource dataBlobContributorRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(logicAppName, storageBlobDataContributorId, dataStorageRef.id)
  scope: dataStorageRef
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageBlobDataContributorId)
    principalId: logicApp.outputs.logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource dataTableContributorRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(logicAppName, storageTableDataContributorId, dataStorageRef.id)
  scope: dataStorageRef
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageTableDataContributorId)
    principalId: logicApp.outputs.logicAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// ── Alert rules (scoped to shared integration platform RG) ────────────────────

module alertRules './modules/alertRules.bicep' = {
  name: 'alertRules'
  scope: resourceGroup(sharedInfraResourceGroupName)
  params: {
    environment:           environment
    locationCode:          locationCode
    logicAppId:            logicApp.outputs.logicAppId
    serviceBusNamespaceName: serviceBusNamespaceName
    appInsightsId:         appInsights.id
    alertEmailAddress:     alertEmailAddress
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output logicAppName string            = logicApp.outputs.logicAppName
output logicAppId string              = logicApp.outputs.logicAppId
output logicAppDefaultHostname string = logicApp.outputs.logicAppDefaultHostname
output logicAppPrincipalId string     = logicApp.outputs.logicAppPrincipalId
output dataStorageAccountName string  = storageAccounts.outputs.dataAccountName
output configStorageAccountName string = logicApp.outputs.configStorageAccountName
output sharedKeyVaultUri string       = sharedKeyVault.properties.vaultUri
output vnetId string                  = networking.outputs.vnetId

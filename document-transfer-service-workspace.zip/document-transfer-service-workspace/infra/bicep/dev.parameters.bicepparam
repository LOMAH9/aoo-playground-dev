using './main.bicep'

// ── Environment ────────────────────────────────────────────────────────────
param environment = 'dev'
param location    = 'uksouth'

// ── Shared integration platform (rg-uks-integrationplatform-dev) ──────────
// All resources below already exist; they are referenced, not created here.
// Pipeline overrides this via SHARED_RESOURCE_GROUP variable group variable.
// Value here is used for local az CLI runs only.
param sharedInfraResourceGroupName = 'rg-uks-integrationplatform-dev'  // overridden by SHARED_RESOURCE_GROUP
param serviceBusNamespaceName      = 'sbns-uks-integrationplatform-dev' // overridden by SERVICE_BUS_NAMESPACE
param sharedKeyVaultName           = 'kv-uks-integration-dev'          // overridden by KEY_VAULT_NAME
param appInsightsName              = 'appi-uks-integrationplatform-dev' // overridden by APP_INSIGHTS_NAME
param apimBaseUrl                  = 'https://apim-uks-integrationplatform-dev.azure-api.net' // overridden by APIM_BASE_URL

// ── KV secret names (leave at defaults unless names differ in this environment) ──
// param appInsightsInstrumentationKeySecretName = 'appinsights-instrumentation-key'
// param appInsightsConnectionStringSecretName   = 'appinsights-connection-string'
// param apimSubscriptionKeySecretName           = 'apim-subscription-key'
// param acsEmailEndpointSecretName              = 'acs-email-endpoint'

// ── Email ──────────────────────────────────────────────────────────────────
param acsEmailSenderAddress = 'DoNotReply@<your-acs-domain>.azurecomm.net'

// ── Managed API connections ────────────────────────────────────────────────
// Populate after creating the SharePoint connection in the Azure Portal.
param sharePointConnectionRuntimeUrl = ''

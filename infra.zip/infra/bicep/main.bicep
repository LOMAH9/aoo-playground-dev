targetScope = 'resourceGroup'

// ── Parameters ─────────────────────────────────────────────────────────────

@description('Target environment: dev, uat, or prod')
@allowed(['dev', 'uat', 'prod'])
param environment string

@description('Azure region for all DTS resources. Determines locationCode used in resource names.')
@allowed(['uksouth', 'ukwest'])
param location string = 'uksouth'

@description('Tags applied to all resources')
param tags object = {
  product: 'dts'
  environment: environment
  managedBy: 'bicep'
}

// ── Shared integration platform ───────────────────────────────────────────────
// These resources already exist in the shared integration platform resource group.
// They are referenced (not created) by this deployment.

@description('Resource group containing the shared integration platform (KV, SB, APIM, AppInsights)')
param sharedInfraResourceGroupName string

@description('Shared Service Bus namespace name. Standard or Premium tier required for topics.')
param serviceBusNamespaceName string

@description('Shared Key Vault name. Holds APIM subscription key, AppInsights secrets, ACS endpoint.')
param sharedKeyVaultName string

@description('Shared Application Insights component name. Used to derive the Log Analytics workspace ID for diagnostic settings.')
param appInsightsName string

@description('APIM base URL for all outbound HTTP actions from workflow activities.')
param apimBaseUrl string

// ── KV secret names (in the shared Key Vault) ─────────────────────────────────

param appInsightsConnectionStringSecretName    string = 'appinsights-connection-string'
param appInsightsInstrumentationKeySecretName  string = 'appinsights-instrumentation-key'
param apimSubscriptionKeySecretName            string = 'apim-subscription-key'
param acsEmailEndpointSecretName               string = 'acs-email-endpoint'
param acsEmailSenderAddress                    string
param correlationIdHeader                      string = 'X-Correlation-ID'
param whitespaceApiAudienceId                  string = ''

// ── Managed API connection URLs ────────────────────────────────────────────────

@description('SharePoint Online managed connection runtime URL. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param sharePointConnectionRuntimeUrl string = ''

@description('SharePoint Online managed API connection resource ID. Leave empty on first deploy; populate after creating the connection in the Azure Portal.')
param sharePointConnectionResourceId string = ''

// ── Alerts ─────────────────────────────────────────────────────────────────────

@description('Email address for the DTS ops alert action group. Leave empty to deploy alert rules without email notification.')
param alertEmailAddress string = ''

// ── Derived values ─────────────────────────────────────────────────────────────

var locationCodeMap = {
  uksouth: 'uks'
  ukwest:  'ukw'
}
var locationCode = locationCodeMap[location]

var logicAppName   = 'logic-${locationCode}-dts-${environment}'
var servicePlanName = 'asp-${locationCode}-dts-${environment}'

// ── Service Bus topic/sub names (must match serviceBusResources.bicep) ─────────
var sbusTopicDlvRequests   = 'sbt-dts-riskdocs-delivery'
var sbusSubDlvRequests     = 'sbts-dts-riskdocs-delivery'
var sbusTopicNotifications = 'sbt-dts-riskdocs-notifications'

// ── Existing shared resources ──────────────────────────────────────────────────

resource sharedKeyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: sharedKeyVaultName
  scope: resourceGroup(sharedInfraResourceGroupName)
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' existing = {
  name: appInsightsName
  scope: resourceGroup(sharedInfraResourceGroupName)
}

// ── KV secret URI derivation ───────────────────────────────────────────────────

var appInsightsConnectionStringSecretUri   = '${sharedKeyVault.properties.vaultUri}secrets/${appInsightsConnectionStringSecretName}'
var appInsightsInstrumentationKeySecretUri = '${sharedKeyVault.properties.vaultUri}secrets/${appInsightsInstrumentationKeySecretName}'
var apimSubscriptionKeySecretUri           = '${sharedKeyVault.properties.vaultUri}secrets/${apimSubscriptionKeySecretName}'
var acsEmailEndpointSecretUri              = '${sharedKeyVault.properties.vaultUri}secrets/${acsEmailEndpointSecretName}'

// ── Storage accounts ───────────────────────────────────────────────────────────

module storageAccounts './modules/storageAccounts.bicep' = {
  name: 'storageAccounts'
  params: {
    environment:  environment
    locationCode: locationCode
    location:     location
    tags:         tags
  }
}

// ── Logic App Standard ─────────────────────────────────────────────────────────

module logicApp './modules/logicAppStandard.bicep' = {
  name: 'logicAppStandard'
  params: {
    logicAppName:     logicAppName
    servicePlanName:  servicePlanName
    environment:      environment
    locationCode:     locationCode
    location:         location
    tags:             tags
    serviceBusNamespaceName: serviceBusNamespaceName
    apimBaseUrl:             apimBaseUrl
    logAnalyticsWorkspaceId: appInsights.properties.WorkspaceResourceId
    sharedKeyVaultName:      sharedKeyVaultName
    blobStagingAccountName:   storageAccounts.outputs.dataAccountName
    blobRecordsAccountName:   storageAccounts.outputs.dataAccountName
    blobQuarantineAccountName: storageAccounts.outputs.dataAccountName
    tableStorageAccountName:  storageAccounts.outputs.dataAccountName
    blobStagingContainerName:   storageAccounts.outputs.stagingContainerName
    blobRecordsContainerName:   storageAccounts.outputs.recordsContainerName
    blobQuarantineContainerName: storageAccounts.outputs.quarantineContainerName
    sbusTopicDlvRequests:   sbusTopicDlvRequests
    sbusSubDlvRequests:     sbusSubDlvRequests
    sbusTopicNotifications: sbusTopicNotifications
    sharePointConnectionRuntimeUrl:       sharePointConnectionRuntimeUrl
    sharePointConnectionResourceId:       sharePointConnectionResourceId
    appInsightsConnectionStringSecretUri:   appInsightsConnectionStringSecretUri
    appInsightsInstrumentationKeySecretUri: appInsightsInstrumentationKeySecretUri
    apimSubscriptionKeySecretUri:           apimSubscriptionKeySecretUri
    acsEmailEndpointSecretUri:              acsEmailEndpointSecretUri
    acsEmailSenderAddress:                  acsEmailSenderAddress
    correlationIdHeader:                    correlationIdHeader
    whitespaceApiAudienceId:                whitespaceApiAudienceId
  }
}

// ── Service Bus resources (scoped to shared integration platform RG) ───────────

module serviceBusResources './modules/serviceBusResources.bicep' = {
  name: 'serviceBusResources'
  scope: resourceGroup(sharedInfraResourceGroupName)
  params: {
    serviceBusNamespaceName: serviceBusNamespaceName
  }
}

// ── Alert rules (scoped to shared integration platform RG) ────────────────────

module alertRules './modules/alertRules.bicep' = {
  name: 'alertRules'
  scope: resourceGroup(sharedInfraResourceGroupName)
  params: {
    environment:           environment
    locationCode:          locationCode
    logicAppId:            logicApp.outputs.logicAppId
    serviceBusNamespaceName: serviceBusNamespaceName
    appInsightsId:         appInsights.id
    alertEmailAddress:     alertEmailAddress
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output logicAppName string            = logicApp.outputs.logicAppName
output logicAppId string              = logicApp.outputs.logicAppId
output logicAppDefaultHostname string = logicApp.outputs.logicAppDefaultHostname
output logicAppPrincipalId string     = logicApp.outputs.logicAppPrincipalId
output dataStorageAccountName string  = storageAccounts.outputs.dataAccountName
output configStorageAccountName string = logicApp.outputs.configStorageAccountName
output sharedKeyVaultUri string       = sharedKeyVault.properties.vaultUri

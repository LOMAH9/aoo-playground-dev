// Deploys to: shared integration platform resource group
// Scope: set by caller (resourceGroup(sharedInfraResourceGroupName))

param environment string
param locationCode string

@description('Resource ID of the Logic App Standard instance. Used to scope workflow-run metric alerts.')
#disable-next-line no-unused-params
param logicAppId string

@description('Name of the shared Service Bus namespace. Used to scope DLQ metric alerts.')
param serviceBusNamespaceName string

@description('Resource ID of the shared Application Insights component. Used to scope log-based alerts.')
param appInsightsId string

@description('Email address for the DTS ops action group. Leave empty to deploy alerts without email notification.')
param alertEmailAddress string = ''

// ── Action group ──────────────────────────────────────────────────────────────

resource actionGroup 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: 'ag-${locationCode}-dts-${environment}'
  location: 'global'
  properties: {
    groupShortName: 'dts-${environment}'
    enabled: true
    emailReceivers: empty(alertEmailAddress) ? [] : [
      {
        name: 'dts-ops'
        emailAddress: alertEmailAddress
        useCommonAlertSchema: true
      }
    ]
  }
}

// ── Alert: workflow run failures (metric) ─────────────────────────────────────
// Fires when the Logic App records more than 5 failed workflow runs in a 5-minute
// window. A spike in RunsFailed indicates a systemic problem — either a bad deploy
// or an infrastructure dependency (SB, KV, storage) that is unreachable.

resource alertWorkflowFailures 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'dts-${environment}-workflow-failures'
  location: 'global'
  properties: {
    description: 'DTS Logic App has more than 5 failed workflow runs in 5 minutes'
    severity: 2
    enabled: true
    scopes: [ logicAppId ]
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          criterionType: 'StaticThresholdCriterion'
          name: 'RunsFailed'
          metricName: 'RunsFailed'
          timeAggregation: 'Total'
          operator: 'GreaterThan'
          threshold: 5
        }
      ]
    }
    actions: [ { actionGroupId: actionGroup.id } ]
  }
}

// ── Alert: delivery DLQ depth (metric) ────────────────────────────────────────
// Fires as soon as dead-lettered messages appear on the delivery subscription.
// Any non-zero DLQ depth means documents are failing permanently and require manual
// investigation before replay.

resource alertDlqDepth 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'dts-${environment}-dlq-depth'
  location: 'global'
  properties: {
    description: 'DTS delivery topic dead-letter queue has messages — permanent delivery failures require investigation and replay'
    severity: 1
    enabled: true
    scopes: [ resourceId('Microsoft.ServiceBus/namespaces/topics/subscriptions', serviceBusNamespaceName, 'sbt-dts-riskdocs-delivery', 'sbts-dts-riskdocs-delivery') ]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT5M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          criterionType: 'StaticThresholdCriterion'
          name: 'DeadLetteredMessages'
          metricName: 'DeadLetteredMessages'  // verify metric name in portal — may vary by SB tier
          timeAggregation: 'Average'
          operator: 'GreaterThan'
          threshold: 0
        }
      ]
    }
    actions: [ { actionGroupId: actionGroup.id } ]
  }
}

// ── Alert: orchestration failures (log-based) ─────────────────────────────────
// Fires when more than 3 OrchestrationFailed custom events appear in Application
// Insights within a 15-minute window. Individual retries are expected; sustained
// terminal failures indicate a persistent issue.

resource alertOrchestrationFailed 'Microsoft.Insights/scheduledQueryRules@2022-06-15' = {
  name: 'dts-${environment}-orchestration-failed'
  location: resourceGroup().location
  properties: {
    description: 'DTS orchestration runs are reaching terminal failure state at an elevated rate'
    severity: 2
    enabled: true
    scopes: [ appInsightsId ]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT15M'
    autoMitigate: true
    criteria: {
      allOf: [
        {
          query: 'customEvents | where name == "OrchestrationFailed"'
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 3
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [ actionGroup.id ]
    }
  }
}

// ── Alert: dead man's switch (log-based) ─────────────────────────────────────
// Fires when no DiscoveryCompleted event has appeared in Application Insights in
// the last 4 hours. Catches silent failures where the scheduler is not triggering
// or the orchestrator is completing without emitting telemetry.
// NOTE: This alert will false-positive on bank holidays (the schedule intentionally
// skips those days). Suppress or disable the alert rule on known non-working days,
// or filter the query to exclude expected quiet periods.

resource alertDeadMansSwitch 'Microsoft.Insights/scheduledQueryRules@2022-06-15' = {
  name: 'dts-${environment}-dead-mans-switch'
  location: resourceGroup().location
  properties: {
    description: 'No DTS discovery run has completed in the last 4 hours — possible silent failure'
    severity: 3
    enabled: true
    scopes: [ appInsightsId ]
    evaluationFrequency: 'PT30M'
    windowSize: 'PT4H'
    autoMitigate: false  // LessThan conditions cannot self-resolve; alert fires on every evaluation until events reappear
    criteria: {
      allOf: [
        {
          query: 'customEvents | where name == "DiscoveryCompleted"'
          timeAggregation: 'Count'
          operator: 'LessThan'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: [ actionGroup.id ]
    }
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────────

output actionGroupId string = actionGroup.id

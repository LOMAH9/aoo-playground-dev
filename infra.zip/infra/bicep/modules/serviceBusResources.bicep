targetScope = 'resourceGroup'

param serviceBusNamespaceName string

// ── Reference existing shared resources ───────────────────────────────────

resource sbus 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' existing = {
  name: serviceBusNamespaceName
}

// ── Discovery topics (internal) ────────────────────────────────────────────

resource topicDiscRuns 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'dts-disc-runs'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: true
    duplicateDetectionHistoryTimeWindow: 'PT10M'
    defaultMessageTimeToLive: 'P14D'
    enableBatchedOperations: true
  }
}

resource subDiscRuns 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicDiscRuns
  name: 'sub-disc'
  properties: {
    maxDeliveryCount: 3
    lockDuration: 'PT5M'
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

resource topicDiscRisks 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'dts-disc-risks'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: false
    defaultMessageTimeToLive: 'P14D'
    enableBatchedOperations: true
  }
}

resource subDiscRisks 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicDiscRisks
  name: 'sub-risk'
  properties: {
    maxDeliveryCount: 3
    lockDuration: 'PT5M'
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

// ── Delivery request topic ─────────────────────────────────────────────────
// Named with integration-platform convention: sbt- prefix for shared topics.
// No duplicate detection — replays are legitimate re-deliveries (see ADR-0009).

resource topicDlvRequests 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'sbt-dts-riskdocs-delivery'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: false
    defaultMessageTimeToLive: 'P14D'
    enableBatchedOperations: true
  }
}

resource subDlvRequests 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicDlvRequests
  name: 'sbts-dts-riskdocs-delivery'
  properties: {
    maxDeliveryCount: 10
    lockDuration: 'PT5M'
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

// ── Notifications topic (async; consumed by shared send-notifications workflow) ──

resource topicNotifications 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  parent: sbus
  name: 'sbt-dts-riskdocs-notifications'
  properties: {
    maxSizeInMegabytes: 1024
    requiresDuplicateDetection: false
    defaultMessageTimeToLive: 'P7D'
    enableBatchedOperations: true
  }
}

resource subNotifications 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  parent: topicNotifications
  name: 'sbts-dts-riskdocs-notifications'
  properties: {
    maxDeliveryCount: 5
    lockDuration: 'PT2M'
    defaultMessageTimeToLive: 'P7D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
  }
}

// ── Outputs ────────────────────────────────────────────────────────────────

output topicDlvRequestsName string   = topicDlvRequests.name
output subDlvRequestsName string     = subDlvRequests.name
output topicNotificationsName string = topicNotifications.name

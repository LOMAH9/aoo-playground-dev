# Apollo DTS — Architecture Overview

## System Context

Apollo Document Transfer Service (DTS) is an Azure Logic Apps Standard application. It polls external partner APIs (Whitespace initially), retrieves risk documents, validates them, and delivers them to one or more downstream destinations (Azure Blob Storage, SharePoint Online, Azure File Share, Network Share). Post-delivery notifications are sent via the shared notifications workflow using the Office 365 Outlook managed connector (email with file attachments or SharePoint links) or Microsoft Teams incoming webhooks.

```
┌─────────────────────────────────────────────────────────┐
│  Partner APIs (Whitespace, future partners)             │
└────────────────────────┬────────────────────────────────┘
                         │ HTTPS / polling (via APIM)
                         ▼
┌─────────────────────────────────────────────────────────┐
│  Apollo DTS  (Azure Logic Apps Standard)                │
│                                                         │
│  ┌─────────────────────┐                                │
│  │  Timer / HTTP       │  Trigger workflows             │
│  │  / Service Bus      │                                │
│  │  Triggers           │                                │
│  └──────────┬──────────┘                                │
│             │                                           │
│      ┌──────▼───────────┐    ┌────────────────────────┐ │
│      │  Discovery       │───▶│  Service Bus Topic     │ │
│      │  Orchestrator    │    │  sbt-dts-riskdocs-     │ │
│      └──────────────────┘    │  delivery              │ │
│                              └───────────┬────────────┘ │
│                                          │              │
│                              ┌───────────▼────────────┐ │
│                              │  Delivery Orchestrator │ │
│                              └────────────────────────┘ │
│                                          │              │
│  ┌──────────────────────────┐            │              │
│  │  Azure Table Storage     │            │              │
│  │  (config + state)        │            │              │
│  └──────────────────────────┘            │              │
└──────────────────────────────────────────┼──────────────┘
                                           │
             ┌─────────────────────────────▼──────────────┐
             │  Destinations                               │
             │  - Azure Blob Storage                       │
             │  - Azure File Share                         │
             │  - SharePoint Online                        │
             │  - Network Share (SMB)                      │
             └─────────────────────────────────────────────┘
```

## Hosting

| Attribute | Value |
|-----------|-------|
| Runtime | Azure Logic Apps Standard (Workflow runtime, extension bundle v1.*) |
| Hosting plan | Workflow Standard WS1 (Windows App Service Plan) |
| Region | UK South (primary), UK West (DR) |
| Trigger types | Recurrence (timer), Service Bus, HTTP (Request) |

## Workflows

| Workflow | Kind | Trigger | Purpose |
|----------|------|---------|---------|
| `wf-trigger-timer-discoveryworkload` | Stateful | Recurrence (5 min) | Evaluates active workload schedules; dispatches due workloads to the discovery orchestrator |
| `wf-trigger-http-manual` | Stateless | HTTP POST | Manual / forced discovery run, bypassing schedule checks |
| `wf-trigger-http-replay` | Stateless | HTTP POST | Replays failed deliveries for a given workload |
| `wf-trigger-servicebus-topic-deliveryworkload` | Stateful | Service Bus topic | Consumes delivery request messages; invokes the delivery orchestrator |
| `wf-orchestrator-discovery` | Stateful | HTTP child | Orchestrates document discovery: pages partner API, downloads documents to staging blob, publishes delivery requests |
| `wf-orchestrator-delivery` | Stateful | HTTP child | Orchestrates delivery: resolves routing, dispatches per-destination upload activity, records outcome |
| `wf-activity-partner-api-whitespace` | Stateless | HTTP child | Whitespace API — paginated document metadata retrieval |
| `wf-activity-sharepoint` | Stateless | HTTP child | Uploads a staged document to a SharePoint document library via managed connector |
| `wf-shared-notifications-service` | Stateful | HTTP child | Sends delivery outcome notifications via Office 365 Outlook (email) or Teams incoming webhook |

## Infrastructure

| Resource | Name pattern | Purpose |
|----------|-------------|---------|
| Logic App Standard | `logic-{loc}-dts-{env}` | Workflow host |
| App Service Plan | `asp-{loc}-dts-{env}` | Workflow Standard WS1 |
| Config storage account | `sta{loc}dtsconfig{env}` | Logic App backing storage (workflow state, artifact cache, file share) |
| Data storage account | `sta{loc}dtsdata{env}` | Blob containers (staging, records, quarantine) + all DTS Azure Tables |
| Shared Service Bus namespace | `sbns-uks-integrationplatform-{env}` | Delivery request topic; notification topic |
| Shared Key Vault | `kv-uks-integration-{env}` | APIM key, App Insights connection string; SMB routing credentials |
| Shared App Insights | `appi-uks-integrationplatform-{env}` | Telemetry; custom DTS events via direct HTTP ingestion |
| Shared APIM | `apim-uks-integrationplatform-{env}` | Gateway for Whitespace API (OAuth + APIM subscription key) |

## Managed API Connections

Logic App System-Assigned MI is used for all managed connections. Connection runtime URLs are blank on first deploy and populated post-provisioning (see [setup-guide.md](setup-guide.md) step 5).

| Connection name | Managed API | Used by | Auth requirement |
|-----------------|-------------|---------|-----------------|
| `office365` | `office365` | `wf-shared-notifications-service` | MSI — `Mail.Send` application permission granted in Entra |

SharePoint uploads use a direct **HTTP action** against `https://graph.microsoft.com/v1.0/drives/{driveId}/root:/{path}:/content` with MSI auth (`audience: https://graph.microsoft.com`). No managed SharePoint connector is used; the Logic App MI requires `Sites.Selected` write access granted per site via Entra (PnP PowerShell — see [setup-guide.md](setup-guide.md) step 6).

Built-in service provider connections (Service Bus, Azure Blob, Azure Tables) authenticate automatically via MI using the `connectionName` entries in `connections.json`.

## Data Flow — Discovery

1. `wf-trigger-timer-discoveryworkload` fires every 5 minutes. For each active workload whose schedule window and interval criteria are satisfied, it invokes `wf-orchestrator-discovery` with a generated correlation ID.
2. The discovery orchestrator calls `wf-activity-partner-api-whitespace` in a paging loop, collecting document metadata within the configured overlap window.
3. Each discovered document is downloaded from the partner API and written to staging blob storage, with status recorded to `DtsDocuments`.
4. When all documents for a risk are staged, the orchestrator publishes a delivery request message to `sbt-dts-riskdocs-delivery`.
5. After all risks are processed, `wf-orchestrator-discovery` optionally calls `wf-shared-notifications-service` for a run-summary notification.

## Data Flow — Delivery

1. `wf-trigger-servicebus-topic-deliveryworkload` consumes delivery request messages from the Service Bus subscription. Invalid envelopes are dead-lettered; messages with no staged downloads are dead-lettered.
2. The trigger invokes `wf-orchestrator-delivery` with the full message envelope.
3. The delivery orchestrator resolves active routing entries from `DtsWorkloadDocRouting` and fans out per destination.
4. Each routing dispatch calls the appropriate upload activity (`wf-activity-sharepoint`, or activities for Blob / Azure Files / Network Share).
5. Delivery outcome (per-document, per-destination) is recorded to `DtsDocumentDeliveries`. The Service Bus message is completed on success or abandoned on failure (returned to topic for retry / DLQ).
6. After all deliveries complete, `wf-orchestrator-delivery` optionally calls `wf-shared-notifications-service` for a delivery-outcome notification.

## Key Design Decisions

Architecture Decision Records are in `docs/adr/`. Key decisions:

| ADR | Decision |
|-----|---------|
| ADR-0015 | ~~Business notifications via ACS Email~~ — **Superseded**. Notifications now use the Office 365 Outlook managed connector in `wf-shared-notifications-service`. |
| ADR-0022 | ~~SFTP size-only verification~~ — **Superseded**. SFTP is no longer a supported source or destination type. |
| ADR-0028 | Credential vault pattern — SMB routing credentials stored as Key Vault secrets; Logic App MI reads them via Key Vault REST API at delivery time. |

## Compliance

- **UK GDPR Art 5(1)(f), Art 25, Art 32:** encryption in transit (TLS 1.2+) and at rest (Storage Service Encryption), all service access via Managed Identity.
- **SYSC 9:** audit trail written for every document disposition event (`DtsDocumentDeliveries`).
- **SYSC 15A:** retry strategy (exponential backoff on all HTTP actions); DR region (UK West) mirrors UK South.
- **SMCR:** all configuration changes are code-reviewed and deployed via pipeline — no manual production access.
